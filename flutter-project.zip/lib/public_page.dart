// ignore_for_file: use_build_context_synchronously
import 'dart:ui';
import 'package:flutter/material.dart';
import 'public_chat_page.dart';
import 'tiktok_downloader_page.dart';
import 'nik_check_page.dart';
import 'phone_lookup.dart';
import 'subdomain_finder_page.dart';
import 'anime.dart';
import 'chat_ai_page.dart';
import 'synclave_page.dart';

// Urutan tier role, dari paling rendah ke paling tinggi.
const List<String> _tierOrder = ['member', 'reseller', 'vip', 'owner', 'partner', 'staff', 'kingz', 'dev'];

int _tierIndex(String role) {
  final i = _tierOrder.indexOf(role.toLowerCase());
  return i == -1 ? 0 : i;
}

class PublicFeaturesPage extends StatelessWidget {
  final String username;
  final String sessionKey;
  final String role;

  const PublicFeaturesPage({
    super.key,
    required this.username,
    required this.sessionKey,
    this.role = 'member',
  });

  static const _bg     = Color(0xFF080D14);
  static const _card   = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);
  static const _cyan   = Color(0xFFFF1744);
  static const _gold   = Color(0xFFFFC107);

  void _showLocked(BuildContext context, String needRole) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Fitur ini butuh role ${needRole.toUpperCase()} ke atas',
        style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
      backgroundColor: _gold.withOpacity(0.95),
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final myTier = _tierIndex(role);

    final features = [
      _Feature(
        icon: Icons.forum_rounded,
        label: 'Chat Public',
        desc: 'Chat & kirim foto, video, lokasi ke semua user',
        gradient: [const Color(0xFFFF1744), const Color(0xFF0070A0)],
        minRole: 'member',
        onTap: () => Navigator.push(context, _slide(PublicChatPage(username: username))),
      ),
      _Feature(
        icon: Icons.videocam_rounded,
        label: 'TikTok Downloader',
        desc: 'Download video TikTok tanpa watermark HD',
        gradient: [const Color(0xFF010101), const Color(0xFFFF1744)],
        minRole: 'member',
        onTap: () => Navigator.push(context, _slide(TikTokDownloaderPage(sessionKey: sessionKey))),
      ),
      _Feature(
        icon: Icons.movie_creation_outlined,
        label: 'Anime',
        desc: 'Cari & nonton info anime favorit',
        gradient: [const Color(0xFFEC4899), const Color(0xFFBE185D)],
        minRole: 'member',
        onTap: () => Navigator.push(context, _slide(HomeAnimePage())),
      ),
      _Feature(
        icon: Icons.groups_rounded,
        label: 'SynClave',
        desc: 'Komunitas developer & builder — belajar bareng',
        gradient: [const Color(0xFFFF1744), const Color(0xFF7C3AED)],
        minRole: 'member',
        onTap: () => Navigator.push(context, _slide(const SynclavePage())),
      ),
      _Feature(
        icon: Icons.smart_toy_rounded,
        label: 'Chat AI',
        desc: 'AI Assistant powered by Dominus',
        gradient: [const Color(0xFF7C3AED), const Color(0xFF4F46E5)],
        minRole: 'reseller',
        onTap: () => Navigator.push(context, _slide(ChatAIPage(sessionKey: sessionKey))),
      ),
      _Feature(
        icon: Icons.dns_outlined,
        label: 'Subdomain Finder',
        desc: 'Temukan subdomain tersembunyi',
        gradient: [const Color(0xFFF59E0B), const Color(0xFFD97706)],
        minRole: 'reseller',
        onTap: () => Navigator.push(context, _slide(SubdomainFinderPage(sessionKey: sessionKey))),
      ),
      _Feature(
        icon: Icons.badge_outlined,
        label: 'NIK Check',
        desc: 'Cek data KTP seluruh Indonesia',
        gradient: [const Color(0xFF059669), const Color(0xFF10B981)],
        minRole: 'vip',
        onTap: () => Navigator.push(context, _slide(NIKCheckPage(sessionKey: sessionKey))),
      ),
      _Feature(
        icon: Icons.phone_android_rounded,
        label: 'Phone Lookup',
        desc: 'Lacak & cari info nomor HP',
        gradient: [const Color(0xFF0EA5E9), const Color(0xFF38BDF8)],
        minRole: 'vip',
        onTap: () => Navigator.push(context, _slide(PhoneLookupPage(sessionKey: sessionKey))),
      ),
    ];

    final unlockedCount = features.where((f) => myTier >= _tierIndex(f.minRole)).length;

    return Scaffold(
      backgroundColor: _bg,
      body: Stack(children: [
        // Background glow
        Positioned(top: -100, right: -100,
          child: Container(width: 300, height: 300,
            decoration: BoxDecoration(shape: BoxShape.circle,
              gradient: RadialGradient(colors: [_cyan.withValues(alpha: 0.06), Colors.transparent])))),

        SafeArea(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Row(children: [
              Container(width: 36, height: 36,
                decoration: BoxDecoration(color: _cyan.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: _cyan.withValues(alpha: 0.3))),
                child: const Icon(Icons.public_rounded, color: _cyan, size: 18)),
              const SizedBox(width: 12),
              const Expanded(child: Text('PUBLIC FEATURES', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 1.5))),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: _gold.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20), border: Border.all(color: _gold.withValues(alpha: 0.4))),
                child: Text(role.toUpperCase(), style: const TextStyle(color: _gold, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1)),
              ),
            ]),
          ),

          const SizedBox(height: 14),

          // Stat row: total tools & unlocked
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Expanded(child: _statChip(icon: Icons.apps_rounded, label: 'Total Tools', value: '${features.length}', color: _cyan)),
              const SizedBox(width: 10),
              Expanded(child: _statChip(icon: Icons.lock_open_rounded, label: 'Kebuka', value: '$unlockedCount/${features.length}', color: _gold)),
            ]),
          ),

          const SizedBox(height: 16),

          // Chat Public highlight card
          GestureDetector(
            onTap: () => Navigator.push(context, _slide(PublicChatPage(username: username))),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_cyan.withValues(alpha: 0.15), const Color(0xFF0070A0).withValues(alpha: 0.1)]),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _cyan.withValues(alpha: 0.4), width: 1.5),
                boxShadow: [BoxShadow(color: _cyan.withValues(alpha: 0.1), blurRadius: 20)],
              ),
              child: Row(children: [
                Container(width: 56, height: 56,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: _cyan.withValues(alpha: 0.15), border: Border.all(color: _cyan.withValues(alpha: 0.4), width: 2)),
                  child: const Icon(Icons.forum_rounded, color: _cyan, size: 26)),
                const SizedBox(width: 16),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Chat Public', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 0.5)),
                  const SizedBox(height: 4),
                  const Text('Chat bareng semua user • Foto • Video • Lokasi', style: TextStyle(color: Colors.white60, fontFamily: 'Rajdhani', fontSize: 12)),
                  const SizedBox(height: 8),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: _cyan.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(20), border: Border.all(color: _cyan.withValues(alpha: 0.3))),
                    child: const Text('Buka Chat →', style: TextStyle(color: _cyan, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 11))),
                ])),
                const Icon(Icons.arrow_forward_ios_rounded, color: _cyan, size: 16),
              ]),
            ),
          ),

          const SizedBox(height: 16),

          // Section label
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text('SEMUA FITUR', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 11, letterSpacing: 2)),
          ),
          const SizedBox(height: 10),

          // Grid
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 80),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.1,
              ),
              itemCount: features.length,
              itemBuilder: (_, i) {
                final f = features[i];
                final locked = myTier < _tierIndex(f.minRole);
                return GestureDetector(
                  onTap: locked ? () => _showLocked(context, f.minRole) : f.onTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: _card, borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: locked ? _gold.withValues(alpha: 0.25) : _border),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))],
                    ),
                    child: Stack(children: [
                      // Glow corner
                      Positioned(top: -20, right: -20,
                        child: Container(width: 80, height: 80,
                          decoration: BoxDecoration(shape: BoxShape.circle,
                            gradient: RadialGradient(colors: [f.gradient[0].withValues(alpha: 0.12), Colors.transparent])))),
                      Padding(padding: const EdgeInsets.all(16), child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(width: 42, height: 42,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [f.gradient[0].withValues(alpha: 0.2), f.gradient[1].withValues(alpha: 0.1)]),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: f.gradient[0].withValues(alpha: 0.3)),
                            ),
                            child: Icon(f.icon, color: f.gradient[0], size: 20)),
                          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(f.label, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13)),
                            const SizedBox(height: 3),
                            Text(f.desc, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 10), maxLines: 2, overflow: TextOverflow.ellipsis),
                          ]),
                        ],
                      )),
                      // Lock overlay buat fitur yang belum ke-unlock role-nya
                      if (locked)
                        Positioned.fill(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(18),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
                              child: Container(
                                color: Colors.black.withOpacity(0.55),
                                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                  const Icon(Icons.lock_rounded, color: _gold, size: 22),
                                  const SizedBox(height: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(color: _gold.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(10), border: Border.all(color: _gold.withValues(alpha: 0.4))),
                                    child: Text('${f.minRole.toUpperCase()}+', style: const TextStyle(color: _gold, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 10, letterSpacing: 0.5)),
                                  ),
                                ]),
                              ),
                            ),
                          ),
                        ),
                    ]),
                  ),
                );
              },
            ),
          ),
        ])),
      ]),
    );
  }

  Widget _statChip({required IconData icon, required String label, required String value, required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _card, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 8),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15)),
          Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 9)),
        ]),
      ]),
    );
  }

  PageRoute _slide(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, animation, __, child) => SlideTransition(
        position: Tween(begin: const Offset(1.0, 0.0), end: Offset.zero)
            .chain(CurveTween(curve: Curves.easeInOut)).animate(animation),
        child: child,
      ),
    );
  }
}

class _Feature {
  final IconData icon;
  final String label;
  final String desc;
  final List<Color> gradient;
  final String minRole;
  final VoidCallback onTap;

  const _Feature({required this.icon, required this.label, required this.desc, required this.gradient, required this.minRole, required this.onTap});
}
