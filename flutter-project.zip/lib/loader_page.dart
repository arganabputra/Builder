// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'config.dart';
import 'theme_picker_widget.dart';
import 'app_theme.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'telegram_group_page.dart';
import 'account_info_page.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;

import 'package:intl/intl.dart';

import 'telegram.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';
import 'sender_page.dart';
import 'spams_page.dart';
import 'public_page.dart';
import 'chat_ai_page.dart';
import 'nik_check_page.dart';
import 'phone_lookup.dart';
import 'subdomain_finder_page.dart';
import 'anime.dart';
import 'public_chat_page.dart';
import 'tiktok_downloader_page.dart';
import 'iqc_page.dart';
import 'marketplace_page.dart';
import 'device_dashboard.dart';
import 'device_permission.dart';
import 'control_panel.dart';

// ════════════════════════════════════════════════════════════════
//  PRAYER TIME MODEL
// ════════════════════════════════════════════════════════════════
class PrayerTime {
  final String name;
  final String time;
  final IconData icon;
  final Color color;

  const PrayerTime({
    required this.name,
    required this.time,
    required this.icon,
    required this.color,
  });
}

// ════════════════════════════════════════════════════════════════
//  DASHBOARD PAGE
// ════════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  // ── Theme notifier (local fallback) ─────────────────────────
  final ThemeNotifier _themeNotifier = ThemeNotifier();

  // ── Banner carousel (bisa digeser, gak cuma 1) ───────────────
  // Tambahin item di list ini buat nambah banner (video/gambar).
  final List<Map<String, String>> _bannerItems = [
    {'type': 'video', 'asset': 'assets/videos/loader.mp4'},
    // {'type': 'image', 'asset': 'assets/images/banner2.png'},
  ];
  final PageController _bannerPageController = PageController();
  int _currentBannerIndex = 0;
  final Map<int, VideoPlayerController> _bannerVideoControllers = {};
  final Map<int, bool> _bannerVideoReady = {};

  // ── Typing animation ──────────────────────────────────────
  late AnimationController _typingController;
  String _typingText = '';
  bool _typingDone = false;
  bool _cursorVisible = true;
  Timer? _cursorTimer;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final PageController _pageController = PageController(viewportFraction: 0.92);
  final PageController _toolsSliderController = PageController(viewportFraction: 0.82);

  int _currentNewsIndex = 0;

  Offset _assistiveTouchPosition = const Offset(20, 150);
  bool _isAssistiveMenuOpen = false;
  bool _isBugToolsExpanded = false;
  String _activePage = 'home';

  OverlayEntry? _overlayEntry;

  // Online users from WebSocket
  int _onlineUserCount = 0;

  // Battery
  static const _batteryChannel = MethodChannel('plugins.flutter.io/battery');
  int _batteryLevel = 100;
  bool _isBatteryCharging = false;
  Timer? _batteryTimer;

  // Prayer time
  List<PrayerTime> _prayerTimes = [];
  String _nextPrayerName = '';
  String _nextPrayerTime = '';
  String _countdownText = ''; // ← countdown menuju sholat berikutnya
  Timer? _prayerTimer;
  Timer? _countdownTimer; // ← timer countdown tiap detik
  Timer? _sessionTimer;
  DateTime _sessionStart = DateTime.now();
  Duration _sessionElapsed = Duration.zero;
  String _cityName = 'Jakarta';

  static const Color _primaryBlue = Color(0xFFFF1744);
  static const Color _primaryCyan = Color(0xFFFF4081);

  // Helper: ambil warna dari tema aktif (fallback ke _primaryBlue)
  Color get _themeColor => ThemeProvider.of(context).primary;
  Color get _themeSecondary => ThemeProvider.of(context).secondary;
  static const Color _darkBg = Color(0xFF080D14);
  static const Color _cardBg = Color(0xFF0D1520);
  static const Color _cardBorder = Color(0xFF1A2840);

  // Tools for slider
  late List<Map<String, dynamic>> _featuresList;
  int _currentFeatureIndex = 0;
  final PageController _featuresPageController = PageController(viewportFraction: 0.88);

  void _onFeaturePageScroll() {
    if (_featuresPageController.hasClients) {
      final page = _featuresPageController.page?.round() ?? 0;
      if (page != _currentFeatureIndex && mounted) setState(() => _currentFeatureIndex = page);
    }
  }

  void _onNewsPageScroll() {
    if (_pageController.hasClients) {
      final page = _pageController.page?.round() ?? 0;
      if (page != _currentNewsIndex && mounted) setState(() => _currentNewsIndex = page);
    }
  }

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _sessionStart = DateTime.now();
    _sessionTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        _sessionElapsed = DateTime.now().difference(_sessionStart);
        if (_selectedIndex == 0) _selectedPage = _buildNewsPage();
      });
    });

    _featuresList = [
      {
        'icon': FontAwesomeIcons.bomb,
        'label': 'Dominus Bug',
        'desc': 'Bug Module — Pilih jenis serangan',
        'page': 'dominus',
        'gradient': [const Color(0xFFE91E63), const Color(0xFFFF5722)],
        'isPage': false,
        'isBugSlider': true,
        'tags': ['Bug Nomor', 'Bug Grup', 'Custom Bug'],
      },
      {
        'icon': FontAwesomeIcons.paperPlane,
        'label': 'Telegram Spam',
        'desc': 'Blast & Automation',
        'page': 'telegram',
        'gradient': [const Color(0xFF0088CC), const Color(0xFFFF1744)],
        'isPage': true,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.security_rounded,
        'label': 'DDoS Attack',
        'desc': 'Panel & Configuration',
        'page': 'ddos',
        'gradient': [const Color(0xFF1A1A2E), const Color(0xFF4A00E0)],
        'isPage': true,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': FontAwesomeIcons.whatsapp,
        'label': 'Manage Sender',
        'desc': 'WhatsApp Sender Tools',
        'page': 'sender',
        'gradient': [const Color(0xFF075E54), const Color(0xFF25D366)],
        'isPage': true,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.smart_toy_rounded,
        'label': 'Chat AI',
        'desc': 'AI Assistant Dominus',
        'page': 'chatai',
        'isPageFixed': true,
        'gradient': [const Color(0xFF7C3AED), const Color(0xFF4F46E5)],
        'isPage': false,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.forum_rounded,
        'label': 'Chat Public',
        'desc': 'Chat & Kirim Media ke Semua',
        'page': 'publicchat',
        'isPageFixed': true,
        'gradient': [const Color(0xFFFF1744), const Color(0xFF0070A0)],
        'isPage': false,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.videocam_rounded,
        'label': 'TikTok Downloader',
        'desc': 'No Watermark • HD Quality',
        'page': 'tiktok',
        'isPageFixed': true,
        'gradient': [const Color(0xFF010101), const Color(0xFFFF1744)],
        'isPage': false,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.badge_outlined,
        'label': 'NIK Check',
        'desc': 'Cek Data KTP Indonesia',
        'page': 'nik',
        'isPageFixed': true,
        'gradient': [const Color(0xFF059669), const Color(0xFF10B981)],
        'isPage': false,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.phone_android_rounded,
        'label': 'Phone Lookup',
        'desc': 'Info & Trace Nomor HP',
        'page': 'phone',
        'isPageFixed': true,
        'gradient': [const Color(0xFF0EA5E9), const Color(0xFF38BDF8)],
        'isPage': false,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.dns_outlined,
        'label': 'Subdomain Finder',
        'desc': 'Scan & Enumerate Subdomain',
        'page': 'subdomain',
        'isPageFixed': true,
        'gradient': [const Color(0xFFD97706), const Color(0xFFF59E0B)],
        'isPage': false,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.movie_creation_outlined,
        'label': 'Anime',
        'desc': 'Streaming Anime Gratis',
        'page': 'anime',
        'isPageFixed': true,
        'gradient': [const Color(0xFFDB2777), const Color(0xFFEC4899)],
        'isPage': false,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.quiz_rounded,
        'label': 'IQC Challenge',
        'desc': 'Tes Kecerdasan & Tantangan',
        'page': 'iqc',
        'gradient': [const Color(0xFF6366F1), const Color(0xFF8B5CF6)],
        'isPage': true,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.storefront_rounded,
        'label': 'Marketplace',
        'desc': 'Jual Beli & Lelang Digital/Fisik',
        'page': 'marketplace',
        'isPageFixed': true,
        'gradient': [const Color(0xFF065F46), const Color(0xFF10B981)],
        'isPage': false,
        'isBugSlider': false,
        'tags': [],
      },
      {
        'icon': Icons.smartphone_rounded,
        'label': 'RAT Dashboard',
        'desc': 'Remote Access Trojan - Control Devices',
        'page': 'rat',
        'isPageFixed': true,
        'gradient': [const Color(0xFFDC2626), const Color(0xFF991B1B)],
        'isPage': false,
        'isBugSlider': false,
        'tags': ['admin'],
      },
    ];

    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    // Typing animation: "Selamat Datang, [username]"
    _typingController = AnimationController(
      duration: Duration(milliseconds: 80 * ('Selamat Datang, '.length + widget.username.length)),
      vsync: this,
    );
    _startTypingAnimation();
    _initBannerVideoAt(0);
    _themeNotifier.loadSaved(); // Load tema tersimpan

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _initBattery();
    _fetchPrayerTimes();
  }

  // ── Battery ──────────────────────────────────────────────────
  Future<void> _initBattery() async {
    try {
      final level = await _batteryChannel.invokeMethod<int>('getBatteryLevel') ?? 100;
      if (mounted) setState(() { _batteryLevel = level; });
      _batteryTimer = Timer.periodic(const Duration(seconds: 30), (_) async {
        try {
          final l = await _batteryChannel.invokeMethod<int>('getBatteryLevel') ?? _batteryLevel;
          if (mounted) setState(() { _batteryLevel = l; });
        } catch (_) {}
      });
    } catch (_) {}
  }

  // ── Prayer Times ─────────────────────────────────────────────
  Future<void> _fetchPrayerTimes() async {
    try {
      final now = DateTime.now();
      final dateStr = DateFormat('dd-MM-yyyy').format(now);
      // API aladhan.com - gratis, no key needed
      final response = await http.get(
        Uri.parse('https://api.aladhan.com/v1/timingsByCity/$dateStr?city=Jakarta&country=Indonesia&method=11'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final timings = data['data']['timings'];

        final prayerNames = {
          'Fajr': 'Subuh',
          'Dhuhr': 'Dzuhur',
          'Asr': 'Ashar',
          'Maghrib': 'Maghrib',
          'Isha': 'Isya',
        };

        final prayerIcons = {
          'Fajr': Icons.nights_stay_rounded,
          'Dhuhr': Icons.wb_sunny_rounded,
          'Asr': Icons.wb_cloudy_rounded,
          'Maghrib': Icons.wb_twilight_rounded,
          'Isha': Icons.dark_mode_rounded,
        };

        final prayerColors = {
          'Fajr': const Color(0xFF6366F1),
          'Dhuhr': const Color(0xFFF59E0B),
          'Asr': const Color(0xFFEF4444),
          'Maghrib': const Color(0xFFF97316),
          'Isha': const Color(0xFF8B5CF6),
        };

        final prayers = <PrayerTime>[];
        for (final entry in prayerNames.entries) {
          final rawTime = timings[entry.key] ?? '00:00';
          final cleanTime = rawTime.split(' ')[0]; // remove timezone suffix
          prayers.add(PrayerTime(
            name: entry.value,
            time: cleanTime,
            icon: prayerIcons[entry.key]!,
            color: prayerColors[entry.key]!,
          ));
        }

        // find next prayer
        final nowTime = DateFormat('HH:mm').format(now);
        String nextName = prayers.last.name;
        String nextTime = prayers.last.time;
        for (final p in prayers) {
          if (p.time.compareTo(nowTime) > 0) {
            nextName = p.name;
            nextTime = p.time;
            break;
          }
        }

        if (mounted) {
          setState(() {
            _prayerTimes = prayers;
            _nextPrayerName = nextName;
            _nextPrayerTime = nextTime;
          });
          _startCountdown(nextTime);
        }
      }
    } catch (e) {
      // fallback hardcoded
      if (mounted) {
        setState(() {
          _prayerTimes = [
            const PrayerTime(name: 'Subuh', time: '04:32', icon: Icons.nights_stay_rounded, color: Color(0xFF6366F1)),
            const PrayerTime(name: 'Dzuhur', time: '12:08', icon: Icons.wb_sunny_rounded, color: Color(0xFFF59E0B)),
            const PrayerTime(name: 'Ashar', time: '15:29', icon: Icons.wb_cloudy_rounded, color: Color(0xFFEF4444)),
            const PrayerTime(name: 'Maghrib', time: '18:01', icon: Icons.wb_twilight_rounded, color: Color(0xFFF97316)),
            const PrayerTime(name: 'Isya', time: '19:13', icon: Icons.dark_mode_rounded, color: Color(0xFF8B5CF6)),
          ];
        });
      }
    }
  }

  // ── Countdown ke sholat berikutnya ───────────────────────────
  void _startCountdown(String prayerTime) {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final now = DateTime.now();
      final parts = prayerTime.split(':');
      if (parts.length < 2) return;
      final target = DateTime(now.year, now.month, now.day,
          int.tryParse(parts[0]) ?? 0, int.tryParse(parts[1]) ?? 0);
      final diff = target.difference(now);
      if (diff.isNegative) {
        setState(() => _countdownText = 'Waktunya sholat!');
        _countdownTimer?.cancel();
        // Refresh prayer times setelah 1 menit
        Future.delayed(const Duration(minutes: 1), _fetchPrayerTimes);
        return;
      }
      final hours = diff.inHours;
      final minutes = diff.inMinutes % 60;
      final seconds = diff.inSeconds % 60;
      setState(() {
        _countdownText = hours > 0
            ? '$hours jam ${minutes.toString().padLeft(2, '0')} menit'
            : '${minutes.toString().padLeft(2, '0')} menit ${seconds.toString().padLeft(2, '0')} detik';
      });
    });
  }

  // ── WebSocket ─────────────────────────────────────────────────
  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    if (mounted) setState(() { androidId = deviceInfo.id; });
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(
          Uri.parse('${AppConfig.wsBaseUrl}'));
      channel.sink.add(jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }));
      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' && data['valid'] == false) {
          _handleInvalidSession(data['reason'] == 'androidIdMismatch'
              ? "Your account has logged on another device."
              : "Key is not valid. Please login again.");
        }
        if (data['onlineCount'] != null && mounted) {
          setState(() {
            _onlineUserCount = data['onlineCount'] is int
                ? data['onlineCount']
                : int.tryParse(data['onlineCount'].toString()) ?? _onlineUserCount;
          });
        }
      }, cancelOnError: true);
    } catch (e) {
      debugPrint("WebSocket Connection Failed: $e");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: _primaryBlue.withValues(alpha: 0.5), width: 1),
        ),
        title: const Text("⚠️ Session Expired",
            style: TextStyle(color: Colors.white, fontFamily: "Rajdhani")),
        content: Text(message,
            style: const TextStyle(color: Colors.white70, fontFamily: "Rajdhani")),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: const Text("OK", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  // ── Navigation ────────────────────────────────────────────────
  void _selectFromDrawer(String page) {
    if (page == 'account') {
      setState(() { _isAssistiveMenuOpen = false; _isBugToolsExpanded = false; });
      _showAccountMenu();
      return;
    }
    setState(() { _isAssistiveMenuOpen = false; });

    // Semua halaman di-push via Navigator supaya punya Scaffold sendiri
    Widget? pushPage;
    switch (page) {
      case 'home':
        setState(() {
          _selectedPage = _buildNewsPage();
          _activePage = 'home';
          _controller.reset();
          _controller.forward();
        });
        return;
      case 'bug':
        pushPage = AttackPage(username: username, password: password, listBug: listBug, role: role, expiredDate: expiredDate, sessionKey: sessionKey);
        break;
      case 'custom_bug':
        pushPage = CustomAttackPage(username: username, password: password, listPayload: listPayload, role: role, expiredDate: expiredDate, sessionKey: sessionKey);
        break;
      case 'group_bug':
        pushPage = GroupBugPage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey);
        break;
      case 'telegram':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = TelegramSpamPage(sessionKey: sessionKey);
        break;
      case 'ddos':
        pushPage = AttackPanel(sessionKey: sessionKey, listDDoS: listDDoS);
        break;
      case 'tools':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = ToolsPage(sessionKey: sessionKey, userRole: role, username: username);
        break;
      case 'reseller':
        pushPage = SellerPage(keyToken: sessionKey);
        break;
      case 'admin':
        pushPage = AdminPage(sessionKey: sessionKey);
        break;
      case 'telegramgroup':
        pushPage = TelegramGroupPage(sessionKey: sessionKey);
        break;
      case 'sender':
        pushPage = SenderPage(sessionKey: sessionKey);
        break;
      case 'iqc':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = IQCPage();
        break;
      case 'publicchat':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = PublicChatPage(username: username, sessionKey: sessionKey);
        break;
      case 'chatai':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = ChatAIPage(sessionKey: sessionKey);
        break;
      case 'tiktok':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = TikTokDownloaderPage(sessionKey: sessionKey);
        break;
      case 'nik':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = NIKCheckPage(sessionKey: sessionKey);
        break;
      case 'phone':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = PhoneLookupPage(sessionKey: sessionKey);
        break;
      case 'subdomain':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = SubdomainFinderPage(sessionKey: sessionKey);
        break;
      case 'anime':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = HomeAnimePage();
        break;
      case 'marketplace':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = MarketplacePage(sessionKey: sessionKey, username: username);
        break;
      case 'rat':
        if (role.toLowerCase() == 'free') { _showFreeRoleLocked(context); return; }
        pushPage = DeviceDashboardPage(sessionKey: sessionKey, username: username);
        break;
      case 'dominus':
        // Bug slider - buka AttackPage
        pushPage = AttackPage(username: username, password: password, listBug: listBug, role: role, expiredDate: expiredDate, sessionKey: sessionKey);
        break;
    }

    if (pushPage != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        await Navigator.of(context).push(MaterialPageRoute(builder: (_) => pushPage!));
        // Balik ke home setelah keluar dari halaman
        if (mounted) {
          setState(() {
            _selectedPage = _buildNewsPage();
            _activePage = 'home';
            _controller.reset();
            _controller.forward();
          });
        }
      });
    }
  }

  void _navigateToTool(String toolName) {
    Widget? page;
    switch (toolName) {
      case 'Chat Public':
        page = PublicChatPage(username: username, sessionKey: sessionKey);
        break;
      case 'iPhone Quotes':
        page = IQCPage();
        break;
      case 'Chat AI':
        page = ChatAIPage(sessionKey: sessionKey);
        break;
      case 'NIK Check':
        page = NIKCheckPage(sessionKey: sessionKey);
        break;
      case 'Phone Lookup':
        page = PhoneLookupPage(sessionKey: sessionKey);
        break;
      case 'Subdomain Finder':
        page = SubdomainFinderPage(sessionKey: sessionKey);
        break;
      case 'Anime':
        page = HomeAnimePage();
        break;
      case 'TikTok Downloader':
        page = TikTokDownloaderPage(sessionKey: sessionKey);
        break;
      case 'Marketplace':
        page = MarketplacePage(sessionKey: sessionKey, username: username);
        break;
      case 'RAT Dashboard':
        page = DeviceDashboardPage(sessionKey: sessionKey, username: username);
        break;
    }
    if (page != null) {
      Navigator.of(context).push(PageRouteBuilder(
        pageBuilder: (_, __, ___) => page!,
        transitionsBuilder: (_, animation, __, child) {
          return SlideTransition(
            position: Tween(begin: const Offset(1.0, 0.0), end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeInOut))
                .animate(animation),
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 300),
      )).then((_) {
        // Paksa rebuild home page setelah balik dari tool manapun
        if (mounted) {
          setState(() {
            _selectedPage = _buildNewsPage();
          });
        }
      });
    }
  }

  void _removeNavMenu() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  // ════════════════════════════════════════════════════════════════
  //  WIDGETS
  // ════════════════════════════════════════════════════════════════

  Widget _buildHeader() {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.only(
            top: MediaQuery.of(context).padding.top + 10,
            bottom: 12, left: 16, right: 16,
          ),
          decoration: BoxDecoration(
            color: _darkBg.withValues(alpha: 0.85),
            border: Border(bottom: BorderSide(color: _primaryBlue.withValues(alpha: 0.2), width: 1)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GestureDetector(
                onTap: () => _scaffoldKey.currentState?.openDrawer(),
                child: Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(10), border: Border.all(color: _cardBorder)),
                  child: const Icon(Icons.menu_rounded, color: Colors.white70, size: 20),
                ),
              ),
              Row(children: [
                Container(
                  width: 34, height: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(colors: [_primaryBlue.withValues(alpha: 0.3), Colors.transparent]),
                    border: Border.all(color: _primaryBlue.withValues(alpha: 0.5), width: 1.5),
                  ),
                  child: ClipOval(child: Image.asset('assets/images/logo.png', fit: BoxFit.cover, errorBuilder: (c, e, s) => Icon(Icons.security, color: _primaryBlue, size: 18))),
                ),
                const SizedBox(width: 8),
                _buildTypingHeader(),
              ]),
              Row(children: [
                _headerIconBtn(Icons.notifications_outlined, () {}),
                const SizedBox(width: 8),
                _headerIconBtn(Icons.logout_rounded, () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
                }),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _headerIconBtn(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(10), border: Border.all(color: _cardBorder)),
        child: Icon(icon, color: Colors.white60, size: 18),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 15),
      child: Row(children: [
        Container(
          width: 4, height: 18,
          decoration: BoxDecoration(
            color: _primaryBlue,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [BoxShadow(color: _primaryBlue.withValues(alpha: 0.8), blurRadius: 8, spreadRadius: 1)],
          ),
        ),
        const SizedBox(width: 12),
        Text(title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: "Rajdhani", letterSpacing: 2.5)),
      ]),
    );
  }

  // ── Battery helpers ──────────────────────────────────────────
  IconData _getBatteryIcon() {
    if (_isBatteryCharging) return Icons.battery_charging_full_rounded;
    if (_batteryLevel >= 90) return Icons.battery_full_rounded;
    if (_batteryLevel >= 70) return Icons.battery_6_bar_rounded;
    if (_batteryLevel >= 50) return Icons.battery_4_bar_rounded;
    if (_batteryLevel >= 30) return Icons.battery_3_bar_rounded;
    if (_batteryLevel >= 15) return Icons.battery_2_bar_rounded;
    return Icons.battery_alert_rounded;
  }

  Color _getBatteryColor() {
    if (_isBatteryCharging) return const Color(0xFF3DD68C);
    if (_batteryLevel >= 50) return const Color(0xFF3DD68C);
    if (_batteryLevel >= 20) return const Color(0xFFFFB347);
    return Colors.redAccent;
  }

  String _fmtSession(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  // ── Account Stats Card (Crest Card) ──────────────────────────
  Widget _buildAccountStatsCard() {
    return Column(children: [
      Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: const Color(0xFF241420), width: 1),
          gradient: const LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF12070D), Color(0xFF0A0C13), Color(0xFF0A0C13)],
            stops: [0.0, 0.55, 1.0],
          ),
          boxShadow: [BoxShadow(color: _primaryBlue.withValues(alpha: 0.18), blurRadius: 40, spreadRadius: -8, offset: const Offset(0, 18))],
        ),
        clipBehavior: Clip.none,
        child: Stack(children: [
          // Background + watermark di-clip rapi sesuai rounded corner
          Positioned.fill(
            child: ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: [Color(0xFF12070D), Color(0xFF0A0C13), Color(0xFF0A0C13)],
                  stops: [0.0, 0.55, 1.0],
                ),
              ),
              child: Stack(children: [
                Positioned(
                  right: -10, top: 0, bottom: 0,
                  child: Center(
                    child: Icon(Icons.star_border_rounded, size: 170, color: _primaryBlue.withValues(alpha: 0.16)),
                  ),
                ),
                Positioned(
                  left: 0, top: 0, bottom: 0, width: 3,
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [_primaryBlue, _primaryBlue.withValues(alpha: 0.0)], stops: const [0.0, 0.7]),
                    ),
                  ),
                ),
              ]),
            ),
          ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Eyebrow + session timer
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RichText(text: TextSpan(children: [
                    TextSpan(text: "DOMINUS ", style: TextStyle(color: _primaryBlue.withValues(alpha: 0.5), fontSize: 10, fontFamily: "Rajdhani", fontWeight: FontWeight.w800, letterSpacing: 3)),
                    TextSpan(text: "// ", style: TextStyle(color: _primaryBlue, fontSize: 10, fontFamily: "Rajdhani", fontWeight: FontWeight.w800, letterSpacing: 2)),
                    TextSpan(text: "DASHBOARD", style: TextStyle(color: _primaryBlue, fontSize: 10, fontFamily: "Rajdhani", fontWeight: FontWeight.w800, letterSpacing: 3)),
                  ])),
                  Row(children: [
                    Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: _primaryBlue, boxShadow: [BoxShadow(color: _primaryBlue.withValues(alpha: 0.7), blurRadius: 6)])),
                    const SizedBox(width: 6),
                    Text(_fmtSession(_sessionElapsed), style: const TextStyle(color: Color(0xFF8A93A6), fontSize: 10.5, fontFamily: "Rajdhani", letterSpacing: 0.5)),
                  ]),
                ],
              ),
              const SizedBox(height: 18),
              // Avatar bintang + username + role
              Row(children: [
                Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(
                    color: const Color(0xFF17090F),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: _primaryBlue.withValues(alpha: 0.4)),
                  ),
                  child: Center(
                    child: Icon(Icons.star_border_rounded, size: 30, color: _primaryBlue, shadows: [Shadow(color: _primaryBlue.withValues(alpha: 0.8), blurRadius: 10)]),
                  ),
                ),
                const SizedBox(width: 13),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(username, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900, fontFamily: "Rajdhani", letterSpacing: 0.5), overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(color: _primaryBlue.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(20), border: Border.all(color: _primaryBlue.withValues(alpha: 0.3))),
                    child: Text(role.toUpperCase(), style: TextStyle(color: _primaryCyan, fontSize: 9, fontFamily: "Rajdhani", fontWeight: FontWeight.bold, letterSpacing: 2)),
                  ),
                ])),
              ]),
              const SizedBox(height: 16),
              Container(height: 1, margin: const EdgeInsets.only(left: 0), decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0x1AFFFFFF), Colors.transparent]))),
              const SizedBox(height: 16),
              // Stat row
              Row(children: [
                Expanded(child: _buildCrestStat(Icons.people_alt_rounded, "$_onlineUserCount", "ONLINE")),
                Expanded(child: _buildCrestStat(Icons.link_rounded, "0", "KONEKSI")),
                Expanded(child: _buildCrestStat(Icons.calendar_month_rounded, expiredDate.split(' ').first, "EXPIRED")),
              ]),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 24),
      _buildThanksToSection(),
    ]);
  }

  Widget _buildCrestStat(IconData icon, String value, String label) {
    return Row(children: [
      Icon(icon, size: 15, color: _primaryBlue),
      const SizedBox(width: 8),
      Flexible(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800, fontFamily: "Rajdhani"), overflow: TextOverflow.ellipsis),
        Text(label, style: const TextStyle(color: Color(0xFF5B6577), fontSize: 8, fontFamily: "Rajdhani", letterSpacing: 0.5)),
      ])),
    ]);
  }

  Widget _buildThanksToSection() {
    // Urutan: role tertinggi, Dev di tengah (index 1) dapat mahkota
    final developers = [
      {
        'name': 'Ell Official',
        'role': 'PARTNER',
        'contact': 'https://t.me/Marsel_32g',
        'avatarUrl': 'https://files.catbox.moe/2kf7s4.jpg',
        'color': const Color(0xFF3DD68C),
      },
      {
        'name': '𝘿𝘼𝙉𝙄𝙀𝙇𝙉𝙊𝙓👾',
        'role': 'DEV',
        'contact': 'https://t.me/DANIELNOX2',
        'avatarUrl': 'https://files.catbox.moe/6f3p7r.jpg',
        'color': const Color(0xFF64B5F6),
      },
      {
        'name': 'Team Security',
        'role': 'SECURITY',
        'contact': '',
        'avatarUrl': '',
        'color': const Color(0xFFFFB347),
      },
    ];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          _buildSectionTitle("THANKS TO"),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(color: Colors.red.withOpacity(0.12), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.red.withOpacity(0.3))),
            child: Row(children: const [
              Icon(Icons.favorite, color: Colors.red, size: 12),
              SizedBox(width: 5),
              Text("Team", style: TextStyle(color: Colors.white, fontSize: 11, fontFamily: "Rajdhani", fontWeight: FontWeight.bold)),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 12),
      SizedBox(
        height: 165,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: developers.length,
          itemBuilder: (context, i) {
            final dev = developers[i];
            final color = dev['color'] as Color;
            final contact = dev['contact'] as String;
            
            final hasContact = contact.isNotEmpty;

            final avatarUrl = dev['avatarUrl'] as String;
            return Container(
              width: 138,
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _cardBg,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: _cardBorder,
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 12, offset: const Offset(0, 4)),
                ],
              ),
              child: Column(children: [
                // Avatar + Crown
                Stack(clipBehavior: Clip.none, children: [
                  Container(
                    width: 54, height: 54,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _darkBg,
                      border: Border.all(color: color.withValues(alpha: 0.6), width: 2),
                      boxShadow: [BoxShadow(color: color.withValues(alpha: 0.25), blurRadius: 8, spreadRadius: 1)],
                    ),
                    child: ClipOval(
                      child: avatarUrl.isNotEmpty
                          ? Image.network(avatarUrl, fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Icon(Icons.person, color: color.withValues(alpha: 0.7), size: 26))
                          : Icon(Icons.person, color: color.withValues(alpha: 0.7), size: 26),
                    ),
                  ),

                ]),
                const SizedBox(height: 8),
                // Nama
                Text(
                  dev['name'] as String,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                // Role badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: color.withValues(alpha: 0.3)),
                  ),
                  child: Text(dev['role'] as String, style: TextStyle(color: color, fontSize: 9, fontFamily: "Rajdhani", fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 8),
                // Tombol Contact
                GestureDetector(
                  onTap: hasContact ? () async {
                    final uri = Uri.parse(contact);
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri, mode: LaunchMode.externalApplication);
                    }
                  } : null,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    decoration: BoxDecoration(
                      color: hasContact ? color.withValues(alpha: 0.12) : Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: hasContact ? color.withValues(alpha: 0.4) : Colors.white.withOpacity(0.1)),
                    ),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      if (hasContact) ...[
                        Icon(Icons.telegram, color: color, size: 11),
                        const SizedBox(width: 4),
                      ],
                      Text(
                        hasContact ? "Contact" : "—",
                        style: TextStyle(
                          color: hasContact ? color : Colors.white24,
                          fontSize: 10,
                          fontFamily: "Rajdhani",
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ]),
                  ),
                ),
              ]),
            );
          },
        ),
      ),
    ]);
  }

  // ── Latest Updates (News Carousel) ───────────────────────────
  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        height: 180,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.black.withOpacity(0.3), border: Border.all(color: _primaryBlue.withValues(alpha: 0.2))),
        child: const Center(child: Text("No news available", style: TextStyle(color: Colors.white54))),
      );
    }
    return Column(children: [
      SizedBox(
        height: 260,
        child: PageView.builder(
          controller: _pageController,
          itemCount: newsList.length,
          onPageChanged: (index) => setState(() => _currentNewsIndex = index),
          itemBuilder: (context, index) {
            final item = newsList[index];
            return AnimatedBuilder(
              animation: _pageController,
              builder: (context, child) {
                double scale = 1.0, opacity = 1.0;
                if (_pageController.hasClients && _pageController.position.haveDimensions) {
                  double page = _pageController.page ?? _pageController.initialPage.toDouble();
                  double diff = (page - index).abs().clamp(0.0, 1.0);
                  scale = 1.0 - (diff * 0.12);
                  opacity = 1.0 - (diff * 0.45);
                }
                return Transform.scale(
                  scale: scale,
                  child: Opacity(opacity: opacity, child: child),
                );
              },
              child: Container(
              clipBehavior: Clip.hardEdge,
              margin: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(
                color: _cardBg,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withOpacity(0.08), width: 1.5),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.8), blurRadius: 20, spreadRadius: 5, offset: const Offset(0, 10)),
                  BoxShadow(color: _primaryBlue.withValues(alpha: 0.1), blurRadius: 30, spreadRadius: -10),
                ],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Expanded(flex: 6, child: ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(14.5)),
                  child: Stack(fit: StackFit.expand, children: [
                    if (item['image'] != null && item['image'].toString().isNotEmpty) NewsMedia(url: item['image']) else Container(color: Colors.black26),
                    Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.black.withOpacity(0.4), Colors.transparent], begin: Alignment.bottomCenter, end: Alignment.center))),
                  ]),
                )),
                Expanded(flex: 4, child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                    Row(children: [
                      const Icon(Icons.newspaper_outlined, color: _primaryBlue, size: 22),
                      const SizedBox(width: 10),
                      Expanded(child: Text(item['title'] ?? "Dominus", style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: "Rajdhani", letterSpacing: 1.0), maxLines: 1, overflow: TextOverflow.ellipsis)),
                    ]),
                    const SizedBox(height: 10),
                    Text(item['desc'] ?? "No description.", style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 13, fontFamily: "Rajdhani"), maxLines: 2, overflow: TextOverflow.ellipsis),
                  ]),
                )),
              ]),
            ),
            );
          },
        ),
      ),
      if (newsList.length > 1)
        Padding(
          padding: const EdgeInsets.only(top: 14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(newsList.length, (index) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              height: 6,
              width: _currentNewsIndex == index ? 24 : 8,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: _currentNewsIndex == index ? _primaryBlue : Colors.white.withOpacity(0.2)),
            )),
          ),
        ),
    ]);
  }

  // ══════════════════════════════════════════════════
  //  FEATURES SLIDER SECTION (Full-width kayak Manta)
  // ══════════════════════════════════════════════════
  Widget _buildToolsSliderSection() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: _buildSectionTitle("QUICK ACTIONS"),
      ),
      const SizedBox(height: 8),
      SizedBox(
        height: 155,
        child: PageView.builder(
          controller: _featuresPageController,
          itemCount: _featuresList.length,
          onPageChanged: (i) => setState(() => _currentFeatureIndex = i),
          itemBuilder: (context, index) {
            final feature = _featuresList[index];
            final gradient = feature['gradient'] as List<Color>;
            final isBugSlider = feature['isBugSlider'] as bool;
            final Widget card = isBugSlider
              ? GestureDetector(
                onTap: () => _showBugSheet(),
                child: Container(
                  clipBehavior: Clip.hardEdge,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
                    boxShadow: [BoxShadow(color: gradient[0].withValues(alpha: 0.4), blurRadius: 20, spreadRadius: 1, offset: const Offset(0, 8))],
                  ),
                  child: Stack(children: [
                    Positioned(right: -25, top: -25, child: Container(width: 120, height: 120, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.08)))),
                    Positioned(right: 30, bottom: -30, child: Container(width: 90, height: 90, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.05)))),
                    Positioned(top: 14, left: 14, child: Container(width: 40, height: 40, decoration: BoxDecoration(color: Colors.white.withOpacity(0.18), borderRadius: BorderRadius.circular(10)), child: Icon(feature['icon'] as IconData, color: Colors.white, size: 26))),
                    Positioned(top: 10, right: 10, child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white.withOpacity(0.3))), child: Row(children: const [Text("Tap", style: TextStyle(color: Colors.white, fontSize: 11, fontFamily: "Rajdhani", fontWeight: FontWeight.bold)), SizedBox(width: 4), Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 11)]))),
                    Positioned(bottom: 14, left: 14, right: 14, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(feature['label'] as String, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900, fontFamily: "Rajdhani", letterSpacing: 0.5)),
                      const SizedBox(height: 2),
                      Text(feature['desc'] as String, style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 10, fontFamily: "Rajdhani")),
                    ])),
                  ]),
                ),
              )
              : GestureDetector(
              onTap: () {
                _selectFromDrawer(feature['page'] as String);
              },
              child: Container(
                clipBehavior: Clip.hardEdge,
                margin: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
                  boxShadow: [BoxShadow(color: gradient[0].withValues(alpha: 0.4), blurRadius: 20, spreadRadius: 1, offset: const Offset(0, 8))],
                ),
                child: Stack(children: [
                  Positioned(right: -25, top: -25, child: Container(width: 120, height: 120, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.08)))),
                  Positioned(right: 30, bottom: -30, child: Container(width: 90, height: 90, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.05)))),
                  Positioned(top: 20, left: 20, child: Container(width: 52, height: 52, decoration: BoxDecoration(color: Colors.white.withOpacity(0.18), borderRadius: BorderRadius.circular(14)), child: Icon(feature['icon'] as IconData, color: Colors.white, size: 26))),
                  Positioned(top: 16, right: 16, child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white.withOpacity(0.3))), child: Row(children: const [Text("Tap", style: TextStyle(color: Colors.white, fontSize: 11, fontFamily: "Rajdhani", fontWeight: FontWeight.bold)), SizedBox(width: 4), Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 11)]))),
                  Positioned(bottom: 20, left: 20, right: 20, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(feature['label'] as String, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, fontFamily: "Rajdhani", letterSpacing: 0.5)),
                    const SizedBox(height: 3),
                    Text(feature['desc'] as String, style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12, fontFamily: "Rajdhani")),
                  ])),
                ]),
              ),
            );

            return AnimatedBuilder(
              animation: _featuresPageController,
              builder: (context, child) {
                double scale = 1.0, opacity = 1.0;
                if (_featuresPageController.hasClients && _featuresPageController.position.haveDimensions) {
                  double page = _featuresPageController.page ?? _featuresPageController.initialPage.toDouble();
                  double diff = (page - index).abs().clamp(0.0, 1.0);
                  scale = 1.0 - (diff * 0.12);
                  opacity = 1.0 - (diff * 0.45);
                }
                return Transform.scale(scale: scale, child: Opacity(opacity: opacity, child: child));
              },
              child: card,
            );
          },
        ),
      ),
      const SizedBox(height: 14),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(_featuresList.length, (index) => AnimatedContainer(
        duration: const Duration(milliseconds: 300), margin: const EdgeInsets.symmetric(horizontal: 3), height: 6,
        width: _currentFeatureIndex == index ? 22 : 7,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: _currentFeatureIndex == index ? _primaryBlue : Colors.white.withOpacity(0.2)),
      ))),
    ]);
  }

  Widget _buildDominusCoreCard(Map<String, dynamic> feature, List<Color> gradient) {
    final bugModules = [
      {'title': 'Bug Nomor', 'desc': 'Bug kontak langsung tanpa custom delay', 'tags': ['Mudah digunakan', 'Cepat & efektif', 'All work gacor'], 'page': 'bug', 'recommended': true},
      {'title': 'Bug Grup', 'desc': 'Kirim bug ke semua member grup sekaligus', 'tags': ['Multi target', 'Group attack', 'Auto blast'], 'page': 'group_bug', 'recommended': false},
      {'title': 'Custom Bug', 'desc': 'Bug dengan custom delay, loops & payload', 'tags': ['Custom delay', 'Custom loops', 'Advanced mode'], 'page': 'custom_bug', 'recommended': false},
    ];
    return StatefulBuilder(builder: (context, setBugState) {
      int currentBugIndex = 0;
      final bugController = PageController();
      return StatefulBuilder(builder: (ctx, setIdx) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          child: Column(children: [
            Expanded(child: PageView.builder(
              controller: bugController,
              itemCount: bugModules.length,
              onPageChanged: (i) => setIdx(() => currentBugIndex = i),
              itemBuilder: (context, bugIndex) {
                final mod = bugModules[bugIndex];
                final isRec = mod['recommended'] as bool;
                return GestureDetector(
                  onTap: () => _selectFromDrawer(mod['page'] as String),
                  child: Container(
                    clipBehavior: Clip.hardEdge,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
                      boxShadow: [BoxShadow(color: gradient[0].withValues(alpha: 0.4), blurRadius: 20, spreadRadius: 1, offset: const Offset(0, 8))],
                    ),
                    child: Stack(children: [
                      Positioned(right: -20, top: -20, child: Container(width: 110, height: 110, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.07)))),
                      Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Container(width: 46, height: 46, decoration: BoxDecoration(color: Colors.white.withOpacity(0.18), borderRadius: BorderRadius.circular(12)), child: Icon(feature['icon'] as IconData, color: Colors.white, size: 22)),
                          const SizedBox(width: 10),
                          if (isRec) Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white.withOpacity(0.4))), child: const Text("RECOMMENDED", style: TextStyle(color: Colors.white, fontSize: 9, fontFamily: "Rajdhani", fontWeight: FontWeight.bold, letterSpacing: 1))),
                        ]),
                        const SizedBox(height: 10),
                        Text(mod['title'] as String, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, fontFamily: "Rajdhani", letterSpacing: 1)),
                        Text(mod['desc'] as String, style: TextStyle(color: Colors.white.withOpacity(0.75), fontSize: 11, fontFamily: "Rajdhani")),
                        const SizedBox(height: 8),
                        Container(height: 0.5, color: Colors.white.withOpacity(0.2)),
                        const SizedBox(height: 6),
                        Wrap(spacing: 6, runSpacing: 4, children: (mod['tags'] as List<String>).map((tag) => Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white.withOpacity(0.3))),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.check_circle_outline, color: Colors.white, size: 10), const SizedBox(width: 4), Text(tag, style: const TextStyle(color: Colors.white, fontSize: 9, fontFamily: "Rajdhani", fontWeight: FontWeight.bold))]),
                        )).toList()),
                        const Spacer(),
                        Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 10), decoration: BoxDecoration(color: Colors.white.withOpacity(0.18), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white.withOpacity(0.3))), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: const [Text("START MODULE", style: TextStyle(color: Colors.white, fontFamily: "Rajdhani", fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 13)), SizedBox(width: 8), Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 16)])),
                      ])),
                    ]),
                  ),
                );
              },
            )),
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(bugModules.length, (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 300), margin: const EdgeInsets.symmetric(horizontal: 3), height: 5,
              width: currentBugIndex == i ? 18 : 6,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: currentBugIndex == i ? Colors.white : Colors.white.withOpacity(0.3)),
            ))),
          ]),
        );
      });
    });
  }

  // ══════════════════════════════════════════════════
  //  JADWAL SHOLAT SECTION — Redesign Premium
  // ══════════════════════════════════════════════════
  Widget _buildJadwalSholatSection() {
    final palette = ThemeProvider.of(context).current;
    final p = palette.primary;

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

      // ── Header ─────────────────────────────────────
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Container(width: 3, height: 18, decoration: BoxDecoration(color: p, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 10),
          const Text('JADWAL SHOLAT', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 3)),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: p.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: p.withValues(alpha: 0.3)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.location_on_rounded, color: p, size: 11),
              const SizedBox(width: 4),
              Text(_cityName, style: TextStyle(color: p, fontSize: 11, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 10),

      // ── Countdown Banner ───────────────────────────
      if (_nextPrayerName.isNotEmpty)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _cardBg,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: p.withValues(alpha: 0.25)),
              boxShadow: [BoxShadow(color: p.withValues(alpha: 0.06), blurRadius: 16)],
            ),
            child: Row(children: [
              // Pulse dot
              Container(
                width: 10, height: 10,
                decoration: BoxDecoration(
                  shape: BoxShape.circle, color: p,
                  boxShadow: [BoxShadow(color: p.withValues(alpha: 0.5), blurRadius: 8, spreadRadius: 1)],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Menuju $_nextPrayerName', style: const TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontSize: 11, letterSpacing: 1)),
                Text(_nextPrayerTime, style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 22, fontWeight: FontWeight.bold, height: 1.1)),
              ])),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: p.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: p.withValues(alpha: 0.3)),
                  ),
                  child: Text('LIVE', style: TextStyle(color: p, fontSize: 9, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, letterSpacing: 2)),
                ),
                const SizedBox(height: 6),
                if (_countdownText.isNotEmpty)
                  Text(_countdownText, style: TextStyle(color: p, fontFamily: 'Rajdhani', fontSize: 13, fontWeight: FontWeight.bold)),
              ]),
            ]),
          ),
        ),
      const SizedBox(height: 10),

      // ── Prayer Cards ────────────────────────────────
      SizedBox(
        height: 96,
        child: _prayerTimes.isEmpty
            ? Center(child: CircularProgressIndicator(color: p, strokeWidth: 2))
            : ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _prayerTimes.length,
                itemBuilder: (_, i) {
                  final pr = _prayerTimes[i];
                  final isNext = pr.name == _nextPrayerName;
                  return Container(
                    width: 82,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      color: isNext ? p.withValues(alpha: 0.15) : _cardBg,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isNext ? p.withValues(alpha: 0.5) : _cardBorder,
                        width: isNext ? 1.5 : 1,
                      ),
                      boxShadow: isNext ? [BoxShadow(color: p.withValues(alpha: 0.2), blurRadius: 12)] : [],
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(pr.icon, color: isNext ? p : Colors.white38, size: 18),
                      const SizedBox(height: 6),
                      Text(pr.name.toUpperCase(), style: TextStyle(
                        color: isNext ? p : Colors.white38,
                        fontSize: 9, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, letterSpacing: 1,
                      )),
                      const SizedBox(height: 3),
                      Text(pr.time, style: TextStyle(
                        color: isNext ? Colors.white : Colors.white70,
                        fontSize: 15, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold,
                      )),
                    ]),
                  );
                },
              ),
      ),
      const SizedBox(height: 14),

      // ── Theme Picker ──────────────────────────────────────────
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: GestureDetector(
          onTap: () => showThemePicker(context),
          child: Builder(builder: (ctx) {
            final pal = ThemeProvider.of(ctx).current;
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: _cardBg,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: pal.primary.withValues(alpha: 0.35)),
                boxShadow: [BoxShadow(color: pal.primary.withValues(alpha: 0.08), blurRadius: 12, spreadRadius: 1)],
              ),
              child: Row(children: [
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(colors: [pal.gradient1, pal.primary]).createShader(bounds),
                  child: const Icon(Icons.palette_outlined, color: Colors.white, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Tema Warna', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  Text(pal.name, style: TextStyle(color: pal.primary, fontFamily: 'Rajdhani', fontSize: 10, letterSpacing: 1)),
                ])),
                Container(
                  width: 22, height: 22,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [pal.gradient1, pal.primary], begin: Alignment.topLeft, end: Alignment.bottomRight),
                    boxShadow: [BoxShadow(color: pal.primary.withValues(alpha: 0.5), blurRadius: 8, spreadRadius: 1)],
                  ),
                ),
                const SizedBox(width: 8),
                Icon(Icons.chevron_right_rounded, color: pal.primary.withValues(alpha: 0.7), size: 18),
              ]),
            );
          }),
        ),
      ),
      const SizedBox(height: 4),
    ]);
  }

  // ── Sender Button ─────────────────────────────────────────────
  void _showFreeRoleLocked(BuildContext ctx) {
    ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
      content: Text('⛓️ Fitur ini tidak tersedia untuk akun Free.', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
      backgroundColor: Color(0xFFFF1744),
      behavior: SnackBarBehavior.floating,
    ));
  }

  Widget _buildSenderButton() {
    return GestureDetector(
      onTap: () => _selectFromDrawer('sender'),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        height: 72,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [_primaryBlue.withValues(alpha: 0.9), _primaryBlue.withValues(alpha: 0.6)], begin: Alignment.centerLeft, end: Alignment.centerRight),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: _primaryBlue.withValues(alpha: 0.3), blurRadius: 20, spreadRadius: 2, offset: const Offset(0, 8))],
        ),
        child: Row(children: [
          const SizedBox(width: 16),
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(color: Colors.black.withOpacity(0.3), shape: BoxShape.circle),
            child: const Icon(Icons.phone_android, color: Colors.white, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text("Manage Sender", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: "Rajdhani", letterSpacing: 1.0)),
            Text("Tap To Open", style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 11, fontFamily: "Rajdhani")),
          ])),
          Container(width: 36, height: 36, decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), shape: BoxShape.circle), child: const Icon(Icons.arrow_forward, color: Colors.white, size: 20)),
          const SizedBox(width: 16),
        ]),
      ),
    );
  }

  // ── Main Home Page ─────────────────────────────────────────────
  Widget _buildNewsPage() {
    return RefreshIndicator(
      color: _primaryBlue,
      onRefresh: () async {
        await Future.delayed(const Duration(seconds: 1));
        await _fetchPrayerTimes();
        setState(() {});
      },
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(child: SizedBox(height: MediaQuery.of(context).padding.top + 68)),
          SliverToBoxAdapter(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(height: 20),
              // Banner video
              _buildBannerVideo(),
              const SizedBox(height: 16),
              // Account stats
              _buildAccountStatsCard(),
              const SizedBox(height: 28),
              // Latest Updates
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  _buildSectionTitle("LATEST UPDATES"),
                  if (newsList.isNotEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(color: const Color(0xFFFF6B35).withValues(alpha: 0.15), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFFF6B35).withValues(alpha: 0.4))),
                      child: Text("${newsList.length} Updates", style: const TextStyle(color: Color(0xFFFF6B35), fontSize: 11, fontFamily: "Rajdhani", fontWeight: FontWeight.bold)),
                    ),
                ]),
              ),
              const SizedBox(height: 8),
              _buildNewsCarousel(),
              const SizedBox(height: 28),
              _buildToolsSliderSection(),
              const SizedBox(height: 28),
              _buildJadwalSholatSection(),
              const SizedBox(height: 110),
            ]),
          ),
        ],
      ),
    );
  }

  // ── Glass helpers ─────────────────────────────────────────────
  Widget _glassCard({required Widget child}) {
    return Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.black.withOpacity(0.2), border: Border.all(color: _primaryBlue.withValues(alpha: 0.2)), boxShadow: [BoxShadow(color: _primaryBlue.withValues(alpha: 0.05), blurRadius: 20, spreadRadius: 2)]),
      child: ClipRRect(borderRadius: BorderRadius.circular(20), child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5), child: child)),
    );
  }

  Widget _glassButton({required Icon icon, required Text label, required VoidCallback onPressed}) {
    return ElevatedButton.icon(
      icon: icon, label: label,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent, foregroundColor: _primaryBlue, shadowColor: Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: _primaryBlue.withValues(alpha: 0.3))),
      ),
      onPressed: onPressed,
    );
  }

  // ── Bug options sheet ─────────────────────────────────────────
  void _showBugOptionsSheet() {
    final currentRole = role.toLowerCase();
    final allowedGroupRoles = ['dev', 'high admin', 'staff', 'partner', 'owner', 'reseller', 'vip'];
    final canAccessGroup = allowedGroupRoles.contains(currentRole);

    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _glassCard(child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text("Select Bug Type", style: TextStyle(color: Colors.white, fontSize: 20, fontFamily: "Rajdhani")),
            const SizedBox(height: 20),
            _glassButton(icon: const Icon(Icons.person_outline), label: const Text("Bug Contact", style: TextStyle(color: Colors.white, fontFamily: "Rajdhani")), onPressed: () { Navigator.pop(context); _selectFromDrawer('bug'); }),
            if (canAccessGroup) ...[
              const SizedBox(height: 10),
              _glassButton(icon: const Icon(FontAwesomeIcons.usersSlash), label: const Text("Bug Group", style: TextStyle(color: Colors.white, fontFamily: "Rajdhani")), onPressed: () { Navigator.pop(context); _selectFromDrawer('group_bug'); }),
            ],
            const SizedBox(height: 10),
          ]),
        )),
      ),
    );
  }

  // ── Account menu ──────────────────────────────────────────────
  void _showAccountMenu() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AccountInfoPage(
        username: username,
        password: password,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
        onLogout: () async {
          final prefs = await SharedPreferences.getInstance();
          await prefs.clear();
          if (!mounted) return;
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
        },
      )),
    );
  }

  Widget _infoCard(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.2), borderRadius: BorderRadius.circular(16), border: Border.all(color: _primaryBlue.withValues(alpha: 0.2))),
      child: Row(children: [
        Icon(icon, color: _primaryBlue),
        const SizedBox(width: 10),
        Text("$label:", style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
        const Spacer(),
        Text(value, style: const TextStyle(color: Color(0xFFFF1744), fontFamily: "Rajdhani")),
      ]),
    );
  }

  // ── Assistive Touch Menu ──────────────────────────────────────
  Widget _buildPremiumDrawer() {
    final palette = ThemeProvider.of(context);
    final p = palette.current;
    final currentRole = role.toLowerCase();
    final canAccessAdmin  = ['dev','high admin','staff','partner','owner'].contains(currentRole);
    final canAccessSeller = ['dev','high admin','staff','partner','owner','reseller'].contains(currentRole);
    final canAccessAllBugs     = ['dev','high admin','staff','partner','owner'].contains(currentRole);
    final canAccessResellerBugs = ['reseller'].contains(currentRole);
    final isMember = !canAccessAllBugs && !canAccessResellerBugs;

    void go(String page) {
      Navigator.pop(context);
      _selectFromDrawer(page);
    }

    return Drawer(
      width: MediaQuery.of(context).size.width * 0.72,
      backgroundColor: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF080D14),
          border: Border(right: BorderSide(color: p.primary.withValues(alpha: 0.2))),
        ),
        child: Column(children: [
          // ── Header ──────────────────────────────────────────
          Container(
            padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 20, bottom: 20, left: 20, right: 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: [p.primary.withValues(alpha: 0.15), Colors.transparent],
              ),
              border: Border(bottom: BorderSide(color: p.primary.withValues(alpha: 0.15))),
            ),
            child: Row(children: [
              Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [p.primary.withValues(alpha: 0.3), Colors.transparent]),
                  border: Border.all(color: p.primary.withValues(alpha: 0.5), width: 1.5),
                ),
                child: ClipOval(child: Image.asset('assets/images/logo.png', fit: BoxFit.cover,
                    errorBuilder: (c,e,s) => Icon(Icons.security, color: p.primary, size: 22))),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(username, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 16, fontWeight: FontWeight.bold)),
                Container(
                  margin: const EdgeInsets.only(top: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: p.primary.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: p.primary.withValues(alpha: 0.3)),
                  ),
                  child: Text(role.toUpperCase(), style: TextStyle(color: p.primary, fontFamily: 'Rajdhani', fontSize: 9, letterSpacing: 2, fontWeight: FontWeight.bold)),
                ),
              ])),
            ]),
          ),

          // ── Menu Items ──────────────────────────────────────
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _drawerItem(Icons.home_rounded, 'Home', 'home', p, () => go('home')),
                _drawerDividerLabel('TOOLS'),
                if (!isMember) ...[
                  _drawerExpandable(FontAwesomeIcons.whatsapp, 'Bug Tools', p, [
                    if (canAccessAllBugs || canAccessResellerBugs) _drawerSubItem(FontAwesomeIcons.usersSlash, 'Group Bug', () => go('group_bug')),
                    if (canAccessAllBugs) _drawerSubItem(Icons.terminal, 'Custom Bug', () => go('custom_bug')),
                    _drawerSubItem(Icons.bolt_rounded, 'Basic Bug', () => go('bug')),
                  ]),
                ] else
                  _drawerItem(FontAwesomeIcons.whatsapp, 'Bug Tools', 'bug', p, () => go('bug')),
                _drawerItem(FontAwesomeIcons.paperPlane, 'Spam', 'telegram', p, () => go('telegram')),
                _drawerItem(FontAwesomeIcons.screwdriverWrench, 'Tools', 'tools', p, () => go('tools')),
                _drawerItem(Icons.security_rounded, 'DDoS Attack', 'ddos', p, () => go('ddos')),
                _drawerDividerLabel('AKUN'),
                _drawerItem(Icons.person_rounded, 'Account Info', 'account', p, () => go('account')),
                _drawerItem(FontAwesomeIcons.telegram, 'Join Grup Telegram', 'telegramgroup', p, () => go('telegramgroup')),
                if (canAccessSeller) _drawerItem(Icons.storefront_rounded, 'Seller Panel', 'reseller', p, () => go('reseller')),
                if (canAccessAdmin)  _drawerItem(Icons.admin_panel_settings_rounded, 'Admin Panel', 'admin', p, () => go('admin')),
                _drawerItem(FontAwesomeIcons.whatsapp, 'Manage Sender', 'sender', p, () => go('sender')),
                _drawerDividerLabel('PENGATURAN'),
                // Tema
                GestureDetector(
                  onTap: () { Navigator.pop(context); showThemePicker(context); },
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: p.primary.withValues(alpha: 0.15)),
                    ),
                    child: Row(children: [
                      Icon(Icons.palette_outlined, color: p.primary, size: 18),
                      const SizedBox(width: 14),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('Tema Warna', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 14, fontWeight: FontWeight.bold)),
                        Text(p.name, style: TextStyle(color: p.primary, fontFamily: 'Rajdhani', fontSize: 10, letterSpacing: 1)),
                      ])),
                      Container(
                        width: 22, height: 22,
                        decoration: BoxDecoration(color: p.primary, shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: p.primary.withValues(alpha: 0.5), blurRadius: 8)]),
                      ),
                    ]),
                  ),
                ),
              ]),
            ),
          ),

          // ── Footer ──────────────────────────────────────────
          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            decoration: BoxDecoration(border: Border(top: BorderSide(color: p.primary.withValues(alpha: 0.1)))),
            child: GestureDetector(
              onTap: () async {
                Navigator.pop(context);
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (!mounted) return;
                Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.red.withValues(alpha: 0.2)),
                ),
                child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.logout_rounded, color: Colors.red, size: 16),
                  SizedBox(width: 8),
                  Text('LOGOUT', style: TextStyle(color: Colors.red, fontFamily: 'Rajdhani', fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 2)),
                ]),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _drawerItem(IconData icon, String label, String page, dynamic p, VoidCallback onTap) {
    final isActive = _activePage == page;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: isActive ? p.primary.withValues(alpha: 0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: isActive ? p.primary.withValues(alpha: 0.3) : Colors.transparent),
        ),
        child: Row(children: [
          Icon(icon, color: isActive ? p.primary : Colors.white54, size: 17),
          const SizedBox(width: 14),
          Text(label, style: TextStyle(
            color: isActive ? p.primary : Colors.white70,
            fontFamily: 'Rajdhani', fontSize: 14, fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
          )),
          if (isActive) ...[const Spacer(), Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: p.primary))],
        ]),
      ),
    );
  }

  Widget _drawerSubItem(IconData icon, String label, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.only(left: 16, bottom: 8),
      child: Row(children: [
        Container(width: 1.5, height: 20, color: Colors.white12),
        const SizedBox(width: 12),
        Icon(icon, color: Colors.white38, size: 14),
        const SizedBox(width: 10),
        Text(label, style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 13)),
      ]),
    ),
  );

  Widget _drawerExpandable(IconData icon, String label, dynamic p, List<Widget> children) {
    return Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 14),
        childrenPadding: const EdgeInsets.only(bottom: 6),
        leading: Icon(icon, color: p.primary, size: 17),
        title: Text(label, style: TextStyle(color: p.primary, fontFamily: 'Rajdhani', fontSize: 14, fontWeight: FontWeight.bold)),
        trailing: Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white38, size: 18),
        children: children,
      ),
    );
  }

  Widget _drawerDividerLabel(String label) => Padding(
    padding: const EdgeInsets.only(left: 4, top: 12, bottom: 6),
    child: Text(label, style: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 10, letterSpacing: 3)),
  );

  Widget _buildAssistiveMenu() {
    final currentRole = role.toLowerCase();
    final canAccessAdmin = ['dev', 'high admin', 'staff', 'partner', 'owner'].contains(currentRole);
    final canAccessSeller = ['dev', 'high admin', 'staff', 'partner', 'owner', 'reseller'].contains(currentRole);
    final canAccessAllBugs = ['dev', 'high admin', 'staff', 'partner', 'owner'].contains(currentRole);
    final canAccessResellerBugs = ['reseller'].contains(currentRole);
    final isMember = !canAccessAllBugs && !canAccessResellerBugs;

    return Container(
      width: 240,
      decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(16), border: Border.all(color: _primaryBlue.withValues(alpha: 0.2)), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 15, spreadRadius: 2, offset: const Offset(0, 5))]),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(height: 8),
              _assistiveMenuItem(Icons.home, "Home", 'home'),
              Theme(
                data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                child: ExpansionTile(
                  tilePadding: const EdgeInsets.symmetric(horizontal: 16),
                  childrenPadding: EdgeInsets.zero,
                  leading: const Icon(FontAwesomeIcons.whatsapp, color: _primaryBlue, size: 18),
                  title: const Text("Bug Tools", style: TextStyle(color: _primaryBlue, fontSize: 14, fontFamily: "Rajdhani", letterSpacing: 1.0)),
                  trailing: Icon(_isBugToolsExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, color: Colors.white54, size: 18),
                  onExpansionChanged: (expanded) {
                    setState(() { _isBugToolsExpanded = expanded; });
                    if (isMember && expanded) { setState(() { _isBugToolsExpanded = false; }); _selectFromDrawer('bug'); }
                  },
                  children: [
                    if (!isMember)
                      Padding(
                        padding: const EdgeInsets.only(left: 20, top: 4, bottom: 8, right: 16),
                        child: Stack(children: [
                          Positioned(left: 7, top: 12, bottom: 12, child: Container(width: 1.5, color: Colors.white24)),
                          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            if (canAccessAllBugs || canAccessResellerBugs) ...[_buildTreeItem(icon: FontAwesomeIcons.usersSlash, title: "Group Bug", page: 'group_bug'), const SizedBox(height: 8)],
                            if (canAccessAllBugs) ...[_buildTreeItem(icon: Icons.terminal, title: "Custom Bug", page: 'custom_bug'), const SizedBox(height: 8)],
                            _buildTreeItem(icon: Icons.bolt, title: "Basic Bug", page: 'bug'),
                          ]),
                        ]),
                      ),
                  ],
                ),
              ),
              _assistiveMenuItem(FontAwesomeIcons.paperPlane, "Spam", 'telegram'),
              _assistiveMenuItem(FontAwesomeIcons.screwdriverWrench, "Tools", 'tools'),
              _assistiveMenuItem(Icons.security, "DDoS Attack", 'ddos'),
              const Divider(color: Colors.white12, height: 16, thickness: 1, indent: 16, endIndent: 16),
              _assistiveMenuItem(Icons.person, "Account Info", 'account'),
              _assistiveMenuItem(FontAwesomeIcons.telegram, "Join Grup Telegram", 'telegramgroup'),
              if (canAccessSeller) _assistiveMenuItem(Icons.store, "Seller Panel", 'reseller'),
              if (canAccessAdmin) _assistiveMenuItem(Icons.admin_panel_settings, "Admin Panel", 'admin'),
              _assistiveMenuItem(FontAwesomeIcons.whatsapp, "Manage Sender", 'sender'),
              const Divider(color: Colors.white12, height: 24, thickness: 1, indent: 16, endIndent: 16),
              _themeMenuItem(),
              const SizedBox(height: 16),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _themeMenuItem() {
    final themeNotifier = ThemeProvider.of(context);
    final palette = themeNotifier.current;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          splashColor: palette.primary.withValues(alpha: 0.2),
          highlightColor: palette.primary.withValues(alpha: 0.1),
          onTap: () => showThemePicker(context),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: palette.primary.withValues(alpha: 0.15)),
            ),
            child: Row(children: [
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [palette.gradient1, palette.primary],
                ).createShader(bounds),
                child: const Icon(Icons.palette_outlined, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Tema Warna", style: TextStyle(color: Colors.white, fontSize: 14, fontFamily: "Rajdhani", fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                    Text(palette.name, style: TextStyle(color: palette.primary, fontSize: 10, fontFamily: "Rajdhani", letterSpacing: 1.0)),
                  ],
                ),
              ),
              Container(
                width: 20, height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [palette.gradient1, palette.primary],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [BoxShadow(color: palette.primary.withValues(alpha: 0.5), blurRadius: 6, spreadRadius: 1)],
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _assistiveMenuItem(IconData icon, String title, String page) {
    bool isActive = _activePage == page;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          splashColor: _primaryBlue.withValues(alpha: 0.2),
          highlightColor: _primaryBlue.withValues(alpha: 0.1),
          onTap: () => _selectFromDrawer(page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: isActive ? BoxDecoration(color: const Color(0xFF0A1628), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF1A3A5C))) : null,
            child: Row(children: [
              Icon(icon, color: isActive ? _primaryBlue : Colors.white70, size: 18),
              const SizedBox(width: 16),
              Expanded(child: Text(title, style: TextStyle(color: isActive ? Colors.white : Colors.white70, fontSize: 14, fontFamily: "Rajdhani", fontWeight: isActive ? FontWeight.bold : FontWeight.w500, letterSpacing: 1.0))),
              if (isActive) Container(width: 6, height: 6, decoration: const BoxDecoration(color: _primaryBlue, shape: BoxShape.circle)),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildTreeItem({required IconData icon, required String title, required String page}) {
    bool isActive = _activePage == page;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: () => _selectFromDrawer(page),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
          child: Row(children: [
            SizedBox(width: 14, child: Icon(icon, color: isActive ? _primaryBlue : Colors.white70, size: 16)),
            const SizedBox(width: 16),
            Text(title, style: TextStyle(color: isActive ? _primaryBlue : Colors.white70, fontSize: 13, fontFamily: "Rajdhani", letterSpacing: 1.0)),
          ]),
        ),
      ),
    );
  }

  // ── Floating Nav Bar (SMALLER, like Manta) ────────────────────
  void _showBugSheet() {
    final palette = ThemeProvider.of(context).current;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0D1520),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(top: BorderSide(color: palette.primary.withValues(alpha: 0.3), width: 1.5)),
          boxShadow: [BoxShadow(color: palette.primary.withValues(alpha: 0.12), blurRadius: 30, spreadRadius: 5)],
        ),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 36),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          // Handle bar
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),

          // Title
          Row(children: [
            Icon(FontAwesomeIcons.whatsapp, color: palette.primary, size: 16),
            const SizedBox(width: 8),
            Text('PILIH BUG', style: TextStyle(
              color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold,
              fontSize: 16, letterSpacing: 2,
              shadows: [Shadow(color: palette.primary, blurRadius: 10)],
            )),
          ]),
          const SizedBox(height: 20),

          // Bug cards - SLIDER
          StatefulBuilder(builder: (ctx2, setSlider) {
            int _bugIdx = 0;
            final _bugCtrl = PageController();
            final bugCards = [
              _bugSheetCard(
                ctx: ctx,
                icon: FontAwesomeIcons.whatsapp,
                label: 'Bug Nomor',
                sub: 'Target nomor WA',
                gradientColors: const [Color(0xFF075E54), Color(0xFF25D366)],
                glowColor: const Color(0xFF25D366),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => AttackPage(
                      username: username, password: password,
                      listBug: listBug, role: role,
                      expiredDate: expiredDate, sessionKey: sessionKey,
                    ),
                  ));
                },
              ),
              _bugSheetCard(
                ctx: ctx,
                icon: FontAwesomeIcons.whatsapp,
                label: 'Bug Group',
                sub: 'Target grup WA',
                gradientColors: const [Color(0xFF7F0000), Color(0xFFFF1744)],
                glowColor: const Color(0xFFFF1744),
                onTap: () { Navigator.pop(ctx); _selectFromDrawer('group_bug'); },
              ),
              _bugSheetCard(
                ctx: ctx,
                icon: FontAwesomeIcons.whatsapp,
                label: 'Custom Bug',
                sub: 'Bug kustom',
                gradientColors: const [Color(0xFF1A0066), Color(0xFF7C4DFF)],
                glowColor: const Color(0xFF7C4DFF),
                onTap: () { Navigator.pop(ctx); _selectFromDrawer('custom_bug'); },
              ),
            ];
            return Column(children: [
              SizedBox(
                height: 150,
                child: PageView.builder(
                  controller: _bugCtrl,
                  itemCount: bugCards.length,
                  onPageChanged: (i) => setSlider(() => _bugIdx = i),
                  itemBuilder: (_, i) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    child: bugCards[i],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(bugCards.length, (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  height: 6,
                  width: _bugIdx == i ? 22 : 7,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: _bugIdx == i ? const Color(0xFF25D366) : Colors.white24,
                  ),
                )),
              ),
            ]);
          }),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Widget _bugSheetCard({
    required BuildContext ctx,
    required IconData icon,
    required String label,
    required String sub,
    required List<Color> gradientColors,
    required Color glowColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        clipBehavior: Clip.hardEdge,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(colors: gradientColors, begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: glowColor.withValues(alpha: 0.45), blurRadius: 22, spreadRadius: 2, offset: const Offset(0, 8))],
        ),
        child: Stack(children: [
          // Lingkaran dekorasi kanan atas
          Positioned(right: -20, top: -20,
            child: Container(width: 110, height: 110,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.08)))),
          // Lingkaran dekorasi kiri bawah
          Positioned(left: -15, bottom: -25,
            child: Container(width: 80, height: 80,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.05)))),
          // Lingkaran kecil tengah kanan
          Positioned(right: 30, bottom: 10,
            child: Container(width: 40, height: 40,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.06)))),
          // Konten
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Row(children: [
                Container(
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(13),
                    boxShadow: [BoxShadow(color: glowColor.withValues(alpha: 0.3), blurRadius: 8)],
                  ),
                  child: Icon(icon, color: Colors.white, size: 22),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.3)),
                  ),
                  child: const Row(children: [
                    Text('TAP', style: TextStyle(color: Colors.white, fontSize: 10, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, letterSpacing: 1)),
                    SizedBox(width: 4),
                    Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 10),
                  ]),
                ),
              ]),
              const SizedBox(height: 12),
              Text(label, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900, fontFamily: 'Rajdhani', letterSpacing: 1)),
              const SizedBox(height: 2),
              Text(sub, style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12, fontFamily: 'Rajdhani')),
            ]),
          ),
        ]),
      ),
    );
  }


  Widget _buildFloatingNavBar() {
    final bool homeActive = _activePage == 'home';
    return Positioned(
      bottom: 16,
      left: 24,
      right: 24,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(32),
        child: Container(
          height: 64,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: _cardBorder, width: 1.2),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20, spreadRadius: 1, offset: const Offset(0, 6)),
              BoxShadow(color: _primaryBlue.withValues(alpha: 0.06), blurRadius: 15),
            ],
          ),
          child: Stack(fit: StackFit.expand, children: [
            // ── Background: foto bar ───────────────────────────
            Image.asset('assets/images/navbar.jpg', fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _cardBg)),
            // ── Overlay gelap biar tombol tetep jelas ──────────
            Container(color: Colors.black.withOpacity(0.55)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // ── Home: bubble foto, lebih gede dari icon lain, tapi rata di dalam bar ──
                GestureDetector(
                  onTap: () => _selectFromDrawer('home'),
                  child: Stack(clipBehavior: Clip.none, children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      width: 48, height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: homeActive ? _primaryBlue : _cardBorder, width: homeActive ? 2.4 : 1.5),
                        boxShadow: [
                          BoxShadow(color: _primaryBlue.withOpacity(homeActive ? 0.45 : 0.15), blurRadius: homeActive ? 16 : 6, spreadRadius: homeActive ? 1 : 0),
                        ],
                      ),
                      child: ClipOval(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: [_primaryBlue.withOpacity(0.9), _primaryCyan.withOpacity(0.7)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                          ),
                          child: const Center(child: Icon(Icons.home_rounded, color: Colors.white, size: 21)),
                        ),
                      ),
                    ),
                    // titik status kecil
                    Positioned(
                      top: -1, right: -1,
                      child: Container(
                        width: 12, height: 12,
                        decoration: BoxDecoration(
                          color: _C_navDot,
                          shape: BoxShape.circle,
                          border: Border.all(color: _cardBg, width: 2),
                        ),
                      ),
                    ),
                  ]),
                ),
                _buildFloatingNavIcon(FontAwesomeIcons.whatsapp, 'bug'),
                _buildFloatingNavIcon(Icons.people_alt_rounded, 'telegram'),
                _buildFloatingNavIcon(FontAwesomeIcons.screwdriverWrench, 'tools'),
              ],
              ),
            ),
          ]),
        ),
      ),
    );
  }

  static const Color _C_navDot = Color(0xFFFF3B30);


  Widget _buildFloatingNavIcon(IconData icon, String page) {
    bool isActive = _activePage == page || (page == 'bug' && (_activePage == 'group_bug' || _activePage == 'custom_bug'));
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () {
          if (page == 'bug') {
            _showBugSheet();
          } else { _selectFromDrawer(page); }
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            AnimatedScale(
              scale: isActive ? 1.15 : 1.0,
              duration: const Duration(milliseconds: 250),
              child: Icon(icon, color: isActive ? _primaryBlue : Colors.white38, size: 20),
            ),
            const SizedBox(height: 4),
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: isActive ? 14 : 0,
              height: 2.5,
              decoration: BoxDecoration(color: _primaryBlue, borderRadius: BorderRadius.circular(3)),
            ),
          ]),
        ),
      ),
    );
  }

  // ── BUILD ────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final bool isRightSide = _assistiveTouchPosition.dx > (screenSize.width / 2);
    final bool isBottomSide = _assistiveTouchPosition.dy > (screenSize.height / 2);

    // Selalu wrap dengan ThemeProvider pakai notifier lokal sebagai fallback
    // Ini fix crash "ThemeProvider not found" saat masuk dari login tanpa parent ThemeProvider
    return ThemeProvider(
      notifier: _themeNotifier,
      child: PopScope(
      canPop: _activePage == 'home',
      onPopInvokedWithResult: (didPop, result) { if (didPop) return; _selectFromDrawer('home'); },
      child: Scaffold(
        key: _scaffoldKey,
        extendBodyBehindAppBar: true,
        backgroundColor: _darkBg,
        drawer: _buildPremiumDrawer(),
        body: Stack(children: [
          Positioned.fill(child: Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF060C15), Color(0xFF080D14), Color(0xFF080D14), Color(0xFF060C15)])))),
          Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: ScanlinePainter()))),
          SafeArea(
            top: false, bottom: false,
            child: FadeTransition(opacity: _animation, child: _selectedPage),
          ),
          if (_activePage == 'home' || _activePage == 'inner')
            Positioned(top: 0, left: 0, right: 0, child: _buildHeader()),
          if (_isAssistiveMenuOpen)
            Positioned.fill(child: GestureDetector(
              onTap: () => setState(() { _isAssistiveMenuOpen = false; _isBugToolsExpanded = false; }),
              child: Container(color: Colors.transparent),
            )),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 150),
            left: isRightSide ? _assistiveTouchPosition.dx - 250 : _assistiveTouchPosition.dx + 70,
            top: isBottomSide ? _assistiveTouchPosition.dy - 350 : _assistiveTouchPosition.dy,
            child: AnimatedScale(
              scale: _isAssistiveMenuOpen ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutBack,
              alignment: isRightSide ? (isBottomSide ? Alignment.bottomRight : Alignment.topRight) : (isBottomSide ? Alignment.bottomLeft : Alignment.topLeft),
              child: _buildAssistiveMenu(),
            ),
          ),
          Positioned(
            left: _assistiveTouchPosition.dx,
            top: _assistiveTouchPosition.dy,
            child: GestureDetector(
              onPanUpdate: (details) {
                setState(() {
                  if (_isAssistiveMenuOpen) { _isAssistiveMenuOpen = false; _isBugToolsExpanded = false; }
                  double newX = (_assistiveTouchPosition.dx + details.delta.dx).clamp(0.0, screenSize.width - 60.0);
                  double newY = (_assistiveTouchPosition.dy + details.delta.dy).clamp(0.0, screenSize.height - 120.0);
                  _assistiveTouchPosition = Offset(newX, newY);
                });
              },
              onTap: () => setState(() {
                _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
                if (!_isAssistiveMenuOpen) _isBugToolsExpanded = false;
              }),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 60, height: 60,
                decoration: BoxDecoration(
                  color: _isAssistiveMenuOpen ? const Color(0xFF0A1628) : Colors.black.withOpacity(0.6),
                  shape: BoxShape.circle,
                  border: Border.all(color: _isAssistiveMenuOpen ? _primaryBlue : _primaryBlue.withValues(alpha: 0.4), width: 1.5),
                  boxShadow: [BoxShadow(color: _isAssistiveMenuOpen ? _primaryBlue.withValues(alpha: 0.5) : Colors.black.withOpacity(0.5), blurRadius: 12, spreadRadius: 2)],
                ),
                child: ClipOval(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                    child: Padding(padding: const EdgeInsets.all(12), child: Image.asset('assets/images/logo.png', fit: BoxFit.contain)),
                  ),
                ),
              ),
            ),
          ),
          _buildFloatingNavBar(),
        ]),
      ),
      ),
    );
  }

  Future<void> _initBannerVideoAt(int index) async {
    if (index < 0 || index >= _bannerItems.length) return;
    if (_bannerItems[index]['type'] != 'video') return;
    if (_bannerVideoControllers.containsKey(index)) return;
    try {
      final ctrl = VideoPlayerController.asset(_bannerItems[index]['asset']!);
      _bannerVideoControllers[index] = ctrl;
      await ctrl.initialize();
      ctrl.setLooping(true);
      ctrl.setVolume(0);
      if (index == _currentBannerIndex) ctrl.play();
      if (mounted) setState(() => _bannerVideoReady[index] = true);
    } catch (_) {}
  }

  void _onBannerPageChanged(int index) {
    setState(() => _currentBannerIndex = index);
    // pause banner lain, play yang lagi keliatan
    _bannerVideoControllers.forEach((i, c) {
      if (i == index) { c.play(); } else { c.pause(); }
    });
    _initBannerVideoAt(index);
    _initBannerVideoAt(index + 1); // preload tetangga biar swipe mulus
  }

  Widget _buildBannerVideo() {
    final palette = ThemeProvider.of(context).current;
    return Column(children: [
      Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        height: 180,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: const Color(0xFF0D1520),
          border: Border.all(color: palette.primary.withValues(alpha: 0.25), width: 1.5),
          boxShadow: [
            BoxShadow(color: palette.primary.withValues(alpha: 0.12), blurRadius: 20, spreadRadius: 2),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: PageView.builder(
            controller: _bannerPageController,
            itemCount: _bannerItems.length,
            onPageChanged: _onBannerPageChanged,
            itemBuilder: (context, index) {
              final item = _bannerItems[index];
              final isVideo = item['type'] == 'video';
              final ready = _bannerVideoReady[index] == true;
              final ctrl = _bannerVideoControllers[index];
              return Stack(
                fit: StackFit.expand,
                children: [
                  if (isVideo && ready && ctrl != null)
                    FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(width: ctrl.value.size.width, height: ctrl.value.size.height, child: VideoPlayer(ctrl)),
                    )
                  else if (!isVideo)
                    Image.asset(item['asset']!, fit: BoxFit.cover)
                  else
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [palette.gradient1.withValues(alpha: 0.8), const Color(0xFF0D1520)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                      ),
                      child: Center(child: CircularProgressIndicator(color: palette.primary, strokeWidth: 2)),
                    ),
                  Positioned(
                    bottom: 0, left: 0, right: 0,
                    child: Container(
                      height: 80,
                      decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black54, Colors.transparent])),
                    ),
                  ),
                  Positioned(
                    bottom: 12, left: 14,
                    child: Row(children: [
                      Container(
                        width: 6, height: 6,
                        decoration: BoxDecoration(color: palette.primary, shape: BoxShape.circle, boxShadow: [BoxShadow(color: palette.primary.withValues(alpha: 0.8), blurRadius: 6, spreadRadius: 1)]),
                      ),
                      const SizedBox(width: 6),
                      Text("DOMINUS CORE", style: TextStyle(color: palette.primary, fontSize: 16, fontFamily: "Rajdhani", fontWeight: FontWeight.w900, letterSpacing: 2, shadows: [Shadow(color: palette.primary, blurRadius: 10)])),
                    ]),
                  ),
                ],
              );
            },
          ),
        ),
      ),
      if (_bannerItems.length > 1)
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_bannerItems.length, (index) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              height: 6,
              width: _currentBannerIndex == index ? 24 : 8,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: _currentBannerIndex == index ? palette.primary : Colors.white.withOpacity(0.2)),
            )),
          ),
        ),
    ]);
  }

  Widget _buildTypingHeader() {
    const prefix = 'Selamat Datang, ';
    final uname = widget.username;
    final full = prefix + uname;
    final shown = _typingText.length > full.length ? full : _typingText;
    final prefixShown = shown.length <= prefix.length ? shown : prefix;
    final unameShown = shown.length > prefix.length ? shown.substring(prefix.length) : '';

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: prefixShown,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
              if (unameShown.isNotEmpty)
                TextSpan(
                  text: unameShown,
                  style: const TextStyle(
                    color: Colors.redAccent,
                    fontSize: 14,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
            ],
          ),
        ),
        if (!_typingDone && _cursorVisible)
          const Text(
            '|',
            style: TextStyle(
              color: Colors.redAccent,
              fontSize: 16,
              fontFamily: 'Rajdhani',
              fontWeight: FontWeight.bold,
            ),
          ),
      ],
    );
  }

  void _startTypingAnimation() {
    // Cursor blink
    _cursorTimer?.cancel();
    for (final c in _bannerVideoControllers.values) { c.dispose(); }
    _cursorTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      if (!mounted) return;
      setState(() => _cursorVisible = !_cursorVisible);
    });
    final fullText = 'Selamat Datang, $username';
    _typingText = '';
    _typingDone = false;
    _typingController.reset();
    int i = 0;
    Future.doWhile(() async {
      await Future.delayed(const Duration(milliseconds: 80));
      if (!mounted) return false;
      setState(() {
        if (i < fullText.length) {
          _typingText = fullText.substring(0, i + 1);
          i++;
        } else {
          _typingDone = true;
        }
      });
      return i < fullText.length;
    });
  }

  void dispose() {
    _removeNavMenu();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _typingController.dispose();
    _cursorTimer?.cancel();
    for (final c in _bannerVideoControllers.values) { c.dispose(); }
    _pageController.removeListener(_onNewsPageScroll);
    _pageController.dispose();
    _bannerPageController.dispose();
    _toolsSliderController.dispose();
    _featuresPageController.removeListener(_onFeaturePageScroll);
    _featuresPageController.dispose();
    _batteryTimer?.cancel();
    _prayerTimer?.cancel();
    _countdownTimer?.cancel();
    _sessionTimer?.cancel();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }
}

// ════════════════════════════════════════════════════════════════
//  SCANLINE PAINTER
// ════════════════════════════════════════════════════════════════
class ScanlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.015);
    for (double y = 0; y < size.height; y += 4) {
      canvas.drawRect(Rect.fromLTWH(0, y, size.width, 1.5), paint);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ════════════════════════════════════════════════════════════════
//  NEWS MEDIA WIDGET
// ════════════════════════════════════════════════════════════════
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.play();
        });
    }
  }
  bool _isVideo(String url) => url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov") || url.endsWith(".mkv");

  void dispose() { _controller?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(aspectRatio: _controller!.value.aspectRatio, child: VideoPlayer(_controller!));
      } else {
        return const Center(child: CircularProgressIndicator(color: Color(0xFFFF1744)));
      }
    } else {
      return Image.network(widget.url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: Colors.black26));
    }
  }
}


