// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'app_theme.dart';
import 'topup_page.dart';

// ═══════════════════════════════════════════════════════════════
//  MODELS
// ═══════════════════════════════════════════════════════════════
class MarketItem {
  final String id;
  final String title;
  final String desc;
  final String category; // 'digital' | 'fisik'
  final String type;     // 'fixed' | 'auction'
  final int price;
  final int? highestBid;
  final String? highestBidder;
  final DateTime? auctionEnd;
  final String sellerUsername;
  final String? imageUrl;
  final String status; // 'active' | 'sold' | 'closed'
  final int stock;

  MarketItem({
    required this.id,
    required this.title,
    required this.desc,
    required this.category,
    required this.type,
    required this.price,
    this.highestBid,
    this.highestBidder,
    this.auctionEnd,
    required this.sellerUsername,
    this.imageUrl,
    required this.status,
    required this.stock,
  });

  factory MarketItem.fromJson(Map<String, dynamic> j) => MarketItem(
    id: j['_id'] ?? j['id'] ?? '',
    title: j['title'] ?? '',
    desc: j['desc'] ?? '',
    category: j['category'] ?? 'digital',
    type: j['type'] ?? 'fixed',
    price: (j['price'] ?? 0) is int ? j['price'] : (j['price'] as num).toInt(),
    highestBid: j['highestBid'] != null ? (j['highestBid'] as num).toInt() : null,
    highestBidder: j['highestBidder'],
    auctionEnd: j['auctionEnd'] != null ? DateTime.tryParse(j['auctionEnd']) : null,
    sellerUsername: j['sellerUsername'] ?? '',
    imageUrl: j['imageUrl'],
    status: j['status'] ?? 'active',
    stock: (j['stock'] ?? 1) is int ? j['stock'] : (j['stock'] as num).toInt(),
  );
}

// ═══════════════════════════════════════════════════════════════
//  MARKETPLACE PAGE
// ═══════════════════════════════════════════════════════════════
class MarketplacePage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const MarketplacePage({super.key, required this.sessionKey, required this.username});

  @override
  State<MarketplacePage> createState() => _MarketplacePageState();
}

class _MarketplacePageState extends State<MarketplacePage> with TickerProviderStateMixin {
  late TabController _tab;
  List<MarketItem> _allItems = [];
  List<MarketItem> _myItems = [];
  bool _loading = true;
  String _filter = 'all'; // 'all' | 'digital' | 'fisik'
  String _typeFilter = 'all'; // 'all' | 'fixed' | 'auction'
  int _walletBalance = 0;
  String _search = '';
  final _searchCtrl = TextEditingController();
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this);
    _loadData();
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (_) => _loadData());
  }

  @override
  void dispose() {
    _tab.dispose();
    _searchCtrl.dispose();
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadData() async {
    try {
      final results = await Future.wait([
        http.get(Uri.parse('${AppConfig.baseUrl}/api/marketplace/items'), headers: {'x-session-key': widget.sessionKey}),
        http.get(Uri.parse('${AppConfig.baseUrl}/api/marketplace/my-items'), headers: {'x-session-key': widget.sessionKey}),
        http.get(Uri.parse('${AppConfig.baseUrl}/api/marketplace/wallet'), headers: {'x-session-key': widget.sessionKey}),
      ]);
      if (!mounted) return;
      final itemsData = jsonDecode(results[0].body);
      final myData = jsonDecode(results[1].body);
      final walletData = jsonDecode(results[2].body);
      setState(() {
        _allItems = (itemsData['items'] as List? ?? []).map((e) => MarketItem.fromJson(e)).toList();
        _myItems = (myData['items'] as List? ?? []).map((e) => MarketItem.fromJson(e)).toList();
        _walletBalance = (walletData['balance'] ?? 0) is int ? walletData['balance'] : (walletData['balance'] as num).toInt();
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<MarketItem> get _filtered {
    var list = _allItems.where((i) => i.status == 'active').toList();
    if (_filter != 'all') list = list.where((i) => i.category == _filter).toList();
    if (_typeFilter != 'all') list = list.where((i) => i.type == _typeFilter).toList();
    if (_search.isNotEmpty) list = list.where((i) => i.title.toLowerCase().contains(_search.toLowerCase()) || i.sellerUsername.toLowerCase().contains(_search.toLowerCase())).toList();
    return list;
  }

  String _fmtRupiah(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp ${buf.toString()}';
  }

  String _countdown(DateTime end) {
    final diff = end.difference(DateTime.now());
    if (diff.isNegative) return 'Selesai';
    if (diff.inDays > 0) return '${diff.inDays}h ${diff.inHours % 24}j';
    if (diff.inHours > 0) return '${diff.inHours}j ${diff.inMinutes % 60}m';
    return '${diff.inMinutes}m ${diff.inSeconds % 60}d';
  }

  @override
  Widget build(BuildContext context) {
    final theme = ThemeProvider.of(context);
    final primary = theme.primary;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, color: primary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('MARKETPLACE', style: TextStyle(color: primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 2)),
        actions: [
          // Wallet balance
          GestureDetector(
            onTap: () => _openTopUp(context),
            child: Container(
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                border: Border.all(color: primary.withOpacity(0.5)),
                borderRadius: BorderRadius.circular(20),
                color: primary.withOpacity(0.1),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.account_balance_wallet_rounded, color: primary, size: 14),
                const SizedBox(width: 6),
                Text(_fmtRupiah(_walletBalance), style: TextStyle(color: primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 12)),
              ]),
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: primary,
          labelColor: primary,
          unselectedLabelColor: Colors.white38,
          labelStyle: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13),
          tabs: const [
            Tab(text: 'SEMUA'),
            Tab(text: 'JUALAN GW'),
            Tab(text: 'REKBER'),
            Tab(text: 'RIWAYAT'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _buildBrowseTab(primary),
          _buildMyItemsTab(primary),
          _buildHistoryTab(primary),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showSellDialog(context, primary),
        backgroundColor: primary,
        icon: const Icon(Icons.add_rounded, color: Colors.black),
        label: const Text('JUAL', style: TextStyle(color: Colors.black, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 14)),
      ),
    );
  }

  // ── Tab Browse ───────────────────────────────────────────────
  Widget _buildBrowseTab(Color primary) {
    return Column(children: [
      // Search
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: TextField(
          controller: _searchCtrl,
          style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani'),
          onChanged: (v) => setState(() => _search = v),
          decoration: InputDecoration(
            hintText: 'Cari produk atau seller...',
            hintStyle: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani'),
            prefixIcon: Icon(Icons.search_rounded, color: primary),
            filled: true,
            fillColor: const Color(0xFF111111),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: primary.withOpacity(0.2))),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: primary)),
            contentPadding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
      ),
      // Filter chips
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
        child: Row(children: [
          _chip('Semua', 'all', _filter, (v) => setState(() => _filter = v), primary),
          const SizedBox(width: 8),
          _chip('Digital', 'digital', _filter, (v) => setState(() => _filter = v), primary),
          const SizedBox(width: 8),
          _chip('Fisik', 'fisik', _filter, (v) => setState(() => _filter = v), primary),
          const Spacer(),
          _chip('Fixed', 'fixed', _typeFilter, (v) => setState(() => _typeFilter = v), Colors.orange),
          const SizedBox(width: 8),
          _chip('Lelang', 'auction', _typeFilter, (v) => setState(() => _typeFilter = v), Colors.purple),
        ]),
      ),
      // List
      Expanded(
        child: _loading
          ? Center(child: CircularProgressIndicator(color: primary))
          : _filtered.isEmpty
            ? _empty('Tidak ada produk', Icons.store_mall_directory_outlined, primary)
            : RefreshIndicator(
                color: primary,
                onRefresh: _loadData,
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  itemCount: _filtered.length,
                  itemBuilder: (ctx, i) => _itemCard(_filtered[i], primary),
                ),
              ),
      ),
    ]);
  }

  Widget _chip(String label, String val, String current, void Function(String) onTap, Color color) {
    final active = current == val;
    return GestureDetector(
      onTap: () => onTap(val),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: active ? color.withOpacity(0.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? color : Colors.white24),
        ),
        child: Text(label, style: TextStyle(color: active ? color : Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 12)),
      ),
    );
  }

  Widget _itemCard(MarketItem item, Color primary) {
    final isAuction = item.type == 'auction';
    final currentPrice = isAuction ? (item.highestBid ?? item.price) : item.price;
    final auctionColor = Colors.purple;

    return GestureDetector(
      onTap: () => _showItemDetail(context, item, primary),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF0D0D0D),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isAuction ? auctionColor.withOpacity(0.4) : primary.withOpacity(0.15)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Image atau placeholder
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            child: item.imageUrl != null
              ? Image.network(item.imageUrl!, height: 160, width: double.infinity, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => _imagePlaceholder(isAuction ? auctionColor : primary))
              : _imagePlaceholder(isAuction ? auctionColor : primary),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Badge row
              Row(children: [
                _badge(item.category == 'digital' ? 'Digital' : 'Fisik', item.category == 'digital' ? Colors.cyan : Colors.orange, icon: item.category == 'digital' ? Icons.bolt_rounded : Icons.inventory_2_rounded),
                const SizedBox(width: 6),
                if (isAuction) _badge('Lelang', auctionColor, icon: Icons.gavel_rounded),
                const Spacer(),
                if (isAuction && item.auctionEnd != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: Colors.red.withOpacity(0.15), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.red.withOpacity(0.4))),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.timer_outlined, color: Colors.red, size: 12),
                      const SizedBox(width: 4),
                      Text(_countdown(item.auctionEnd!), style: const TextStyle(color: Colors.red, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 11)),
                    ]),
                  ),
              ]),
              const SizedBox(height: 8),
              Text(item.title, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16), maxLines: 2, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 4),
              Text(item.desc, style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 12), maxLines: 2, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 10),
              Row(children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(isAuction ? 'Bid Tertinggi' : 'Harga', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11)),
                  Text(_fmtRupiah(currentPrice), style: TextStyle(color: isAuction ? auctionColor : primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 18)),
                ]),
                const Spacer(),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('@${item.sellerUsername}', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11)),
                  if (!isAuction) Text('Stok: ${item.stock}', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11)),
                  if (isAuction && item.highestBidder != null) Text('Bidder: ${item.highestBidder}', style: TextStyle(color: auctionColor.withOpacity(0.8), fontFamily: 'Rajdhani', fontSize: 11)),
                ]),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _imagePlaceholder(Color color) => Container(
    height: 160, width: double.infinity,
    decoration: BoxDecoration(color: color.withOpacity(0.08)),
    child: Icon(Icons.image_outlined, color: color.withOpacity(0.3), size: 48),
  );

  Widget _badge(String text, Color color, {IconData? icon}) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(8), border: Border.all(color: color.withOpacity(0.4))),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      if (icon != null) ...[
        Icon(icon, size: 11, color: color),
        const SizedBox(width: 4),
      ],
      Text(text, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 11)),
    ]),
  );

  // ── Tab My Items ─────────────────────────────────────────────
  Widget _buildMyItemsTab(Color primary) {
    return _loading
      ? Center(child: CircularProgressIndicator(color: primary))
      : _myItems.isEmpty
        ? _empty('Belum ada barang yang dijual\nTekan tombol JUAL untuk mulai!', Icons.storefront_outlined, primary)
        : RefreshIndicator(
            color: primary,
            onRefresh: _loadData,
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
              itemCount: _myItems.length,
              itemBuilder: (ctx, i) => _myItemCard(_myItems[i], primary),
            ),
          );
  }

  Widget _myItemCard(MarketItem item, Color primary) {
    final statusColor = item.status == 'active' ? Colors.green : item.status == 'sold' ? Colors.orange : Colors.red;
    final statusLabel = item.status == 'active' ? 'AKTIF' : item.status == 'sold' ? 'TERJUAL' : 'DITUTUP';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0D0D0D),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: primary.withOpacity(0.15)),
      ),
      child: Row(children: [
        // Thumb
        Container(
          width: 60, height: 60,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: primary.withOpacity(0.08)),
          child: item.imageUrl != null
            ? ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(item.imageUrl!, fit: BoxFit.cover))
            : Icon(Icons.storefront_outlined, color: primary.withOpacity(0.4), size: 28),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item.title, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15), maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 2),
          Text(_fmtRupiah(item.type == 'auction' ? (item.highestBid ?? item.price) : item.price), style: TextStyle(color: primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 4),
          Row(children: [
            _badge(item.type == 'auction' ? 'Lelang' : 'Fixed', item.type == 'auction' ? Colors.purple : Colors.teal, icon: item.type == 'auction' ? Icons.gavel_rounded : Icons.sell_rounded),
            const SizedBox(width: 6),
            _badge(statusLabel, statusColor),
          ]),
        ])),
        // Delete button
        if (item.status == 'active')
          GestureDetector(
            onTap: () => _deleteItem(item, primary),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.red.withOpacity(0.3))),
              child: const Icon(Icons.delete_outline_rounded, color: Colors.red, size: 18),
            ),
          ),
      ]),
    );
  }


  // ── Tab Rekber ───────────────────────────────────────────────
  Widget _buildRekberTab(Color primary) {
    return FutureBuilder<http.Response>(
      future: http.get(Uri.parse('${AppConfig.baseUrl}/api/marketplace/rekber'), headers: {'x-session-key': widget.sessionKey}),
      builder: (ctx, snap) {
        if (!snap.hasData) return Center(child: CircularProgressIndicator(color: primary));
        final data = jsonDecode(snap.data!.body);
        final rekbers = (data['rekbers'] as List? ?? []);
        if (rekbers.isEmpty) return _empty('Belum ada transaksi rekber\nTekan REKBER/MC di detail produk', Icons.handshake_outlined, Colors.amber);
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
          itemCount: rekbers.length,
          itemBuilder: (ctx, i) {
            final r = rekbers[i];
            final isBuyer = r['buyerUsername'] == widget.username;
            final status = r['status'] as String;
            final statusColor = status == 'pending' ? Colors.orange : status == 'released' ? Colors.green : Colors.red;
            final statusLabel = status == 'pending' ? 'MENUNGGU' : status == 'released' ? 'SELESAI' : 'DIBATALKAN';
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF0D0D0D),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.amber.withOpacity(0.2)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Icon(Icons.handshake_outlined, color: Colors.amber, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: Text(r['itemTitle'] ?? 'Transaksi Manual', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15), maxLines: 1, overflow: TextOverflow.ellipsis)),
                  _badge(statusLabel, statusColor),
                ]),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Buyer: @${r['buyerUsername']}', style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 12)),
                    Text('Seller: @${r['sellerUsername']}', style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 12)),
                  ])),
                  Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text(_fmtRupiah((r['amount'] as num).toInt()), style: const TextStyle(color: Colors.amber, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16)),
                    Text(isBuyer ? 'Kamu: Buyer' : 'Kamu: Seller', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11)),
                  ]),
                ]),
                if (status == 'pending') ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: Colors.amber.withOpacity(0.05), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.amber.withOpacity(0.2))),
                    child: Row(children: [
                      const Icon(Icons.lock_outline_rounded, color: Colors.amber, size: 14),
                      const SizedBox(width: 8),
                      const Expanded(child: Text('Dana di-hold sistem, menunggu konfirmasi admin', style: TextStyle(color: Colors.amber, fontFamily: 'Rajdhani', fontSize: 11))),
                    ]),
                  ),
                ],
              ]),
            );
          },
        );
      },
    );
  }

  // ── Rekber Dialog ────────────────────────────────────────────
  void _showRekberDialog(BuildContext context, MarketItem item, Color primary) {
    final amountCtrl = TextEditingController(text: item.type == 'fixed' ? item.price.toString() : (item.highestBid ?? item.price).toString());

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          decoration: const BoxDecoration(
            color: Color(0xFF0D0D0D),
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            border: Border(top: BorderSide(color: Colors.amber, width: 1)),
          ),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 30),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 16),
            const Row(children: [
              Icon(Icons.handshake_outlined, color: Colors.amber, size: 22),
              SizedBox(width: 10),
              Text('REQUEST REKBER / MC', style: TextStyle(color: Colors.amber, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 18)),
            ]),
            const SizedBox(height: 6),
            const Text('Dana akan di-hold sistem. Admin akan memverifikasi transaksi sebelum dana dilepas ke seller.', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
            const SizedBox(height: 16),
            _infoRow('Produk', item.title, Icons.label_outline_rounded, Colors.amber),
            _infoRow('Seller', '@${item.sellerUsername}', Icons.person_outline_rounded, Colors.amber),
            _infoRow('Saldo kamu', _fmtRupiah(_walletBalance), Icons.account_balance_wallet_outlined, Colors.amber),
            const SizedBox(height: 10),
            _field(amountCtrl, 'Jumlah Dana', Icons.payments_outlined, Colors.amber, isNumber: true),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity, height: 50,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.amber, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                icon: const Icon(Icons.lock_outline_rounded, color: Colors.black),
                label: const Text('HOLD DANA & REQUEST MC', style: TextStyle(color: Colors.black, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 14)),
                onPressed: () async {
                  final amount = int.tryParse(amountCtrl.text);
                  if (amount == null || amount < 1000) { _toast('Jumlah tidak valid'); return; }
                  Navigator.pop(context);
                  await _requestRekber(item, amount, primary);
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Future<void> _requestRekber(MarketItem item, int amount, Color primary) async {
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/marketplace/rekber'),
        headers: {'x-session-key': widget.sessionKey, 'Content-Type': 'application/json'},
        body: jsonEncode({
          'itemId': item.id,
          'itemTitle': item.title,
          'sellerUsername': item.sellerUsername,
          'amount': amount,
        }),
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _toast('Rekber dibuat! Dana di-hold. Admin akan menghubungi.');
        setState(() => _tab.animateTo(2));
      } else {
        _toast(data['message'] ?? 'Gagal membuat rekber');
      }
    } catch (_) { _toast('Gagal konek ke server'); }
  }

  // ── Tab History ──────────────────────────────────────────────
  Widget _buildHistoryTab(Color primary) {
    return FutureBuilder<http.Response>(
      future: http.get(Uri.parse('${AppConfig.baseUrl}/api/marketplace/transactions'), headers: {'x-session-key': widget.sessionKey}),
      builder: (ctx, snap) {
        if (!snap.hasData) return Center(child: CircularProgressIndicator(color: primary));
        final data = jsonDecode(snap.data!.body);
        final txs = (data['transactions'] as List? ?? []);
        if (txs.isEmpty) return _empty('Belum ada transaksi', Icons.receipt_long_outlined, primary);
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
          itemCount: txs.length,
          itemBuilder: (ctx, i) {
            final tx = txs[i];
            final isBuyer = tx['buyerUsername'] == widget.username;
            final color = isBuyer ? Colors.red : Colors.green;
            final label = isBuyer ? 'BELI' : 'JUAL';
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF0D0D0D),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: color.withOpacity(0.2)),
              ),
              child: Row(children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.15)),
                  child: Icon(isBuyer ? Icons.shopping_cart_outlined : Icons.sell_outlined, color: color, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(tx['itemTitle'] ?? '-', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14)),
                  Text('${isBuyer ? "Dari: ${tx['sellerUsername']}" : "Ke: ${tx['buyerUsername']}"}', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  _badge(label, color),
                  const SizedBox(height: 4),
                  Text(_fmtRupiah((tx['amount'] as num).toInt()), style: TextStyle(color: color, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14)),
                ]),
              ]),
            );
          },
        );
      },
    );
  }

  // ── Empty state ──────────────────────────────────────────────
  Widget _empty(String msg, IconData icon, Color primary) => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, color: primary.withOpacity(0.3), size: 64),
      const SizedBox(height: 16),
      Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 14)),
    ]),
  );

  // ═══════════════════════════════════════════════════════════════
  //  DIALOGS
  // ═══════════════════════════════════════════════════════════════

  // ── Detail Item ──────────────────────────────────────────────
  void _showItemDetail(BuildContext context, MarketItem item, Color primary) {
    final isAuction = item.type == 'auction';
    final bidCtrl = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => StatefulBuilder(builder: (ctx, setS) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.85,
          decoration: BoxDecoration(
            color: const Color(0xFF0D0D0D),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            border: Border.all(color: primary.withOpacity(0.2)),
          ),
          child: Column(children: [
            Container(width: 40, height: 4, margin: const EdgeInsets.only(top: 12), decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  // Image
                  if (item.imageUrl != null)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.network(item.imageUrl!, width: double.infinity, height: 200, fit: BoxFit.cover),
                    ),
                  const SizedBox(height: 16),
                  // Title & badges
                  Row(children: [
                    _badge(item.category == 'digital' ? 'Digital' : 'Fisik', item.category == 'digital' ? Colors.cyan : Colors.orange, icon: item.category == 'digital' ? Icons.bolt_rounded : Icons.inventory_2_rounded),
                    const SizedBox(width: 8),
                    if (isAuction) _badge('Lelang', Colors.purple, icon: Icons.gavel_rounded),
                  ]),
                  const SizedBox(height: 10),
                  Text(item.title, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 22)),
                  const SizedBox(height: 8),
                  Text(item.desc, style: const TextStyle(color: Colors.white60, fontFamily: 'Rajdhani', fontSize: 14)),
                  const SizedBox(height: 16),
                  // Info row
                  _infoRow('Seller', '@${item.sellerUsername}', Icons.person_outline_rounded, primary),
                  if (!isAuction) _infoRow('Stok', '${item.stock}', Icons.inventory_2_outlined, primary),
                  if (isAuction && item.auctionEnd != null)
                    _infoRow('Berakhir', _countdown(item.auctionEnd!), Icons.timer_outlined, Colors.red),
                  const SizedBox(height: 16),
                  // Harga
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: primary.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: primary.withOpacity(0.2)),
                    ),
                    child: Column(children: [
                      if (isAuction) ...[
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          const Text('Harga Awal', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13)),
                          Text(_fmtRupiah(item.price), style: const TextStyle(color: Colors.white60, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
                        ]),
                        const SizedBox(height: 6),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          const Text('Bid Tertinggi', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13)),
                          Text(_fmtRupiah(item.highestBid ?? item.price), style: TextStyle(color: Colors.purple, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 18)),
                        ]),
                        if (item.highestBidder != null) ...[
                          const SizedBox(height: 4),
                          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                            const Text('Bidder', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
                            Text('@${item.highestBidder}', style: const TextStyle(color: Colors.purple, fontFamily: 'Rajdhani', fontSize: 12)),
                          ]),
                        ],
                        // Input bid
                        const SizedBox(height: 12),
                        TextField(
                          controller: bidCtrl,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani'),
                          decoration: InputDecoration(
                            hintText: 'Masukkan jumlah bid...',
                            hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani'),
                            prefixText: 'Rp ',
                            prefixStyle: TextStyle(color: primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold),
                            filled: true,
                            fillColor: Colors.black,
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: primary.withOpacity(0.3))),
                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: primary.withOpacity(0.3))),
                            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: primary)),
                          ),
                        ),
                      ] else
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          const Text('Harga', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13)),
                          Text(_fmtRupiah(item.price), style: TextStyle(color: primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 22)),
                        ]),
                    ]),
                  ),
                  const SizedBox(height: 8),
                  // Saldo info
                  Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Text('Saldo kamu: ${_fmtRupiah(_walletBalance)}', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
                  ]),
                  const SizedBox(height: 20),
                  // Skip kalau seller sendiri
                  if (item.sellerUsername != widget.username) ...[
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isAuction ? Colors.purple : primary,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: () {
                          Navigator.pop(ctx);
                          if (isAuction) {
                            final bid = int.tryParse(bidCtrl.text);
                            if (bid == null) { _toast('Masukkan jumlah bid dulu!'); return; }
                            _placeBid(item, bid, primary);
                          } else {
                            _buyItem(item, primary);
                          }
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(isAuction ? Icons.gavel_rounded : Icons.shopping_cart_rounded, color: Colors.white, size: 18),
                            const SizedBox(width: 8),
                            Text(
                              isAuction ? 'PASANG BID' : 'BELI SEKARANG',
                              style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ] else
                    Center(child: Text('Ini barang jualan kamu', style: TextStyle(color: primary.withOpacity(0.5), fontFamily: 'Rajdhani', fontSize: 13))),
                  const SizedBox(height: 10),
                  if (item.sellerUsername != widget.username)
                    SizedBox(
                      width: double.infinity, height: 46,
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.amber,
                          side: const BorderSide(color: Colors.amber),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        icon: const Icon(Icons.handshake_outlined, size: 18),
                        label: const Text('REKBER / MC', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 14)),
                        onPressed: () {
                          Navigator.pop(ctx);
                          _showRekberDialog(context, item, primary);
                        },
                      ),
                    ),
                ]),
              ),
            ),
          ]),
        );
      }),
    );
  }

  Widget _infoRow(String label, String val, IconData icon, Color color) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Row(children: [
      Icon(icon, color: color, size: 16),
      const SizedBox(width: 8),
      Text('$label: ', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13)),
      Expanded(child: Text(val, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13))),
    ]),
  );

  // ── Sell Dialog ──────────────────────────────────────────────
  void _showSellDialog(BuildContext context, Color primary) {
    final titleCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final priceCtrl = TextEditingController();
    final stockCtrl = TextEditingController(text: '1');
    final imageCtrl = TextEditingController();
    String category = 'digital';
    String type = 'fixed';
    DateTime? auctionEnd;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => StatefulBuilder(builder: (ctx, setS) {
        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF0D0D0D),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border.all(color: primary.withOpacity(0.2)),
            ),
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 30),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)))),
                const SizedBox(height: 16),
                Text('JUAL BARANG', style: TextStyle(color: primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 1)),
                const SizedBox(height: 16),
                // Category toggle
                Row(children: [
                  Expanded(child: _toggleBtn('Digital', category == 'digital', Colors.cyan, () => setS(() => category = 'digital'), icon: Icons.bolt_rounded)),
                  const SizedBox(width: 10),
                  Expanded(child: _toggleBtn('Fisik', category == 'fisik', Colors.orange, () => setS(() => category = 'fisik'), icon: Icons.inventory_2_rounded)),
                ]),
                const SizedBox(height: 10),
                // Type toggle
                Row(children: [
                  Expanded(child: _toggleBtn('Harga Tetap', type == 'fixed', Colors.teal, () => setS(() => type = 'fixed'), icon: Icons.sell_rounded)),
                  const SizedBox(width: 10),
                  Expanded(child: _toggleBtn('Lelang', type == 'auction', Colors.purple, () => setS(() => type = 'auction'), icon: Icons.gavel_rounded)),
                ]),
                const SizedBox(height: 14),
                _field(titleCtrl, 'Nama Produk', Icons.label_outline_rounded, primary),
                const SizedBox(height: 10),
                _field(descCtrl, 'Deskripsi', Icons.description_outlined, primary, maxLines: 3),
                const SizedBox(height: 10),
                _field(priceCtrl, type == 'auction' ? 'Harga Awal' : 'Harga', Icons.attach_money_rounded, primary, isNumber: true),
                const SizedBox(height: 10),
                if (type == 'fixed')
                  _field(stockCtrl, 'Stok', Icons.inventory_2_outlined, primary, isNumber: true),
                if (type == 'auction') ...[
                  const SizedBox(height: 4),
                  GestureDetector(
                    onTap: () async {
                      final date = await showDatePicker(context: context, initialDate: DateTime.now().add(const Duration(days: 1)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 30)));
                      if (date != null) setS(() => auctionEnd = date.add(const Duration(hours: 23, minutes: 59)));
                    },
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: auctionEnd != null ? Colors.purple : Colors.white24),
                      ),
                      child: Row(children: [
                        Icon(Icons.event_outlined, color: auctionEnd != null ? Colors.purple : Colors.white38, size: 18),
                        const SizedBox(width: 10),
                        Text(
                          auctionEnd != null ? 'Berakhir: ${auctionEnd!.day}/${auctionEnd!.month}/${auctionEnd!.year}' : 'Pilih tanggal berakhir lelang',
                          style: TextStyle(color: auctionEnd != null ? Colors.purple : Colors.white38, fontFamily: 'Rajdhani', fontSize: 14),
                        ),
                      ]),
                    ),
                  ),
                ],
                const SizedBox(height: 10),
                _field(imageCtrl, 'URL Gambar (opsional)', Icons.image_outlined, primary),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                    onPressed: () async {
                      if (titleCtrl.text.isEmpty || priceCtrl.text.isEmpty) { _toast('Isi nama dan harga dulu!'); return; }
                      Navigator.pop(ctx);
                      await _submitItem(
                        title: titleCtrl.text,
                        desc: descCtrl.text,
                        category: category,
                        type: type,
                        price: int.tryParse(priceCtrl.text) ?? 0,
                        stock: int.tryParse(stockCtrl.text) ?? 1,
                        imageUrl: imageCtrl.text.isEmpty ? null : imageCtrl.text,
                        auctionEnd: auctionEnd,
                        primary: primary,
                      );
                    },
                    child: Text('PASANG IKLAN', style: const TextStyle(color: Colors.black, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16)),
                  ),
                ),
              ]),
            ),
          ),
        );
      }),
    );
  }

  Widget _toggleBtn(String label, bool active, Color color, VoidCallback onTap, {IconData? icon}) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: active ? color.withOpacity(0.2) : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: active ? color : Colors.white24),
      ),
      child: Center(child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[
          Icon(icon, size: 14, color: active ? color : Colors.white54),
          const SizedBox(width: 6),
        ],
        Text(label, style: TextStyle(color: active ? color : Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13)),
      ])),
    ),
  );

  Widget _field(TextEditingController ctrl, String hint, IconData icon, Color primary, {int maxLines = 1, bool isNumber = false}) => TextField(
    controller: ctrl,
    maxLines: maxLines,
    keyboardType: isNumber ? TextInputType.number : TextInputType.text,
    inputFormatters: isNumber ? [FilteringTextInputFormatter.digitsOnly] : [],
    style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani'),
    decoration: InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani'),
      prefixIcon: Icon(icon, color: primary.withOpacity(0.6), size: 18),
      filled: true,
      fillColor: Colors.black,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: primary.withOpacity(0.3))),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white12)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: primary)),
    ),
  );

  // ── Top Up Saldo (halaman QRIS) ─────────────────────────────
  Future<void> _openTopUp(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => TopUpPage(sessionKey: widget.sessionKey, currentBalance: _walletBalance)),
    );
    if (result is int) {
      setState(() => _walletBalance = result);
    }
    _loadData();
  }

  // ═══════════════════════════════════════════════════════════════
  //  API CALLS
  // ═══════════════════════════════════════════════════════════════
  Future<void> _submitItem({required String title, required String desc, required String category, required String type, required int price, required int stock, String? imageUrl, DateTime? auctionEnd, required Color primary}) async {
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/marketplace/items'),
        headers: {'x-session-key': widget.sessionKey, 'Content-Type': 'application/json'},
        body: jsonEncode({
          'title': title, 'desc': desc, 'category': category, 'type': type,
          'price': price, 'stock': stock, 'imageUrl': imageUrl,
          'auctionEnd': auctionEnd?.toIso8601String(),
        }),
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _toast('Barang berhasil dipasang!');
        _loadData();
      } else {
        _toast(data['message'] ?? 'Gagal memasang barang');
      }
    } catch (_) { _toast('Gagal konek ke server'); }
  }

  Future<void> _buyItem(MarketItem item, Color primary) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF111111),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Konfirmasi Beli', style: TextStyle(color: primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900)),
        content: Text('Beli "${item.title}" seharga ${_fmtRupiah(item.price)}?\nSaldo kamu: ${_fmtRupiah(_walletBalance)}', style: const TextStyle(color: Colors.white70, fontFamily: 'Rajdhani')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani'))),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), style: ElevatedButton.styleFrom(backgroundColor: primary), child: const Text('Beli', style: TextStyle(color: Colors.black, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold))),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/marketplace/buy/${item.id}'),
        headers: {'x-session-key': widget.sessionKey},
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) { _toast('Pembelian berhasil!'); _loadData(); }
      else _toast(data['message'] ?? 'Gagal membeli');
    } catch (_) { _toast('Gagal konek ke server'); }
  }

  Future<void> _placeBid(MarketItem item, int bid, Color primary) async {
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/marketplace/bid/${item.id}'),
        headers: {'x-session-key': widget.sessionKey, 'Content-Type': 'application/json'},
        body: jsonEncode({'bid': bid}),
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) { _toast('Bid berhasil dipasang!'); _loadData(); }
      else _toast(data['message'] ?? 'Gagal bid');
    } catch (_) { _toast('Gagal konek ke server'); }
  }

  Future<void> _deleteItem(MarketItem item, Color primary) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF111111),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Hapus Barang?', style: TextStyle(color: Colors.red, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900)),
        content: Text('Yakin hapus "${item.title}"?', style: const TextStyle(color: Colors.white70, fontFamily: 'Rajdhani')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani'))),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), style: ElevatedButton.styleFrom(backgroundColor: Colors.red), child: const Text('Hapus', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold))),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      final res = await http.delete(Uri.parse('${AppConfig.baseUrl}/api/marketplace/items/${item.id}'), headers: {'x-session-key': widget.sessionKey});
      final data = jsonDecode(res.body);
      if (data['success'] == true) { _toast('Barang dihapus'); _loadData(); }
      else _toast(data['message'] ?? 'Gagal hapus');
    } catch (_) { _toast('Gagal konek ke server'); }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
      backgroundColor: const Color(0xFF1A1A1A),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }
}
