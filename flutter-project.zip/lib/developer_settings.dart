// ignore_for_file: use_build_context_synchronously
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';

// ── Palette Dominus ───────────────────────────────────────────────────────────
const _bg     = Color(0xFF080D14);
const _card   = Color(0xFF0D1520);
const _card2  = Color(0xFF111C2B);
const _border = Color(0xFF1C2C3E);
const _red    = Color(0xFFFF1744);
const _cyan   = Color(0xFF00E5FF);
const _green  = Color(0xFF00E676);
const _orange = Color(0xFFFF9100);
const _purple = Color(0xFF7C4DFF);
const _white  = Colors.white;

class DeveloperSettingsPage extends StatefulWidget {
  final String currentBaseUrl;
  final Function(String) onBaseUrlChanged;
  const DeveloperSettingsPage({Key? key, required this.currentBaseUrl, required this.onBaseUrlChanged}) : super(key: key);
  @override
  State<DeveloperSettingsPage> createState() => _DeveloperSettingsPageState();
}

class _DeveloperSettingsPageState extends State<DeveloperSettingsPage>
    with TickerProviderStateMixin {

  // Auth
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _urlCtrl  = TextEditingController();
  final _telegramOwnerCtrl = TextEditingController(text: '@ytimlou');
  String _buyMode = 'app'; // 'app' atau 'telegram'
  bool _showPass = false;
  bool _authed   = false;
  static const _devUser = 'Danielnox';
  static const _devPass = 'kacung';

  // Stats saat ini
  bool _online      = false;
  bool _loading     = false;
  bool _restarting  = false;
  int  _cpu = 0, _ram = 0, _disk = 0;
  int  _ramUsed = 0, _ramTotal = 0;
  int  _uptime      = 0;
  int  _totalUser   = 0;
  int  _totalOrder  = 0;

  // Diskon per role
  Map<String, dynamic> _discounts = {};
  bool _discountLoading = false;
  bool _calcOpen = false;

  // Kuota per role (null/gak ada = "-", 0 = unlimited, >0 = sisa stok)
  Map<String, dynamic> _quotas = {};
  bool _quotaLoading = false;
  final Map<String, TextEditingController> _quotaCtrl = {};
  final _allQuotaCtrl = TextEditingController();

  // Kelola User
  List<dynamic> _allUsers = [];
  bool _usersLoading = false;
  String _userSearch = '';
  String _userRoleFilter = 'all';
  String _userViewMode = 'active'; // 'active' | 'deleted'
  final _userSearchCtrl = TextEditingController();
  final _calcHargaCtrl = TextEditingController();
  // Voucher
  final _vNominalCtrl = TextEditingController();
  final _vPrefixCtrl  = TextEditingController();
  final _vLimitCtrl   = TextEditingController();
  final _vExpiryCtrl  = TextEditingController();
  bool    _vLoading   = false;
  String? _vResult;
  String? _vError;
  final _calcPctCtrl   = TextEditingController();
  final _allDiscCtrl   = TextEditingController(); // Fix: harus di state bukan di build
  int _calcResult      = 0;
  int _calcSaving      = 0;
  final List<String> _roles = ['member', 'reseller', 'vip', 'owner', 'partner', 'staff', 'kingz'];
  final Map<String, TextEditingController> _discCtrl = {};
  int  _pending     = 0;
  int  _approved    = 0;
  int  _rejected    = 0;

  // History buat grafik (maks 20 titik)
  final List<double> _cpuHistory  = [];
  final List<double> _ramHistory  = [];
  final List<double> _diskHistory = [];
  final List<bool>   _pingHistory = [];

  Timer? _statsTimer;
  Timer? _uptimeTicker;
  late AnimationController _pulseCtrl;
  late AnimationController _shimCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);
    _shimCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat();
  }

  Future<void> _createVoucher() async {
    final nominal = int.tryParse(_vNominalCtrl.text.replaceAll('.', '')) ?? 0;
    if (nominal <= 0) { setState(() => _vError = 'Nominal wajib diisi'); return; }
    setState(() { _vLoading = true; _vError = null; _vResult = null; });
    try {
      final prefs = await SharedPreferences.getInstance();
      final sKey = prefs.getString('sessionKey') ?? '';
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/voucher/create'),
        headers: {'Content-Type': 'application/json', 'x-session-key': sKey},
        body: jsonEncode({
          'nominal': nominal,
          'prefix': _vPrefixCtrl.text.trim().toUpperCase(),
          'maxUse': int.tryParse(_vLimitCtrl.text) ?? 1,
          'expiryDays': int.tryParse(_vExpiryCtrl.text) ?? 30,
        }),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        setState(() => _vResult = data['voucher']?['code'] ?? '-');
        _vNominalCtrl.clear(); _vPrefixCtrl.clear(); _vLimitCtrl.clear(); _vExpiryCtrl.clear();
      } else {
        setState(() => _vError = data['message'] ?? 'Gagal membuat voucher');
      }
    } catch (_) {
      setState(() => _vError = 'Gagal terhubung ke server');
    }
    setState(() => _vLoading = false);
  }

  Widget _vField(String hint, TextEditingController ctrl, IconData icon, {bool isNumber = false}) {
    return _vFieldNew(hint, ctrl, icon, isNumber: isNumber);
  }

  Widget _vLabel(String text) {
    return Row(children: [
      Container(width: 3, height: 12, margin: const EdgeInsets.only(right: 7), decoration: BoxDecoration(color: const Color(0xFFFFB300), borderRadius: BorderRadius.circular(2))),
      Text(text, style: const TextStyle(color: Color(0xFFFFB300), fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
    ]);
  }

  Widget _vFieldNew(String hint, TextEditingController ctrl, IconData icon, {String? suffix, bool isNumber = false}) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF080D14),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFB300).withValues(alpha: 0.25)),
      ),
      child: TextField(
        controller: ctrl,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 14, fontWeight: FontWeight.w600),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 13),
          prefixIcon: Icon(icon, color: const Color(0xFFFFB300).withValues(alpha: 0.7), size: 17),
          suffixText: suffix,
          suffixStyle: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _userCtrl.dispose(); _passCtrl.dispose(); _urlCtrl.dispose();
    _calcHargaCtrl.dispose(); _calcPctCtrl.dispose(); _allDiscCtrl.dispose();
    _vNominalCtrl.dispose(); _vPrefixCtrl.dispose(); _vLimitCtrl.dispose(); _vExpiryCtrl.dispose();
    _discCtrl.forEach((_, c) => c.dispose());
    _quotaCtrl.forEach((_, c) => c.dispose());
    _allQuotaCtrl.dispose();
    _userSearchCtrl.dispose();
    _statsTimer?.cancel();
    _uptimeTicker?.cancel();
    _pulseCtrl.dispose(); _shimCtrl.dispose();
    super.dispose();
  }

  void _login() {
    if (_userCtrl.text.trim() == _devUser && _passCtrl.text == _devPass) {
      setState(() => _authed = true);
      for (final r in _roles) {
        _discCtrl[r] = TextEditingController();
        _quotaCtrl[r] = TextEditingController();
      }
      _fetchAll();
      _fetchDiscounts();
      _fetchQuotas();
      _fetchAllUsers();
      _loadBuySettings();
      _statsTimer = Timer.periodic(const Duration(seconds: 3), (_) => _fetchStats());
      // Banner stats (user/order) cukup tiap 30 detik
      Timer.periodic(const Duration(seconds: 30), (_) { if (mounted && _authed) _fetchBannerStats(); });
      // Tick uptime tiap detik secara lokal (biar gak perlu tunggu fetch)
      _uptimeTicker = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted && _online) setState(() => _uptime++);
      });
    } else {
      _snack('Kredensial salah!', _red);
    }
  }

  Future<void> _fetchDiscounts() async {
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/requestkey/discount'))
          .timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      if (mounted && d['success'] == true) {
        setState(() {
          _discounts = Map<String, dynamic>.from(d['discounts'] ?? {});
          for (final r in _roles) {
            _discCtrl[r]?.text = (_discounts[r] ?? 0).toString();
          }
        });
      }
    } catch (_) {}
  }

  Future<void> _saveDiscount(String role, int pct) async {
    setState(() => _discountLoading = true);
    try {
      await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/discount/set'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'role': role, 'pct': pct}),
      ).timeout(const Duration(seconds: 8));
      await _fetchDiscounts();
      _snack('Diskon $role → $pct% disimpan ✓', _green);
    } catch (_) {
      _snack('Gagal simpan diskon', _red);
    }
    if (mounted) setState(() => _discountLoading = false);
  }

  Future<void> _fetchQuotas() async {
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/requestkey/quota'))
          .timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      if (mounted && d['success'] == true) {
        setState(() {
          _quotas = Map<String, dynamic>.from(d['quotas'] ?? {});
          for (final r in _roles) {
            // gak ada key = belum diatur -> field dikosongin (tampil "-")
            _quotaCtrl[r]?.text = _quotas.containsKey(r) ? _quotas[r].toString() : '';
          }
        });
      }
    } catch (_) {}
  }

  // qty null = kosongin (jadi "-"), qty 0 = unlimited, qty >0 = sisa stok
  Future<void> _saveQuota(String role, int? qty) async {
    setState(() => _quotaLoading = true);
    try {
      await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/quota/set'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'role': role, 'qty': qty}),
      ).timeout(const Duration(seconds: 8));
      await _fetchQuotas();
      _snack('Kuota $role disimpan ✓', _green);
    } catch (_) {
      _snack('Gagal simpan kuota', _red);
    }
    if (mounted) setState(() => _quotaLoading = false);
  }

  Future<void> _saveQuotaAll(int? qty) async {
    setState(() => _quotaLoading = true);
    try {
      await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/quota/all'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'qty': qty}),
      ).timeout(const Duration(seconds: 8));
      await _fetchQuotas();
      _snack('Semua kuota disimpan ✓', _green);
    } catch (_) {
      _snack('Gagal simpan kuota', _red);
    }
    if (mounted) setState(() => _quotaLoading = false);
  }

  // ── Kelola User ──────────────────────────────────────────────
  Future<void> _fetchAllUsers() async {
    setState(() => _usersLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final sKey = prefs.getString('sessionKey') ?? '';
      final qp = <String, String>{'key': sKey};
      if (_userSearch.trim().isNotEmpty) qp['search'] = _userSearch.trim();
      if (_userRoleFilter != 'all') qp['role'] = _userRoleFilter;
      final endpoint = _userViewMode == 'deleted' ? 'listDeletedUsers' : 'listAllUsersAdmin';
      final uri = Uri.parse('${AppConfig.baseUrl}/api/user/$endpoint').replace(queryParameters: qp);
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (mounted && d['valid'] == true && d['authorized'] == true) {
        setState(() => _allUsers = d['users'] ?? []);
      }
    } catch (_) {}
    if (mounted) setState(() => _usersLoading = false);
  }

  Future<void> _deleteUserAccount(String username) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sKey = prefs.getString('sessionKey') ?? '';
      await http.get(Uri.parse('${AppConfig.baseUrl}/api/user/deleteUser?key=$sKey&username=$username'))
          .timeout(const Duration(seconds: 8));
      _snack('Akun $username dihapus ✓', _green);
      _fetchAllUsers();
    } catch (_) {
      _snack('Gagal hapus akun', _red);
    }
  }

  void _showUserDetail(Map user, {bool isDeleted = false}) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: isDeleted ? _red.withValues(alpha: 0.3) : _border)),
        title: Row(children: [
          Expanded(
            child: Text(user['username'] ?? '-', style: TextStyle(color: _white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, decoration: isDeleted ? TextDecoration.lineThrough : null)),
          ),
          if (isDeleted)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: _red.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6), border: Border.all(color: _red.withValues(alpha: 0.4))),
              child: const Text('DIHAPUS', style: TextStyle(color: _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 10)),
            ),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          _detailRow('Role', (user['role'] ?? '-').toString().toUpperCase()),
          _detailRow('Expired', user['expiredDate']?.toString() ?? '-'),
          _detailRow('Dibuat oleh', user['parent']?.toString() ?? '-'),
          if (!isDeleted) _detailRow('Device ID', user['deviceId']?.toString() ?? '-'),
          if (isDeleted) ...[
            _detailRow('Dihapus oleh', user['deletedBy']?.toString() ?? '-'),
            _detailRow('Tgl Dihapus', _formatLogDate(user['deletedAt']?.toString())),
          ],
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Tutup', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani'))),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.push(context, MaterialPageRoute(builder: (_) => _UserFullDetailPage(user: user, isDeleted: isDeleted)));
            },
            child: const Text('Detail Lengkap', style: TextStyle(color: _cyan, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
          ),
          if (!isDeleted)
            TextButton(
              onPressed: () { Navigator.pop(ctx); _confirmDeleteUser(user['username']); },
              child: const Text('Hapus', style: TextStyle(color: _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
            ),
        ],
      ),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        SizedBox(width: 90, child: Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12))),
        Expanded(child: Text(value, style: const TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 13, fontWeight: FontWeight.w600))),
      ]),
    );
  }

  void _confirmDeleteUser(String username) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: _border)),
        title: const Text('Hapus Akun?', style: TextStyle(color: _white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
        content: Text('Akun "$username" bakal dihapus permanen. Yakin?', style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani'))),
          TextButton(
            onPressed: () { Navigator.pop(ctx); _deleteUserAccount(username); },
            child: const Text('Hapus', style: TextStyle(color: _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<void> _saveDiscountAll(int pct) async {
    setState(() => _discountLoading = true);
    try {
      await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/discount/all'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'pct': pct}),
      ).timeout(const Duration(seconds: 8));
      await _fetchDiscounts();
      _snack('Diskon semua role → $pct% disimpan ✓', _green);
    } catch (_) {
      _snack('Gagal simpan diskon', _red);
    }
    if (mounted) setState(() => _discountLoading = false);
  }

  void _logout() {
    _statsTimer?.cancel();
    _uptimeTicker?.cancel();
    setState(() { _authed = false; _userCtrl.clear(); _passCtrl.clear(); });
  }

  Future<void> _fetchAll() async {
    await Future.wait([_fetchStats(), _fetchBannerStats()]);
  }

  Future<void> _fetchStats() async {
    if (mounted) setState(() => _loading = true);
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/server/stats'))
          .timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      if (mounted) setState(() {
        _online   = d['success'] == true;
        _cpu      = (d['cpu']      ?? 0) as int;
        _ram      = (d['ram']      ?? 0) as int;
        _ramUsed  = (d['ramUsed']  ?? 0) as int;
        _ramTotal = (d['ramTotal'] ?? 0) as int;
        _disk     = (d['disk']     ?? 0) as int;
        _uptime   = (d['uptime']   ?? 0) as int;
        _addHistory(_cpuHistory,  _cpu.toDouble());
        _addHistory(_ramHistory,  _ram.toDouble());
        _addHistory(_diskHistory, _disk.toDouble());
        _pingHistory.add(true);
        if (_pingHistory.length > 20) _pingHistory.removeAt(0);
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() {
        _online = false;
        _pingHistory.add(false);
        if (_pingHistory.length > 20) _pingHistory.removeAt(0);
        _loading = false;
      });
    }
  }

  Future<void> _fetchBannerStats() async {
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/requestkey/banner-stats'))
          .timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      if (mounted && d['success'] == true) setState(() {
        _totalUser  = (d['totalUser']  ?? 0) as int;
        _totalOrder = (d['totalOrder'] ?? 0) as int;
        _pending    = (d['pending']    ?? 0) as int;
        _approved   = (d['approved']   ?? 0) as int;
        _rejected   = (d['rejected']   ?? 0) as int;
      });
    } catch (_) {}
  }

  void _addHistory(List<double> list, double val) {
    list.add(val);
    if (list.length > 20) list.removeAt(0);
  }

  Future<void> _restartServer() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: _red)),
        title: const Text('Restart Server?', style: TextStyle(color: _white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 20)),
        content: const Text('Server akan mati sebentar lalu nyala otomatis via Pterodactyl.', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal', style: TextStyle(color: Colors.white38))),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: _red, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const Text('RESTART', style: TextStyle(color: _white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _restarting = true);
    try {
      await http.post(Uri.parse('${AppConfig.baseUrl}/api/server/restart'),
          headers: {'Content-Type': 'application/json'}).timeout(const Duration(seconds: 8));
      _snack('⚡ Server sedang restart...', _orange);
    } catch (_) {
      _snack('Sinyal restart terkirim', _orange);
    }
    if (mounted) setState(() => _restarting = false);
  }

  void _saveUrl() {
    if (_urlCtrl.text.isEmpty) { _snack('Masukkan URL dulu', _orange); return; }
    widget.onBaseUrlChanged(_urlCtrl.text.trim());
    _urlCtrl.clear();
    _snack('Base URL diubah ✓', _green);
  }

  Future<void> _loadBuySettings() async {
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/buy-settings'))
          .timeout(const Duration(seconds: 6));
      final d = jsonDecode(res.body);
      if (d['success'] == true && mounted) {
        setState(() {
          _buyMode = d['mode'] ?? 'app';
          if (d['telegramUsername'] != null) {
            _telegramOwnerCtrl.text = d['telegramUsername'];
          }
        });
      }
    } catch (_) {}
  }

  Future<void> _saveTelegramOwner() async {
    final username = _telegramOwnerCtrl.text.trim();
    if (username.isEmpty) { _snack('Masukkan username Telegram dulu', _orange); return; }
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/buy-settings/telegram-username'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'telegramUsername': username}),
      ).timeout(const Duration(seconds: 6));
      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        _snack('Username Telegram disimpan ✓', _green);
      }
    } catch (_) {
      _snack('Gagal simpan', _red);
    }
  }

  void _snack(String msg, Color color) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w600)),
    backgroundColor: color, behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    duration: const Duration(seconds: 2),
  ));

  String _fmt(int s) {
    final h = s ~/ 3600, m = (s % 3600) ~/ 60, sec = s % 60;
    return '${h.toString().padLeft(2,'0')}:${m.toString().padLeft(2,'0')}:${sec.toString().padLeft(2,'0')}';
  }

  // ── BUILD ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _red, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: _red.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: _red.withValues(alpha: 0.4)),
            ),
            child: const Icon(Icons.terminal_rounded, color: _red, size: 18),
          ),
          const SizedBox(width: 10),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('DEVELOPER', style: TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 15, fontWeight: FontWeight.bold, letterSpacing: 3)),
            Text('MONITOR', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 9, letterSpacing: 4)),
          ]),
        ]),
        actions: _authed ? [
          if (_loading)
            const Padding(padding: EdgeInsets.only(right: 16), child: Center(
              child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: _red, strokeWidth: 2)),
            ))
          else
            IconButton(icon: const Icon(Icons.refresh_rounded, color: Colors.white38), onPressed: _fetchAll),
        ] : [],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [Colors.transparent, _red, Colors.transparent]),
          )),
        ),
      ),
      body: Stack(children: [
        // Grid background
        Positioned.fill(child: CustomPaint(painter: _GridPainter())),
        _authed ? _buildDashboard() : _buildLogin(),
      ]),
    );
  }

  // ── LOGIN ─────────────────────────────────────────────────────────────────
  Widget _buildLogin() {
    return Stack(
      children: [
        // Background glow effects
        Positioned(top: -60, left: -60,
          child: AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              width: 280, height: 280,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  _red.withValues(alpha: _pulseCtrl.value * 0.12),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
        ),
        Positioned(bottom: 0, right: -80,
          child: Container(
            width: 220, height: 220,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [
                _red.withValues(alpha: 0.06),
                Colors.transparent,
              ]),
            ),
          ),
        ),

        // Content
        SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SizedBox(height: 36),

            // Top badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _red.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _red.withValues(alpha: 0.3)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 6, height: 6, decoration: const BoxDecoration(shape: BoxShape.circle, color: _red)),
                const SizedBox(width: 7),
                const Text('RESTRICTED ACCESS', style: TextStyle(color: _red, fontFamily: 'Rajdhani', fontSize: 10, letterSpacing: 3, fontWeight: FontWeight.bold)),
              ]),
            ),
            const SizedBox(height: 28),

            // Title
            const Text('DEVELOPER', style: TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 42, fontWeight: FontWeight.bold, letterSpacing: 2, height: 1)),
            Row(children: [
              const Text('ACCESS', style: TextStyle(color: _red, fontFamily: 'Rajdhani', fontSize: 42, fontWeight: FontWeight.bold, letterSpacing: 2)),
              const SizedBox(width: 12),
              // Animated underline
              Expanded(child: AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (_, __) => Container(
                  height: 2,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      _red.withValues(alpha: _pulseCtrl.value),
                      Colors.transparent,
                    ]),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              )),
            ]),
            const SizedBox(height: 10),
            const Text('Masukkan kredensial untuk melanjutkan', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13)),
            const SizedBox(height: 36),

            // Form card
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: _card,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _border),
                boxShadow: [
                  BoxShadow(color: _red.withValues(alpha: 0.08), blurRadius: 30, spreadRadius: 0),
                ],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                // Header form
                Row(children: [
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: _red.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _red.withValues(alpha: 0.3)),
                    ),
                    child: const Icon(Icons.security_rounded, color: _red, size: 18),
                  ),
                  const SizedBox(width: 12),
                  const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('AUTHENTIKASI', style: TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 2)),
                    Text('Developer credentials required', style: TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 10)),
                  ]),
                ]),

                const SizedBox(height: 22),
                Container(height: 1, color: _border),
                const SizedBox(height: 22),

                _field('Username', 'dev_username', _userCtrl, Icons.person_outline_rounded, false),
                const SizedBox(height: 14),
                _field('Password', '••••••••', _passCtrl, Icons.lock_outline_rounded, true),
                const SizedBox(height: 24),

                // Authenticate button
                SizedBox(width: double.infinity, height: 54,
                  child: ElevatedButton(
                    onPressed: _login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _red,
                      foregroundColor: _white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      elevation: 0,
                    ),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Icon(Icons.login_rounded, size: 18),
                      const SizedBox(width: 10),
                      const Text('AUTHENTICATE', style: TextStyle(fontFamily: 'Rajdhani', fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 3)),
                      const SizedBox(width: 10),
                      AnimatedBuilder(
                        animation: _pulseCtrl,
                        builder: (_, __) => Icon(Icons.arrow_forward_ios_rounded,
                          size: 12, color: _white.withValues(alpha: 0.4 + _pulseCtrl.value * 0.6)),
                      ),
                    ]),
                  ),
                ),
              ]),
            ),

            const SizedBox(height: 28),

            // Bottom warning
            Center(
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.warning_amber_rounded, color: Colors.white24, size: 12),
                const SizedBox(width: 6),
                const Text('Akses hanya untuk developer yang sah', style: TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 11)),
              ]),
            ),
            const SizedBox(height: 20),
          ]),
        ),
      ],
    );
  }

  Widget _field(String lbl, String hint, TextEditingController ctrl, IconData icon, bool isPass) =>
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(lbl, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11, letterSpacing: 2)),
      const SizedBox(height: 6),
      TextField(
        controller: ctrl,
        obscureText: isPass && !_showPass,
        style: const TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 14),
        onSubmitted: isPass ? (_) => _login() : null,
        decoration: InputDecoration(
          hintText: hint, hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani'),
          prefixIcon: Icon(icon, color: Colors.white38, size: 18),
          suffixIcon: isPass ? IconButton(
            icon: Icon(isPass && !_showPass ? Icons.visibility_outlined : Icons.visibility_off_outlined, color: Colors.white38, size: 18),
            onPressed: () => setState(() => _showPass = !_showPass),
          ) : null,
          filled: true, fillColor: _bg,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _border)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _border)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _red, width: 1.5)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    ]);

  // ── DASHBOARD ─────────────────────────────────────────────────────────────
  Widget _buildDashboard() => RefreshIndicator(
    color: _red, backgroundColor: _card, onRefresh: _fetchAll,
    child: SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 32),
      child: Column(children: [

        // ─ Status Banner ───────────────────────────────
        _statusBanner(),
        const SizedBox(height: 12),

        // ─ Uptime + Quick actions ──────────────────────
        Row(children: [
          Expanded(child: _quickCard(Icons.timer_outlined, 'UPTIME', _fmt(_uptime), _cyan)),
          const SizedBox(width: 10),
          Expanded(child: _quickCard(Icons.people_alt_rounded, 'TOTAL USER', '$_totalUser', _purple)),
          const SizedBox(width: 10),
          Expanded(child: _quickCard(Icons.receipt_long_rounded, 'TOTAL ORDER', '$_totalOrder', _orange)),
        ]),
        const SizedBox(height: 12),

        // ─ CPU Chart ───────────────────────────────────
        _lineChartCard('CPU USAGE', _cpuHistory, _cpu, _red, Icons.memory_rounded),
        const SizedBox(height: 10),

        // ─ RAM Chart ───────────────────────────────────
        _lineChartCard('RAM USAGE', _ramHistory, _ram, _cyan, Icons.developer_board_rounded,
            subtitle: '${_ramUsed}MB / ${_ramTotal}MB'),
        const SizedBox(height: 10),

        // ─ Disk Chart ──────────────────────────────────
        _lineChartCard('DISK USAGE', _diskHistory, _disk, _orange, Icons.storage_rounded),
        const SizedBox(height: 12),

        // ─ Ping History ────────────────────────────────
        _pingChartCard(),
        const SizedBox(height: 12),

        // ─ Order Breakdown ─────────────────────────────
        _orderCard(),
        const SizedBox(height: 12),

        // ─ URL Card ────────────────────────────────────
        _urlCard(),
        const SizedBox(height: 12),
        _telegramOwnerCard(),
        const SizedBox(height: 12),
        _discountCard(),
        const SizedBox(height: 12),
        _quotaCard(),
        const SizedBox(height: 12),
        _userManagementCard(),
        const SizedBox(height: 12),
        // ── Create Voucher ──────────────────────────────
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0D1016),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFFFB300).withValues(alpha: 0.3)),
            boxShadow: [BoxShadow(color: const Color(0xFFFFB300).withValues(alpha: 0.06), blurRadius: 20)],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [const Color(0xFFFFB300).withValues(alpha: 0.15), Colors.transparent], begin: Alignment.centerLeft, end: Alignment.centerRight),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                border: const Border(bottom: BorderSide(color: Color(0xFF1E1E1E))),
              ),
              child: Row(children: [
                Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFB300).withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFFFFB300).withValues(alpha: 0.4)),
                  ),
                  child: const Icon(Icons.confirmation_number_rounded, color: Color(0xFFFFB300), size: 18),
                ),
                const SizedBox(width: 12),
                const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('CREATE VOUCHER', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1.5)),
                  Text('Generate kode diskon eksklusif', style: TextStyle(color: Color(0xFFFFB300), fontFamily: 'Rajdhani', fontSize: 10)),
                ]),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _vLabel('NOMINAL DISKON'),
                const SizedBox(height: 8),
                _vFieldNew('Contoh: 10000', _vNominalCtrl, Icons.payments_rounded, isNumber: true),
                const SizedBox(height: 16),
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    _vLabel('PREFIX'),
                    const SizedBox(height: 8),
                    _vFieldNew('DC', _vPrefixCtrl, Icons.tag_rounded),
                  ])),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    _vLabel('MAX PAKAI'),
                    const SizedBox(height: 8),
                    _vFieldNew('10', _vLimitCtrl, Icons.repeat_rounded, isNumber: true),
                  ])),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    _vLabel('EXPIRY HARI'),
                    const SizedBox(height: 8),
                    _vFieldNew('30', _vExpiryCtrl, Icons.timer_rounded, isNumber: true),
                  ])),
                ]),
                const SizedBox(height: 14),
                if (_vError != null) ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: _red.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(12), border: Border.all(color: _red.withValues(alpha: 0.3))),
                    child: Row(children: [
                      const Icon(Icons.error_outline_rounded, color: _red, size: 16),
                      const SizedBox(width: 8),
                      Expanded(child: Text(_vError!, style: const TextStyle(color: _red, fontFamily: 'Rajdhani', fontSize: 13))),
                    ]),
                  ),
                  const SizedBox(height: 12),
                ],
                if (_vResult != null) ...[
                  GestureDetector(
                    onTap: () {
                      Clipboard.setData(ClipboardData(text: _vResult!));
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Kode disalin!', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
                        backgroundColor: Color(0xFF22C55E), behavior: SnackBarBehavior.floating, duration: Duration(seconds: 1),
                      ));
                    },
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: const Color(0xFF22C55E).withValues(alpha: 0.06),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFF22C55E).withValues(alpha: 0.4)),
                      ),
                      child: Column(children: [
                        const Text('VOUCHER BERHASIL DIBUAT', style: TextStyle(color: Color(0xFF22C55E), fontFamily: 'Rajdhani', fontSize: 11, letterSpacing: 1.5)),
                        const SizedBox(height: 8),
                        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Text(_vResult!, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 24, letterSpacing: 5)),
                          const SizedBox(width: 10),
                          const Icon(Icons.copy_rounded, color: Color(0xFF22C55E), size: 16),
                        ]),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
                GestureDetector(
                  onTap: _vLoading ? null : _createVoucher,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFFFFB300), Color(0xFFE65100)], begin: Alignment.centerLeft, end: Alignment.centerRight),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [BoxShadow(color: const Color(0xFFFFB300).withValues(alpha: 0.35), blurRadius: 14, offset: const Offset(0, 5))],
                    ),
                    child: _vLoading
                        ? const Center(child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)))
                        : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 20),
                            SizedBox(width: 10),
                            Text('GENERATE VOUCHER', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 2)),
                          ]),
                  ),
                ),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 14),

        // ─ Restart ─────────────────────────────────────
        _restartCard(),
        const SizedBox(height: 12),

        // ─ Logout ──────────────────────────────────────
        SizedBox(width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: _logout,
            icon: const Icon(Icons.logout_rounded, size: 16, color: Colors.white38),
            label: const Text('LOGOUT', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', letterSpacing: 2)),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: _border),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
      ]),
    ),
  );

  Widget _statusBanner() {
    final color = _online ? _green : _red;
    final label = _online ? 'ONLINE' : 'OFFLINE';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: _card, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.5)),
        boxShadow: [BoxShadow(color: color.withValues(alpha: 0.1), blurRadius: 20)],
      ),
      child: Row(children: [
        AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, __) => Container(
            width: 14, height: 14,
            decoration: BoxDecoration(
              shape: BoxShape.circle, color: _online ? _green : Colors.white24,
              boxShadow: _online ? [BoxShadow(color: _green.withValues(alpha: _pulseCtrl.value * 0.7), blurRadius: 12, spreadRadius: 2)] : [],
            ),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('SERVER STATUS', style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 10, letterSpacing: 3, fontWeight: FontWeight.bold)),
          Text(label, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 24, fontWeight: FontWeight.bold)),
        ])),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
          child: Text(_online ? 'RUNNING' : 'DOWN', style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2)),
        ),
      ]),
    );
  }

  Widget _quickCard(IconData icon, String lbl, String val, Color color) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: color, size: 18),
      const SizedBox(height: 8),
      Text(val, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 2),
      Text(lbl, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 9, letterSpacing: 1)),
    ]),
  );

  Widget _lineChartCard(String title, List<double> history, int current, Color color, IconData icon, {String? subtitle}) =>
    Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 8),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _label(title),
            if (subtitle != null)
              Text(subtitle, style: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 10)),
          ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
            child: Text('$current%', style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 13, fontWeight: FontWeight.bold)),
          ),
        ]),
        const SizedBox(height: 14),
        // Progress bar
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: current / 100,
            backgroundColor: _border,
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 6,
          ),
        ),
        const SizedBox(height: 14),
        // Line chart
        SizedBox(
          height: 60,
          child: history.length < 2
              ? Center(child: Text('Mengumpulkan data...', style: TextStyle(color: color.withValues(alpha: 0.4), fontFamily: 'Rajdhani', fontSize: 11)))
              : CustomPaint(
                  size: Size.infinite,
                  painter: _LineChartPainter(history, color),
                ),
        ),
      ]),
    );

  Widget _pingChartCard() => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Icon(Icons.wifi_rounded, color: _cyan, size: 16),
        const SizedBox(width: 8),
        _label('PING HISTORY'),
        const Spacer(),
        Row(children: [
          _dot(_green, 'Online'),
          const SizedBox(width: 12),
          _dot(_red, 'Offline'),
        ]),
      ]),
      const SizedBox(height: 14),
      SizedBox(
        height: 56,
        child: _pingHistory.isEmpty
            ? Center(child: Text('Belum ada data', style: TextStyle(color: _cyan.withValues(alpha: 0.4), fontFamily: 'Rajdhani', fontSize: 11)))
            : Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: List.generate(20, (i) {
                  final idx = _pingHistory.length - 20 + i;
                  final hasData = idx >= 0 && idx < _pingHistory.length;
                  final isOnline = hasData ? _pingHistory[idx] : null;
                  return Expanded(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      margin: const EdgeInsets.symmetric(horizontal: 1.5),
                      height: isOnline == null ? 6 : (isOnline ? 48 : 12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color: isOnline == null ? _border
                            : (isOnline ? _green.withValues(alpha: 0.85) : _red.withValues(alpha: 0.75)),
                        boxShadow: (isOnline == true) ? [BoxShadow(color: _green.withValues(alpha: 0.3), blurRadius: 6)] : [],
                      ),
                    ),
                  );
                }),
              ),
      ),
    ]),
  );

  Widget _orderCard() {
    final total = _totalOrder == 0 ? 1 : _totalOrder;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.bar_chart_rounded, color: _orange, size: 16),
          const SizedBox(width: 8),
          _label('ORDER BREAKDOWN'),
          const Spacer(),
          Text('$_totalOrder total', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11)),
        ]),
        const SizedBox(height: 16),
        _orderRow('Approved', _approved, total, _green),
        const SizedBox(height: 10),
        _orderRow('Pending',  _pending,  total, _orange),
        const SizedBox(height: 10),
        _orderRow('Rejected', _rejected, total, _red),
      ]),
    );
  }

  Widget _orderRow(String lbl, int val, int total, Color color) => Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Text(lbl, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 12, fontWeight: FontWeight.w600)),
        const Spacer(),
        Text('$val', style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 13, fontWeight: FontWeight.bold)),
      ]),
      const SizedBox(height: 5),
      ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: LinearProgressIndicator(
          value: val / total,
          backgroundColor: _border,
          valueColor: AlwaysStoppedAnimation<Color>(color),
          minHeight: 5,
        ),
      ),
    ],
  );

  Widget _discountCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.local_offer_rounded, color: _orange, size: 16),
          const SizedBox(width: 8),
          _label('DISKON PER ROLE'),
          const Spacer(),
          // Tombol kalkulator
          GestureDetector(
            onTap: () => setState(() => _calcOpen = !_calcOpen),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: _calcOpen ? _orange.withValues(alpha: 0.2) : _orange.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _orange.withValues(alpha: 0.4)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.calculate_rounded, color: _orange, size: 13),
                const SizedBox(width: 5),
                Text(_calcOpen ? 'Tutup' : 'Kalkulator', style: const TextStyle(color: _orange, fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.bold)),
              ]),
            ),
          ),
          if (_discountLoading) ...[
            const SizedBox(width: 8),
            const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: _orange, strokeWidth: 2)),
          ],
        ]),
        const SizedBox(height: 6),
        const Text('0 = tidak ada diskon', style: TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 10)),

        // ── Kalkulator Accordion ─────────────────────────────
        if (_calcOpen) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _bg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _orange.withValues(alpha: 0.25)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.calculate_rounded, color: _orange, size: 14),
                const SizedBox(width: 6),
                _label('KALKULATOR DISKON'),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _calcField('Harga Asli (Rp)', 'contoh: 50000', _calcHargaCtrl, Icons.price_change_rounded)),
                const SizedBox(width: 10),
                Expanded(child: _calcField('Diskon (%)', 'contoh: 30', _calcPctCtrl, Icons.percent_rounded)),
              ]),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity, height: 40,
                child: ElevatedButton(
                  onPressed: () {
                    final harga = int.tryParse(_calcHargaCtrl.text.replaceAll('.', '').replaceAll(',', '')) ?? 0;
                    final pct   = int.tryParse(_calcPctCtrl.text) ?? 0;
                    if (harga <= 0 || pct <= 0 || pct > 100) {
                      _snack('Isi harga dan persentase dengan benar!', _red);
                      return;
                    }
                    final saving = (harga * pct / 100).round();
                    final result = harga - saving;
                    setState(() { _calcResult = result; _calcSaving = saving; });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _orange, foregroundColor: _white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    elevation: 0,
                  ),
                  child: const Text('HITUNG', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 13)),
                ),
              ),
              if (_calcResult > 0) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _orange.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _orange.withValues(alpha: 0.3)),
                  ),
                  child: Column(children: [
                    _calcRow('Harga Asli', 'Rp ${_fmtRp(int.tryParse(_calcHargaCtrl.text.replaceAll('.','').replaceAll(',','')) ?? 0)}', Colors.white54),
                    const SizedBox(height: 6),
                    _calcRow('Potongan', '- Rp ${_fmtRp(_calcSaving)}', _red),
                    const Divider(color: Colors.white12, height: 14),
                    _calcRow('Harga Final', 'Rp ${_fmtRp(_calcResult)}', _orange, bold: true, big: true),
                  ]),
                ),
              ],
            ]),
          ),
        ],
        const SizedBox(height: 14),

        const SizedBox(height: 14),
        // Set semua role sekaligus
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _bg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _orange.withValues(alpha: 0.25)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('SET SEMUA ROLE', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 10, letterSpacing: 2)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: _allDiscCtrl,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 14, fontWeight: FontWeight.bold),
                  decoration: InputDecoration(
                    hintText: 'Contoh: 50',
                    hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 13),
                    suffixText: '%',
                    suffixStyle: const TextStyle(color: _orange, fontWeight: FontWeight.bold),
                    filled: true, fillColor: _card,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _orange, width: 1.5)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: () => _saveDiscountAll(int.tryParse(_allDiscCtrl.text) ?? 0),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _orange, foregroundColor: _white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 0, padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
                ),
                child: const Text('Simpan', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ]),
          ]),
        ),
        const SizedBox(height: 14),
        Container(height: 1, color: _border),
        const SizedBox(height: 12),

        // Per role — premium cards
        ..._roles.map((role) {
          final pct = (_discounts[role] ?? 0) as int;
          final hasDisc = pct > 0;
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: hasDisc ? _orange.withValues(alpha: 0.06) : const Color(0xFF0A0A0F),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: hasDisc ? _orange.withValues(alpha: 0.4) : _border),
              boxShadow: hasDisc ? [BoxShadow(color: _orange.withValues(alpha: 0.08), blurRadius: 12)] : null,
            ),
            child: Row(children: [
              // Role label
              Expanded(
                flex: 3,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(role.toUpperCase(), style: TextStyle(
                    color: hasDisc ? _orange : Colors.white54,
                    fontFamily: 'Rajdhani', fontWeight: FontWeight.bold,
                    fontSize: 12, letterSpacing: 1,
                  )),
                  if (hasDisc) ...[
                    const SizedBox(height: 3),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: _orange.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                      child: Text('DISKON $pct%', style: const TextStyle(color: _orange, fontFamily: 'Rajdhani', fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
                    ),
                  ],
                ]),
              ),
              const SizedBox(width: 10),
              // Input
              Expanded(
                flex: 4,
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF080D14),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: hasDisc ? _orange.withValues(alpha: 0.5) : _border),
                  ),
                  child: TextField(
                    controller: _discCtrl[role],
                    keyboardType: TextInputType.number,
                    style: TextStyle(color: hasDisc ? _orange : _white, fontFamily: 'Rajdhani', fontSize: 15, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                    decoration: InputDecoration(
                      hintText: '0',
                      hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 14),
                      suffixText: '%',
                      suffixStyle: TextStyle(color: hasDisc ? _orange : Colors.white24, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // Save button
              GestureDetector(
                onTap: () => _saveDiscount(role, int.tryParse(_discCtrl[role]?.text ?? '0') ?? 0),
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: _orange.withValues(alpha: hasDisc ? 0.2 : 0.08),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _orange.withValues(alpha: 0.4)),
                    boxShadow: hasDisc ? [BoxShadow(color: _orange.withValues(alpha: 0.2), blurRadius: 8)] : null,
                  ),
                  child: const Icon(Icons.check_rounded, color: _orange, size: 18),
                ),
              ),
            ]),
          );
        }).toList(),
      ]),
    );
  }

  Widget _quotaCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.inventory_2_rounded, color: _cyan, size: 16),
          const SizedBox(width: 8),
          _label('KUOTA PER ROLE'),
          const Spacer(),
          if (_quotaLoading) const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: _cyan, strokeWidth: 2)),
        ]),
        const SizedBox(height: 6),
        const Text('Kosong = "-"   •   0 = unlimited   •   angka = sisa stok', style: TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 10)),
        const SizedBox(height: 14),

        // Set semua role sekaligus
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: _cyan.withValues(alpha: 0.25))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('SET SEMUA ROLE', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 10, letterSpacing: 2)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: _allQuotaCtrl,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 14, fontWeight: FontWeight.bold),
                  decoration: InputDecoration(
                    hintText: '0 = unlimited',
                    hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 13),
                    filled: true, fillColor: _card,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _cyan, width: 1.5)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: () => _saveQuotaAll(_allQuotaCtrl.text.trim().isEmpty ? null : (int.tryParse(_allQuotaCtrl.text) ?? 0)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _cyan, foregroundColor: _white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 0, padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
                ),
                child: const Text('Simpan', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ]),
          ]),
        ),
        const SizedBox(height: 14),
        Container(height: 1, color: _border),
        const SizedBox(height: 12),

        // Per role — premium cards
        ..._roles.map((role) {
          final hasQty = _quotas.containsKey(role);
          final qty = hasQty ? (_quotas[role] as int) : null;
          final isUnlimited = hasQty && qty == 0;
          final statusLabel = !hasQty ? '-' : (isUnlimited ? 'UNLIMITED' : 'STOK $qty');
          final active = hasQty;
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: active ? _cyan.withValues(alpha: 0.06) : const Color(0xFF0A0A0F),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: active ? _cyan.withValues(alpha: 0.4) : _border),
              boxShadow: active ? [BoxShadow(color: _cyan.withValues(alpha: 0.08), blurRadius: 12)] : null,
            ),
            child: Row(children: [
              Expanded(
                flex: 3,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(role.toUpperCase(), style: TextStyle(color: active ? _cyan : Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1)),
                  const SizedBox(height: 3),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: (active ? _cyan : Colors.white24).withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                    child: Text(statusLabel, style: TextStyle(color: active ? _cyan : Colors.white38, fontFamily: 'Rajdhani', fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  ),
                ]),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 4,
                child: Container(
                  decoration: BoxDecoration(color: const Color(0xFF080D14), borderRadius: BorderRadius.circular(10), border: Border.all(color: active ? _cyan.withValues(alpha: 0.5) : _border)),
                  child: TextField(
                    controller: _quotaCtrl[role],
                    keyboardType: TextInputType.number,
                    style: TextStyle(color: active ? _cyan : _white, fontFamily: 'Rajdhani', fontSize: 15, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(
                      hintText: '-',
                      hintStyle: TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 14),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: () {
                  final text = _quotaCtrl[role]?.text.trim() ?? '';
                  _saveQuota(role, text.isEmpty ? null : (int.tryParse(text) ?? 0));
                },
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: _cyan.withValues(alpha: active ? 0.2 : 0.08),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _cyan.withValues(alpha: 0.4)),
                    boxShadow: active ? [BoxShadow(color: _cyan.withValues(alpha: 0.2), blurRadius: 8)] : null,
                  ),
                  child: const Icon(Icons.check_rounded, color: _cyan, size: 18),
                ),
              ),
            ]),
          );
        }).toList(),
      ]),
    );
  }

  // ── Kelola User card ─────────────────────────────────────────
  Widget _userManagementCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.people_alt_rounded, color: _purple, size: 16),
          const SizedBox(width: 8),
          _label('KELOLA USER'),
          const Spacer(),
          Text('${_allUsers.length} akun', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11)),
          const SizedBox(width: 8),
          if (_usersLoading) const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: _purple, strokeWidth: 2))
          else GestureDetector(onTap: _fetchAllUsers, child: const Icon(Icons.refresh_rounded, color: _purple, size: 18)),
        ]),
        const SizedBox(height: 14),

        // Toggle Aktif / Dihapus
        Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
          child: Row(children: [
            Expanded(child: _viewModeTab('active', 'AKTIF', Icons.people_alt_rounded)),
            Expanded(child: _viewModeTab('deleted', 'DIHAPUS', Icons.delete_outline_rounded)),
          ]),
        ),
        const SizedBox(height: 10),

        // Search
        TextField(
          controller: _userSearchCtrl,
          style: const TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 14),
          onSubmitted: (v) { _userSearch = v; _fetchAllUsers(); },
          decoration: InputDecoration(
            hintText: 'Cari username...',
            hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 13),
            prefixIcon: const Icon(Icons.search_rounded, color: Colors.white38, size: 18),
            filled: true, fillColor: _bg,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _purple, width: 1.5)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
        const SizedBox(height: 10),

        // Role filter chips
        SizedBox(
          height: 32,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            _roleFilterChip('all', 'SEMUA'),
            ..._roles.map((r) => _roleFilterChip(r, r.toUpperCase())),
          ]),
        ),
        const SizedBox(height: 14),

        // User list
        if (_usersLoading && _allUsers.isEmpty)
          const Padding(padding: EdgeInsets.symmetric(vertical: 20), child: Center(child: CircularProgressIndicator(color: _purple, strokeWidth: 2)))
        else if (_allUsers.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Center(child: Text('Gak ada user ketemu', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13))),
          )
        else
          ..._allUsers.map((u) {
            final isDeleted = _userViewMode == 'deleted';
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: isDeleted ? _red.withValues(alpha: 0.2) : _border)),
              child: GestureDetector(
                onTap: () => _showUserDetail(u, isDeleted: isDeleted),
                child: Row(children: [
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: (isDeleted ? _red : _purple).withValues(alpha: 0.15)),
                    child: Center(child: Text((u['username'] ?? '?').toString()[0].toUpperCase(), style: TextStyle(color: isDeleted ? _red : _purple, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold))),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(u['username'] ?? '-', style: TextStyle(color: isDeleted ? Colors.white70 : _white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13, decoration: isDeleted ? TextDecoration.lineThrough : null)),
                    Text(
                      isDeleted
                        ? 'Dihapus oleh ${u['deletedBy'] ?? '-'} • ${_formatLogDate(u['deletedAt'])}'
                        : '${(u['role'] ?? '-').toString().toUpperCase()} • exp: ${u['expiredDate'] ?? '-'}',
                      style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 10),
                    ),
                  ])),
                  if (!isDeleted)
                    GestureDetector(
                      onTap: () => _confirmDeleteUser(u['username']),
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(color: _red.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(9), border: Border.all(color: _red.withValues(alpha: 0.3))),
                        child: const Icon(Icons.delete_outline_rounded, color: _red, size: 16),
                      ),
                    )
                  else
                    Icon(Icons.chevron_right_rounded, color: Colors.white24, size: 20),
                ]),
              ),
            );
          }),
      ]),
    );
  }

  String _formatLogDate(String? iso) {
    if (iso == null) return '-';
    try {
      final d = DateTime.parse(iso);
      return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    } catch (_) { return iso; }
  }

  Widget _viewModeTab(String value, String label, IconData icon) {
    final active = _userViewMode == value;
    return GestureDetector(
      onTap: () { setState(() => _userViewMode = value); _fetchAllUsers(); },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          color: active ? (value == 'deleted' ? _red : _purple).withValues(alpha: 0.18) : Colors.transparent,
          borderRadius: BorderRadius.circular(9),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 14, color: active ? (value == 'deleted' ? _red : _purple) : Colors.white38),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(color: active ? (value == 'deleted' ? _red : _purple) : Colors.white38, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 11)),
        ]),
      ),
    );
  }

  Widget _roleFilterChip(String value, String label) {
    final active = _userRoleFilter == value;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: GestureDetector(
        onTap: () { setState(() => _userRoleFilter = value); _fetchAllUsers(); },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: active ? _purple.withValues(alpha: 0.2) : _bg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: active ? _purple : _border),
          ),
          child: Text(label, style: TextStyle(color: active ? _purple : Colors.white38, fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }

  Widget _urlCard() => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(padding: const EdgeInsets.all(7), decoration: BoxDecoration(color: _cyan.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
          child: const Icon(Icons.link_rounded, color: _cyan, size: 16)),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _label('BASE URL'),
          const Text('Konfigurasi API endpoint', style: TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 10)),
        ]),
      ]),
      const SizedBox(height: 14),
      Container(
        width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(10), border: Border.all(color: _cyan.withValues(alpha: 0.3))),
        child: Text(AppConfig.baseUrl, style: const TextStyle(color: _cyan, fontFamily: 'Rajdhani', fontSize: 12), overflow: TextOverflow.ellipsis),
      ),
      const SizedBox(height: 10),
      TextField(
        controller: _urlCtrl,
        style: const TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 13),
        decoration: InputDecoration(
          hintText: 'https://api.example.com',
          hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 12),
          prefixIcon: const Icon(Icons.public_rounded, color: Colors.white38, size: 16),
          filled: true, fillColor: _bg,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _cyan, width: 1.5)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        ),
      ),
      const SizedBox(height: 10),
      SizedBox(width: double.infinity, height: 44,
        child: ElevatedButton.icon(
          onPressed: _saveUrl,
          icon: const Icon(Icons.check_rounded, size: 16),
          label: const Text('Simpan', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, letterSpacing: 1)),
          style: ElevatedButton.styleFrom(
            backgroundColor: _cyan.withValues(alpha: 0.12), foregroundColor: _cyan,
            side: const BorderSide(color: _cyan, width: 1),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), elevation: 0,
          ),
        ),
      ),
    ]),
  );

  Widget _telegramOwnerCard() => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(padding: const EdgeInsets.all(7), decoration: BoxDecoration(color: _cyan.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
          child: const Icon(Icons.telegram_rounded, color: _cyan, size: 16)),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _label('BUY ACCOUNT MODE'),
          const Text('Set mode tombol Buy Account', style: TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 10)),
        ]),
        const Spacer(),
        GestureDetector(
          onTap: () async {
            final newMode = _buyMode == 'app' ? 'telegram' : 'app';
            try {
              final res = await http.post(
                Uri.parse('${AppConfig.baseUrl}/api/buy-settings/mode'),
                headers: {'Content-Type': 'application/json'},
                body: jsonEncode({'mode': newMode}),
              ).timeout(const Duration(seconds: 6));
              final d = jsonDecode(res.body);
              if (d['success'] == true && mounted) {
                setState(() => _buyMode = newMode);
                _snack('Mode: ${newMode.toUpperCase()} ✓', _green);
              }
            } catch (_) { _snack('Gagal ubah mode', _red); }
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _buyMode == 'telegram' ? _cyan.withValues(alpha: 0.15) : Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _buyMode == 'telegram' ? _cyan.withValues(alpha: 0.6) : Colors.white24),
            ),
            child: Text(
              _buyMode == 'telegram' ? 'TELEGRAM' : 'APP',
              style: TextStyle(color: _buyMode == 'telegram' ? _cyan : Colors.white38, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 11, letterSpacing: 1),
            ),
          ),
        ),
      ]),
      const SizedBox(height: 14),
      TextField(
        controller: _telegramOwnerCtrl,
        style: const TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 13),
        decoration: InputDecoration(
          hintText: '@ytimlou',
          hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 12),
          prefixIcon: const Icon(Icons.alternate_email_rounded, color: Colors.white38, size: 16),
          filled: true, fillColor: _bg,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _cyan, width: 1.5)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          labelText: 'Username Telegram Owner',
          labelStyle: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12),
        ),
      ),
      const SizedBox(height: 10),
      SizedBox(width: double.infinity, height: 44,
        child: ElevatedButton.icon(
          onPressed: _saveTelegramOwner,
          icon: const Icon(Icons.check_rounded, size: 16),
          label: const Text('Simpan Username', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, letterSpacing: 1)),
          style: ElevatedButton.styleFrom(
            backgroundColor: _cyan.withValues(alpha: 0.12), foregroundColor: _cyan,
            side: const BorderSide(color: _cyan, width: 1),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), elevation: 0,
          ),
        ),
      ),
    ]),
  );

  Widget _restartCard() => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: _card, borderRadius: BorderRadius.circular(16),
      border: Border.all(color: _red.withValues(alpha: 0.4)),
      boxShadow: [BoxShadow(color: _red.withValues(alpha: 0.06), blurRadius: 20)],
    ),
    child: Row(children: [
      Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: _red.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
        child: const Icon(Icons.restart_alt_rounded, color: _red, size: 24),
      ),
      const SizedBox(width: 14),
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('RESTART SERVER', style: TextStyle(color: _red, fontFamily: 'Rajdhani', fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 2)),
        Text('Pterodactyl auto-reboot setelah exit', style: TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 10)),
      ])),
      _restarting
          ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: _red, strokeWidth: 2))
          : ElevatedButton(
              onPressed: _restartServer,
              style: ElevatedButton.styleFrom(
                backgroundColor: _red, foregroundColor: _white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10), elevation: 0,
              ),
              child: const Text('RESTART', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1)),
            ),
    ]),
  );

  Widget _label(String t) => Text(t, style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.w600));
  Widget _dot(Color c, String t) => Row(children: [
    Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: c)),
    const SizedBox(width: 5),
    Text(t, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 10)),
  ]);

  String _fmtRp(int v) => v.toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');

  Widget _calcField(String label, String hint, TextEditingController ctrl, IconData icon) =>
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 10, letterSpacing: 1)),
      const SizedBox(height: 4),
      TextField(
        controller: ctrl,
        keyboardType: TextInputType.number,
        style: const TextStyle(color: _white, fontFamily: 'Rajdhani', fontSize: 13),
        onChanged: (_) => setState(() { _calcResult = 0; _calcSaving = 0; }),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 11),
          prefixIcon: Icon(icon, color: _orange, size: 14),
          filled: true, fillColor: _card,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _border)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _border)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _orange, width: 1.5)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        ),
      ),
    ]);

  Widget _calcRow(String label, String value, Color color, {bool bold = false, bool big = false}) =>
    Row(children: [
      Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
      const Spacer(),
      Text(value, style: TextStyle(
        color: color, fontFamily: 'Rajdhani',
        fontSize: big ? 16 : 12,
        fontWeight: bold ? FontWeight.bold : FontWeight.normal,
      )),
    ]);
}

// ── Line Chart Painter ────────────────────────────────────────────────────────
class _LineChartPainter extends CustomPainter {
  final List<double> data;
  final Color color;
  _LineChartPainter(this.data, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    if (data.length < 2) return;

    final maxVal = data.reduce(math.max).clamp(1.0, 100.0);

    // Grid lines
    final gridPaint = Paint()
      ..color = const Color(0xFF1C2C3E)
      ..strokeWidth = 0.5;
    for (int i = 0; i <= 4; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    // Gradient fill
    final pts = List.generate(data.length, (i) {
      final x = size.width * i / (data.length - 1);
      final y = size.height * (1 - data[i] / maxVal);
      return Offset(x, y);
    });

    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (int i = 1; i < pts.length; i++) {
      final cp1 = Offset((pts[i-1].dx + pts[i].dx) / 2, pts[i-1].dy);
      final cp2 = Offset((pts[i-1].dx + pts[i].dx) / 2, pts[i].dy);
      path.cubicTo(cp1.dx, cp1.dy, cp2.dx, cp2.dy, pts[i].dx, pts[i].dy);
    }

    final fillPath = Path.from(path)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    canvas.drawPath(fillPath, Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [color.withValues(alpha: 0.3), color.withValues(alpha: 0.0)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)));

    // Line
    canvas.drawPath(path, Paint()
      ..color = color
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round);

    // Dot current value
    final last = pts.last;
    canvas.drawCircle(last, 4, Paint()..color = color);
    canvas.drawCircle(last, 2, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(_LineChartPainter old) => old.data != data;
}

// ── GRID BACKGROUND PAINTER ───────────────────────────────────────────────────
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 28.0;

    // Glow layer (blur)
    final glowPaint = Paint()
      ..color = const Color(0xFFFF1744).withOpacity(0.12)
      ..strokeWidth = 3.0
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);

    // Sharp line layer
    final linePaint = Paint()
      ..color = const Color(0xFFFF1744).withOpacity(0.30)
      ..strokeWidth = 0.8;

    // Draw glow first, then sharp lines on top
    for (double x = 0; x <= size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), glowPaint);
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), linePaint);
    }
    for (double y = 0; y <= size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), glowPaint);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
    }
  }

  @override
  bool shouldRepaint(_GridPainter old) => false;
}

// ── Halaman Detail Lengkap User (Aktif / Dihapus) ───────────────────────────
class _UserFullDetailPage extends StatelessWidget {
  final Map user;
  final bool isDeleted;
  const _UserFullDetailPage({required this.user, required this.isDeleted});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        iconTheme: const IconThemeData(color: _white),
        title: Text(
          isDeleted ? 'Detail Akun (Dihapus)' : 'Detail Akun',
          style: const TextStyle(color: _white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDeleted
                      ? [_red.withValues(alpha: 0.18), _card]
                      : [_purple.withValues(alpha: 0.18), _card],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: isDeleted ? _red.withValues(alpha: 0.35) : _border),
              ),
              child: Row(children: [
                Container(
                  width: 54, height: 54,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: (isDeleted ? _red : _purple).withValues(alpha: 0.18),
                    border: Border.all(color: (isDeleted ? _red : _purple).withValues(alpha: 0.4)),
                  ),
                  child: Center(
                    child: Text(
                      (user['username'] ?? '?').toString()[0].toUpperCase(),
                      style: TextStyle(color: isDeleted ? _red : _purple, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 22),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(
                      user['username'] ?? '-',
                      style: TextStyle(color: _white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 19, decoration: isDeleted ? TextDecoration.lineThrough : null),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                      decoration: BoxDecoration(
                        color: (isDeleted ? _red : _cyan).withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        isDeleted ? 'AKUN DIHAPUS' : (user['role'] ?? '-').toString().toUpperCase(),
                        style: TextStyle(color: isDeleted ? _red : _cyan, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 11),
                      ),
                    ),
                  ]),
                ),
              ]),
            ),
            const SizedBox(height: 18),

            _sectionLabel('Informasi Akun'),
            _infoCard([
              _infoRow(Icons.badge_outlined, 'Role', (user['role'] ?? '-').toString().toUpperCase()),
              _infoRow(Icons.event_busy_outlined, 'Expired', user['expiredDate']?.toString() ?? '-'),
              _infoRow(Icons.account_tree_outlined, 'Dibuat oleh (Parent)', user['parent']?.toString() ?? 'SYSTEM'),
              if (!isDeleted) _infoRow(Icons.phonelink_lock_outlined, 'Device ID', user['deviceId']?.toString() ?? '-'),
            ]),

            if (isDeleted) ...[
              const SizedBox(height: 18),
              _sectionLabel('Riwayat Penghapusan'),
              _infoCard([
                _infoRow(Icons.person_remove_outlined, 'Dihapus oleh', user['deletedBy']?.toString() ?? '-'),
                _infoRow(Icons.schedule_outlined, 'Tanggal Dihapus', _fmtDate(user['deletedAt']?.toString())),
                if (user['deviceId'] != null) _infoRow(Icons.phonelink_lock_outlined, 'Device ID (terakhir)', user['deviceId']?.toString() ?? '-'),
              ]),
            ],

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  static String _fmtDate(String? iso) {
    if (iso == null) return '-';
    try {
      final d = DateTime.parse(iso);
      return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    } catch (_) { return iso; }
  }

  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 10, left: 2),
        child: Text(text, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 0.5)),
      );

  Widget _infoCard(List<Widget> rows) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
        child: Column(children: rows),
      );

  Widget _infoRow(IconData icon, String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 11),
        child: Row(children: [
          Icon(icon, color: Colors.white38, size: 17),
          const SizedBox(width: 10),
          Expanded(
            child: Text(label, style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 13)),
          ),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(color: _white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w600, fontSize: 13.5),
            ),
          ),
        ]),
      );
}
