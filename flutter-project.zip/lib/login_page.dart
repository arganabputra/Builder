import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'dart:ui';
import 'buy_account.dart';
import 'config.dart';
import 'maintenance_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;
  String? androidId;
  bool _isObscure = true;

  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    // Load saved base URL from SharedPreferences on app startup
    AppConfig.loadBaseUrl();
    initLogin();

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
    );

    _fadeController.forward();
    _slideController.forward();

    _videoController = VideoPlayerController.asset('assets/videos/login.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(0);
        _videoController.play();
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        "${AppConfig.baseUrl}/api/auth/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
      );
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true) {
          Navigator.pushReplacementNamed(
            context,
            '/splash',
            arguments: {
              'username': savedUser,
              'password': savedPass,
              'role': data['role'],
              'key': data['key'],
              'expiredDate': data['expiredDate'],
              'listBug': data['listBug'] ?? [],
              'listPayload': data['listPayload'] ?? [],
              'listDDoS': data['listDDoS'] ?? [],
              'news': data['news'] ?? [],
            },
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id;
  }

  Future<void> login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showAlert("⚠️ Error", "Username and password are required.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("${AppConfig.baseUrl}/api/auth/validate"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        }),
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showAlert("⛔ Access Expired", "Your access has expired.\nPlease renew it.", showContact: true);
      } else if (validData['valid'] != true) {
        _showAlert("🚫 Login Failed", "Invalid username or password.", showContact: true);
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        Navigator.pushNamed(
          context,
          '/splash',
          arguments: {
            'username': username,
            'password': password,
            'role': validData['role'],
            'key': validData['key'],
            'expiredDate': validData['expiredDate'],
            'listBug': validData['listBug'] ?? [],
            'listPayload': validData['listPayload'] ?? [],
            'listDDoS': validData['listDDoS'] ?? [],
            'news': validData['news'] ?? [],
          },
        );
      }
    } catch (_) {
      _showAlert("🌐 Connection Error", "Failed to connect to the server.");
    }

    setState(() => isLoading = false);
  }


  // Emoji → Icon mapping untuk pesan order closed
  static const Map<String, IconData> _emojiIconMap = {
    '⚠': Icons.warning_amber_rounded,   // tanpa variation selector
    '⚠️': Icons.warning_amber_rounded,  // dengan variation selector
    '🔴': Icons.radio_button_checked,
    '🟢': Icons.radio_button_checked,
    '🟡': Icons.circle,
    '⏳': Icons.hourglass_bottom_rounded,
    '📢': Icons.campaign_rounded,
    '🔔': Icons.notifications_rounded,
    '❌': Icons.cancel_rounded,
    '✅': Icons.check_circle_rounded,
    '🛒': Icons.shopping_cart_rounded,
    '💬': Icons.chat_bubble_rounded,
    '📱': Icons.phone_android_rounded,
    '🔧': Icons.build_rounded,
    '⭐': Icons.star_rounded,
    '🚀': Icons.rocket_launch_rounded,
    '💎': Icons.diamond_rounded,
    '🔒': Icons.lock_rounded,
    '📣': Icons.volume_up_rounded,
    '💰': Icons.monetization_on_rounded,
    '🎯': Icons.gps_fixed_rounded,
  };

  static const Map<String, Color> _emojiColorMap = {
    '⚠': Color(0xFFFF9800),
    '⚠️': Color(0xFFFF9800),
    '🔴': Color(0xFFFF1744),
    '🟢': Color(0xFF00E676),
    '🟡': Color(0xFFFFD600),
    '⏳': Color(0xFF90CAF9),
    '📢': Color(0xFFFF9800),
    '🔔': Color(0xFFFFD600),
    '❌': Color(0xFFFF1744),
    '✅': Color(0xFF00E676),
    '🛒': Color(0xFF4CAF50),
    '💬': Color(0xFF2196F3),
    '📱': Color(0xFF90CAF9),
    '🔧': Color(0xFFFF9800),
    '⭐': Color(0xFFFFD600),
    '🚀': Color(0xFF7C4DFF),
    '💎': Color(0xFF00E5FF),
    '🔒': Color(0xFFFF1744),
    '📣': Color(0xFFFF9800),
    '💰': Color(0xFFFFD600),
    '🎯': Color(0xFFFF1744),
  };

  Widget _buildOrderMessage(String message) {
    final lines = message.split('\n').where((l) => l.trim().isNotEmpty).toList();
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: lines.map((line) {
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.04),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.07)),
          ),
          child: Row(
            children: [
              Container(
                width: 6, height: 6,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xFFFF1744),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(child: Text(
                line,
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.w600,
                  fontSize: 13.5,
                  height: 1.4,
                ),
              )),
            ],
          ),
        );
      }).toList(),
    );
  }

  void _showOrderClosedDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
          decoration: BoxDecoration(
            color: const Color(0xFF0A0F1A),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: const Color(0xFFFF1744).withValues(alpha: 0.35), width: 1),
            boxShadow: [
              BoxShadow(color: const Color(0xFFFF1744).withValues(alpha: 0.15), blurRadius: 40, spreadRadius: 0),
              BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20, spreadRadius: 2),
            ],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // Top glow line
            Container(
              width: 48, height: 3,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2),
                gradient: const LinearGradient(colors: [Colors.transparent, Color(0xFFFF1744), Colors.transparent]),
              ),
            ),
            const SizedBox(height: 20),
            // Icon
            Stack(alignment: Alignment.center, children: [
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFFF1744).withValues(alpha: 0.06),
                ),
              ),
              Container(
                width: 58, height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFFF1744).withValues(alpha: 0.1),
                  border: Border.all(color: const Color(0xFFFF1744).withValues(alpha: 0.4), width: 1),
                ),
                child: const Icon(Icons.lock_outline_rounded, color: Color(0xFFFF1744), size: 26),
              ),
            ]),
            const SizedBox(height: 18),
            // Title
            const Text(
              'ORDER DITUTUP',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w900,
                fontSize: 20,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Sementara tidak menerima order',
              style: TextStyle(
                color: Colors.white.withOpacity(0.35),
                fontFamily: 'Rajdhani',
                fontSize: 12,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 20),
            // Divider
            Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  Colors.transparent,
                  Colors.white.withOpacity(0.08),
                  Colors.transparent,
                ]),
              ),
            ),
            const SizedBox(height: 16),
            _buildOrderMessage(message),
            const SizedBox(height: 20),
            // Close button
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 13),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF1744), Color(0xFFD50000)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(color: const Color(0xFFFF1744).withValues(alpha: 0.4), blurRadius: 16, offset: const Offset(0, 6)),
                  ],
                ),
                child: const Center(child: Text(
                  'TUTUP',
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                    letterSpacing: 2,
                  ),
                )),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _showAlert(String title, String msg, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: const Color(0xFFFF1744).withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFFFF1744).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                title.contains("Error") || title.contains("Failed")
                    ? Icons.error_outline
                    : title.contains("Expired")
                    ? Icons.timer_off
                    : Icons.info_outline,
                color: title.contains("Error") || title.contains("Failed")
                    ? Colors.redAccent
                    : title.contains("Expired")
                    ? Colors.amber
                    : const Color(0xFFFF1744),
              ),
            ),
            const SizedBox(width: 12),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Rajdhani',
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 14,
            fontFamily: 'Rajdhani',
          ),
        ),
        actions: [
          if (showContact)
            TextButton.icon(
              onPressed: () async {
                final uri = Uri.parse("tg://resolve?domain=𝐈𝐊𝐘");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  await launchUrl(Uri.parse("https://t.me/IkyyNotDev"),
                      mode: LaunchMode.externalApplication);
                }
              },
              icon: const Icon(Icons.message, size: 18),
              label: const Text(
                "Contact Admin",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.bold,
                ),
              ),
              style: TextButton.styleFrom(
                backgroundColor: const Color(0xFFFF1744).withValues(alpha: 0.2),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _checkAndOpenBuyPage() async {
    // Cek mode buy account dulu
    try {
      final modeRes = await http.get(Uri.parse('${AppConfig.baseUrl}/api/buy-settings'))
          .timeout(const Duration(seconds: 5));
      final modeData = jsonDecode(modeRes.body);
      if (modeData['success'] == true && modeData['mode'] == 'telegram') {
        final username = (modeData['telegramUsername'] ?? '@ytimlou').replaceFirst('@', '');
        final uri = Uri.parse('https://t.me/$username');
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
          return;
        }
      }
    } catch (_) {}

    void openBuyPage() {
      Navigator.push(
        context,
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => const BuyAccountPage(),
          transitionsBuilder: (_, animation, __, child) {
            return SlideTransition(
              position: Tween(
                begin: const Offset(0.0, 1.0),
                end: Offset.zero,
              ).chain(CurveTween(curve: Curves.easeInOut)).animate(animation),
              child: child,
            );
          },
          transitionDuration: const Duration(milliseconds: 350),
        ),
      );
    }

    try {
      final res = await http.get(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/autoorder-status'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (!mounted) return;

      // Cek orderClosed dari admin
      if (data['orderClosed'] == true) {
        final msg = (data['orderClosedMsg'] as String?)?.isNotEmpty == true
            ? data['orderClosedMsg'] as String
            : '⏳ Sedang dalam maintenance\n🔴 Order sementara ditutup\n📢 Pantau channel untuk update';
        _showOrderClosedDialog(msg);
        return;
      }

      // Order open — langsung masuk
      openBuyPage();
    } catch (_) {
      // Gagal konek ke server — tetap bolehin masuk, jangan block user
      if (!mounted) return;
      openBuyPage();
    }
  }

  Future<void> _openTelegramBot() async {
    final uri = Uri.parse("tg://resolve?domain=𝐈𝐊𝐘");
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      await launchUrl(Uri.parse("https://t.me/IkyyNotDev"),
          mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // VIDEO FULL SCREEN — no FittedBox, no SizedBox constraint
          SizedBox.expand(
            child: _videoController.value.isInitialized
                ? VideoPlayer(_videoController)
                : Container(color: Colors.black),
          ),

          // DARK OVERLAY biar form tetap kebaca
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.4),
                  Colors.black.withOpacity(0.7),
                  Colors.black.withOpacity(0.92),
                ],
              ),
            ),
          ),

          // SUBTLE BLUE RADIAL GLOW di tengah atas
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(0, -0.3),
                radius: 1.0,
                colors: [
                  const Color(0xFFFF1744).withValues(alpha: 0.08),
                  Colors.transparent,
                ],
              ),
            ),
          ),

          // FORM LOGIN
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // LOGO
                      Hero(
                        tag: 'logo',
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFFFF1744).withValues(alpha: 0.7),
                              width: 2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFFFF1744).withValues(alpha: 0.5),
                                blurRadius: 40,
                                spreadRadius: 6,
                              ),
                            ],
                          ),
                          child: ClipOval(
                            child: Image.asset(
                              'assets/images/logo.png',
                              height: 120,
                              width: 120,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),

                      // Tulisan WinClick — putih, glow biru di shadow
                      const Text(
                        "Dominus Core",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 4.0,
                          shadows: [
                            Shadow(
                              color: Color(0xFFFF1744),
                              blurRadius: 20,
                            ),
                            Shadow(
                              color: Color(0xFFFF1744),
                              blurRadius: 40,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "Halaman Sebelum Anda Login",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 14,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 40),

                      // CONTAINER FORM
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.65),
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(
                            color: const Color(0xFFFF1744).withValues(alpha: 0.15),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.7),
                              blurRadius: 25,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            _neonInput("Username", userController, Icons.person),
                            const SizedBox(height: 16),
                            _neonInput("Password", passController, Icons.lock_outline, isPassword: true),
                            const SizedBox(height: 30),

                            // TOMBOL SIGN IN
                            Container(
                              width: double.infinity,
                              height: 55,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                gradient: const LinearGradient(
                                  colors: [
                                    Color(0xFF7F0000),
                                    Color(0xFFFF1744),
                                  ],
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFFFF1744).withValues(alpha: 0.6),
                                    blurRadius: 25,
                                    spreadRadius: 2,
                                    offset: const Offset(0, 5),
                                  ),
                                ],
                              ),
                              child: ElevatedButton(
                                onPressed: isLoading ? null : login,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  shadowColor: Colors.transparent,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                ),
                                child: isLoading
                                    ? const SizedBox(
                                        width: 24,
                                        height: 24,
                                        child: CircularProgressIndicator(
                                          color: Colors.white,
                                          strokeWidth: 2.5,
                                        ),
                                      )
                                    : const Text(
                                        "SIGN IN",
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.white,
                                          fontFamily: 'Rajdhani',
                                          letterSpacing: 2.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // TOMBOL BUY ACCOUNT — solid premium
                      GestureDetector(
                        onTap: _checkAndOpenBuyPage,
                        child: Container(
                          width: double.infinity,
                          height: 52,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            gradient: const LinearGradient(
                              colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFFFF1744).withValues(alpha: 0.45),
                                blurRadius: 20,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(Icons.shopping_cart_rounded, color: Colors.white, size: 16),
                              ),
                              const SizedBox(width: 10),
                              const Text(
                                'BUY ACCOUNT',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Rajdhani',
                                  fontWeight: FontWeight.w900,
                                  fontSize: 15,
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _neonInput(String hint, TextEditingController controller, IconData icon,
      {bool isPassword = false}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: controller,
        obscureText: isPassword ? _isObscure : false,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontFamily: 'Rajdhani',
          fontWeight: FontWeight.bold,
        ),
        cursorColor: const Color(0xFFFF1744),
        decoration: InputDecoration(
          prefixIcon: Icon(
            icon,
            color: const Color(0xFFFF1744).withValues(alpha: 0.8),
          ),
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(
                    _isObscure ? Icons.visibility_off : Icons.visibility,
                    color: Colors.white.withOpacity(0.5),
                  ),
                  onPressed: () {
                    setState(() {
                      _isObscure = !_isObscure;
                    });
                  },
                )
              : null,
          hintText: hint,
          hintStyle: TextStyle(
            color: Colors.white.withOpacity(0.4),
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.bold,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: const Color(0xFFFF1744).withValues(alpha: 0.5), width: 1),
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        ),
      ),
    );
  }
}