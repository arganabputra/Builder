// chess_page.dart — Fitur game catur: Lawan Bot & PvP lewat kode room.
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

// ─────────────────────────────────────────────────────────────────────────
// ENGINE CATUR (murni Dart, gak pake package luar)
// board[r][c] = null atau "wP","bK", dst. row0 = baris 8 (sisi hitam/atas)
// ─────────────────────────────────────────────────────────────────────────

class ChessMove {
  final int fromR, fromC, toR, toC;
  final String? promotion; // 'Q' aja (auto-promote)
  final String? flag; // 'double' | 'enpassant' | 'castleK' | 'castleQ'
  ChessMove({required this.fromR, required this.fromC, required this.toR, required this.toC, this.promotion, this.flag});
}

class ChessState {
  List<List<String?>> board;
  String turn; // 'w' | 'b'
  Map<String, bool> castling; // wK,wQ,bK,bQ
  Map<String, int>? enPassant; // {r,c}

  ChessState({required this.board, required this.turn, required this.castling, this.enPassant});

  factory ChessState.initial() {
    final back = ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'];
    final b = List.generate(8, (_) => List<String?>.filled(8, null));
    for (var c = 0; c < 8; c++) {
      b[0][c] = 'b${back[c]}';
      b[1][c] = 'bP';
      b[6][c] = 'wP';
      b[7][c] = 'w${back[c]}';
    }
    return ChessState(board: b, turn: 'w', castling: {'wK': true, 'wQ': true, 'bK': true, 'bQ': true});
  }

  ChessState clone() => ChessState(
        board: board.map((row) => row.toList()).toList(),
        turn: turn,
        castling: Map.of(castling),
        enPassant: enPassant == null ? null : Map.of(enPassant!),
      );

  Map<String, dynamic> toJson() => {
        'board': board.map((row) => row.map((p) => p).toList()).toList(),
        'turn': turn,
        'castling': castling,
        'enPassant': enPassant,
      };

  static ChessState fromJson(Map<String, dynamic> j) {
    final b = (j['board'] as List).map<List<String?>>((row) => (row as List).map<String?>((p) => p as String?).toList()).toList();
    final cRaw = Map<String, dynamic>.from(j['castling'] ?? {});
    final castling = {
      'wK': cRaw['wK'] == true, 'wQ': cRaw['wQ'] == true,
      'bK': cRaw['bK'] == true, 'bQ': cRaw['bQ'] == true,
    };
    Map<String, int>? ep;
    if (j['enPassant'] != null) {
      final e = Map<String, dynamic>.from(j['enPassant']);
      ep = {'r': e['r'] as int, 'c': e['c'] as int};
    }
    return ChessState(board: b, turn: j['turn'] as String, castling: castling, enPassant: ep);
  }
}

bool _inside(int r, int c) => r >= 0 && r < 8 && c >= 0 && c < 8;

List<ChessMove> _pseudoMoves(ChessState s, int r, int c) {
  final piece = s.board[r][c];
  if (piece == null) return [];
  final color = piece[0], type = piece[1];
  final opp = color == 'w' ? 'b' : 'w';
  final moves = <ChessMove>[];

  if (type == 'P') {
    final dir = color == 'w' ? -1 : 1;
    final startRow = color == 'w' ? 6 : 1;
    final lastRow = color == 'w' ? 0 : 7;
    final one = r + dir;
    if (_inside(one, c) && s.board[one][c] == null) {
      if (one == lastRow) {
        moves.add(ChessMove(fromR: r, fromC: c, toR: one, toC: c, promotion: 'Q'));
      } else {
        moves.add(ChessMove(fromR: r, fromC: c, toR: one, toC: c));
      }
      final two = r + 2 * dir;
      if (r == startRow && _inside(two, c) && s.board[two][c] == null) {
        moves.add(ChessMove(fromR: r, fromC: c, toR: two, toC: c, flag: 'double'));
      }
    }
    for (final dc in [-1, 1]) {
      final tr = r + dir, tc = c + dc;
      if (!_inside(tr, tc)) continue;
      final target = s.board[tr][tc];
      if (target != null && target[0] == opp) {
        if (tr == lastRow) {
          moves.add(ChessMove(fromR: r, fromC: c, toR: tr, toC: tc, promotion: 'Q'));
        } else {
          moves.add(ChessMove(fromR: r, fromC: c, toR: tr, toC: tc));
        }
      } else if (s.enPassant != null && s.enPassant!['r'] == tr && s.enPassant!['c'] == tc) {
        moves.add(ChessMove(fromR: r, fromC: c, toR: tr, toC: tc, flag: 'enpassant'));
      }
    }
  } else if (type == 'N') {
    const offs = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
    for (final o in offs) {
      final tr = r + o[0], tc = c + o[1];
      if (!_inside(tr, tc)) continue;
      final t = s.board[tr][tc];
      if (t == null || t[0] == opp) moves.add(ChessMove(fromR: r, fromC: c, toR: tr, toC: tc));
    }
  } else if (type == 'K') {
    for (var dr = -1; dr <= 1; dr++) {
      for (var dc = -1; dc <= 1; dc++) {
        if (dr == 0 && dc == 0) continue;
        final tr = r + dr, tc = c + dc;
        if (!_inside(tr, tc)) continue;
        final t = s.board[tr][tc];
        if (t == null || t[0] == opp) moves.add(ChessMove(fromR: r, fromC: c, toR: tr, toC: tc));
      }
    }
    final home = color == 'w' ? 7 : 0;
    if (r == home && c == 4) {
      final k = color == 'w' ? s.castling['wK']! : s.castling['bK']!;
      final q = color == 'w' ? s.castling['wQ']! : s.castling['bQ']!;
      if (k && s.board[home][5] == null && s.board[home][6] == null && s.board[home][7] == '${color}R') {
        if (!_isAttacked(s.board, home, 4, opp) && !_isAttacked(s.board, home, 5, opp) && !_isAttacked(s.board, home, 6, opp)) {
          moves.add(ChessMove(fromR: r, fromC: c, toR: home, toC: 6, flag: 'castleK'));
        }
      }
      if (q && s.board[home][1] == null && s.board[home][2] == null && s.board[home][3] == null && s.board[home][0] == '${color}R') {
        if (!_isAttacked(s.board, home, 4, opp) && !_isAttacked(s.board, home, 3, opp) && !_isAttacked(s.board, home, 2, opp)) {
          moves.add(ChessMove(fromR: r, fromC: c, toR: home, toC: 2, flag: 'castleQ'));
        }
      }
    }
  } else {
    List<List<int>> dirs = [];
    if (type == 'B') {
      dirs = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
    } else if (type == 'R') {
      dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
    } else {
      dirs = [[-1, -1], [-1, 1], [1, -1], [1, 1], [-1, 0], [1, 0], [0, -1], [0, 1]];
    }
    for (final d in dirs) {
      var tr = r + d[0], tc = c + d[1];
      while (_inside(tr, tc)) {
        final t = s.board[tr][tc];
        if (t == null) {
          moves.add(ChessMove(fromR: r, fromC: c, toR: tr, toC: tc));
        } else {
          if (t[0] == opp) moves.add(ChessMove(fromR: r, fromC: c, toR: tr, toC: tc));
          break;
        }
        tr += d[0]; tc += d[1];
      }
    }
  }
  return moves;
}

bool _isAttacked(List<List<String?>> board, int r, int c, String byColor) {
  final dir = byColor == 'w' ? -1 : 1;
  final ar = r - dir;
  if (_inside(ar, c - 1) && board[ar][c - 1] == '${byColor}P') return true;
  if (_inside(ar, c + 1) && board[ar][c + 1] == '${byColor}P') return true;

  const kn = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
  for (final o in kn) {
    final tr = r + o[0], tc = c + o[1];
    if (_inside(tr, tc) && board[tr][tc] == '${byColor}N') return true;
  }
  for (var dr = -1; dr <= 1; dr++) {
    for (var dc = -1; dc <= 1; dc++) {
      if (dr == 0 && dc == 0) continue;
      final tr = r + dr, tc = c + dc;
      if (_inside(tr, tc) && board[tr][tc] == '${byColor}K') return true;
    }
  }
  const diag = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
  for (final d in diag) {
    var tr = r + d[0], tc = c + d[1];
    while (_inside(tr, tc)) {
      final p = board[tr][tc];
      if (p != null) {
        if (p[0] == byColor && (p[1] == 'B' || p[1] == 'Q')) return true;
        break;
      }
      tr += d[0]; tc += d[1];
    }
  }
  const straight = [[-1, 0], [1, 0], [0, -1], [0, 1]];
  for (final d in straight) {
    var tr = r + d[0], tc = c + d[1];
    while (_inside(tr, tc)) {
      final p = board[tr][tc];
      if (p != null) {
        if (p[0] == byColor && (p[1] == 'R' || p[1] == 'Q')) return true;
        break;
      }
      tr += d[0]; tc += d[1];
    }
  }
  return false;
}

Map<String, int>? _kingPos(List<List<String?>> board, String color) {
  for (var r = 0; r < 8; r++) {
    for (var c = 0; c < 8; c++) {
      if (board[r][c] == '${color}K') return {'r': r, 'c': c};
    }
  }
  return null;
}

bool _inCheck(ChessState s, String color) {
  final kp = _kingPos(s.board, color);
  if (kp == null) return false;
  return _isAttacked(s.board, kp['r']!, kp['c']!, color == 'w' ? 'b' : 'w');
}

ChessState _applyMove(ChessState s, ChessMove m) {
  final ns = s.clone();
  ns.turn = s.turn == 'w' ? 'b' : 'w';
  ns.enPassant = null;
  final piece = ns.board[m.fromR][m.fromC]!;
  final color = piece[0], type = piece[1];

  if (m.flag == 'enpassant') {
    ns.board[m.fromR][m.toC] = null;
  }
  ns.board[m.toR][m.toC] = m.promotion != null ? '$color${m.promotion}' : piece;
  ns.board[m.fromR][m.fromC] = null;

  if (m.flag == 'castleK') {
    final row = m.fromR;
    ns.board[row][5] = ns.board[row][7];
    ns.board[row][7] = null;
  } else if (m.flag == 'castleQ') {
    final row = m.fromR;
    ns.board[row][3] = ns.board[row][0];
    ns.board[row][0] = null;
  }

  if (type == 'K') {
    if (color == 'w') { ns.castling['wK'] = false; ns.castling['wQ'] = false; }
    else { ns.castling['bK'] = false; ns.castling['bQ'] = false; }
  }
  if (type == 'R') {
    if (color == 'w' && m.fromR == 7 && m.fromC == 0) ns.castling['wQ'] = false;
    if (color == 'w' && m.fromR == 7 && m.fromC == 7) ns.castling['wK'] = false;
    if (color == 'b' && m.fromR == 0 && m.fromC == 0) ns.castling['bQ'] = false;
    if (color == 'b' && m.fromR == 0 && m.fromC == 7) ns.castling['bK'] = false;
  }
  if (m.toR == 7 && m.toC == 0) ns.castling['wQ'] = false;
  if (m.toR == 7 && m.toC == 7) ns.castling['wK'] = false;
  if (m.toR == 0 && m.toC == 0) ns.castling['bQ'] = false;
  if (m.toR == 0 && m.toC == 7) ns.castling['bK'] = false;

  if (m.flag == 'double') {
    ns.enPassant = {'r': ((m.fromR + m.toR) / 2).round(), 'c': m.fromC};
  }
  return ns;
}

List<ChessMove> _legalMoves(ChessState s, String color) {
  final all = <ChessMove>[];
  for (var r = 0; r < 8; r++) {
    for (var c = 0; c < 8; c++) {
      final p = s.board[r][c];
      if (p != null && p[0] == color) all.addAll(_pseudoMoves(s, r, c));
    }
  }
  return all.where((m) {
    final ns = _applyMove(s, m);
    return !_inCheck(ns, color);
  }).toList();
}

// 'playing' | 'check' | 'checkmate' | 'stalemate'
String _gameStatus(ChessState s) {
  final color = s.turn;
  final legal = _legalMoves(s, color);
  final check = _inCheck(s, color);
  if (legal.isEmpty) return check ? 'checkmate' : 'stalemate';
  return check ? 'check' : 'playing';
}

// ── Bot AI: minimax + alpha-beta, kedalaman 3 ──
const Map<String, int> _pieceValue = {'P': 100, 'N': 320, 'B': 330, 'R': 500, 'Q': 900, 'K': 0};

int _evaluate(ChessState s) {
  var score = 0;
  for (var r = 0; r < 8; r++) {
    for (var c = 0; c < 8; c++) {
      final p = s.board[r][c];
      if (p == null) continue;
      final v = _pieceValue[p[1]] ?? 0;
      score += p[0] == 'w' ? v : -v;
    }
  }
  return score;
}

int _minimax(ChessState s, int depth, int alpha, int beta) {
  final status = _gameStatus(s);
  if (status == 'checkmate') return s.turn == 'w' ? -99000 : 99000;
  if (status == 'stalemate') return 0;
  if (depth == 0) return _evaluate(s);
  final color = s.turn;
  final moves = _legalMoves(s, color);
  if (color == 'w') {
    var best = -999999;
    for (final m in moves) {
      final ns = _applyMove(s, m);
      final val = _minimax(ns, depth - 1, alpha, beta);
      if (val > best) best = val;
      if (val > alpha) alpha = val;
      if (beta <= alpha) break;
    }
    return best;
  } else {
    var best = 999999;
    for (final m in moves) {
      final ns = _applyMove(s, m);
      final val = _minimax(ns, depth - 1, alpha, beta);
      if (val < best) best = val;
      if (val < beta) beta = val;
      if (beta <= alpha) break;
    }
    return best;
  }
}

ChessMove? _botBestMove(ChessState s, int depth) {
  final moves = _legalMoves(s, s.turn);
  if (moves.isEmpty) return null;
  final bestMoves = <ChessMove>[];
  var bestVal = s.turn == 'w' ? -999999 : 999999;
  for (final m in moves) {
    final ns = _applyMove(s, m);
    final val = _minimax(ns, depth - 1, -999999, 999999);
    if (s.turn == 'w') {
      if (val > bestVal) { bestVal = val; bestMoves
        ..clear()
        ..add(m); } else if (val == bestVal) bestMoves.add(m);
    } else {
      if (val < bestVal) { bestVal = val; bestMoves
        ..clear()
        ..add(m); } else if (val == bestVal) bestMoves.add(m);
    }
  }
  return bestMoves[math.Random().nextInt(bestMoves.length)];
}

// ── Bidak yang dimakan ──
const Map<String, int> _initialCount = {'P': 8, 'N': 2, 'B': 2, 'R': 2, 'Q': 1, 'K': 1};
const List<String> _captureOrder = ['Q', 'R', 'B', 'N', 'P'];
const Map<String, int> _advValue = {'P': 1, 'N': 3, 'B': 3, 'R': 5, 'Q': 9};

class CapturedInfo {
  final List<String> byWhite; // bidak hitam yg dimakan putih
  final List<String> byBlack; // bidak putih yg dimakan hitam
  final int advWhite;
  CapturedInfo(this.byWhite, this.byBlack, this.advWhite);
}

CapturedInfo _capturedInfo(List<List<String?>> board) {
  final counts = {'w': <String, int>{'P': 0, 'N': 0, 'B': 0, 'R': 0, 'Q': 0, 'K': 0}, 'b': <String, int>{'P': 0, 'N': 0, 'B': 0, 'R': 0, 'Q': 0, 'K': 0}};
  for (var r = 0; r < 8; r++) {
    for (var c = 0; c < 8; c++) {
      final p = board[r][c];
      if (p == null) continue;
      counts[p[0]]![p[1]] = (counts[p[0]]![p[1]] ?? 0) + 1;
    }
  }
  final byWhite = <String>[], byBlack = <String>[];
  var advWhite = 0;
  for (final type in _captureOrder) {
    final missingBlack = _initialCount[type]! - (counts['b']![type] ?? 0);
    for (var i = 0; i < missingBlack; i++) { byWhite.add('b$type'); advWhite += _advValue[type] ?? 0; }
    final missingWhite = _initialCount[type]! - (counts['w']![type] ?? 0);
    for (var i = 0; i < missingWhite; i++) { byBlack.add('w$type'); advWhite -= _advValue[type] ?? 0; }
  }
  return CapturedInfo(byWhite, byBlack, advWhite);
}

const Map<String, String> _glyph = {
  'wK': '♔', 'wQ': '♕', 'wR': '♖', 'wB': '♗', 'wN': '♘', 'wP': '♙',
  'bK': '♚', 'bQ': '♛', 'bR': '♜', 'bB': '♝', 'bN': '♞', 'bP': '♟',
};

// ─────────────────────────────────────────────────────────────────────────
// UI
// ─────────────────────────────────────────────────────────────────────────

const _bg = Color(0xFF0F1115);
const _panel = Color(0xFF171A21);
const _line = Color(0x14FFFFFF);
const _text = Color(0xFFF0F1F4);
const _textDim = Color(0xFF9599A3);
const _accent = Color(0xFF4C8DFF);
const _accent2 = Color(0xFF6EA8FF);
const _lightSq = Color(0xFFEDE6D8);
const _darkSq = Color(0xFF6E8B5A);
const _sel = Color(0x8CF5D26B);
const _lastHi = Color(0x47F5D26B);
const _checkHi = Color(0x8CE5484D);

class ChessPage extends StatefulWidget {
  final String username;
  const ChessPage({super.key, required this.username});

  @override
  State<ChessPage> createState() => _ChessPageState();
}

class _ChessPageState extends State<ChessPage> {
  String screen = 'menu'; // 'menu' | 'game'
  String? mode; // 'bot' | 'online'
  ChessState? state;
  String status = 'playing';
  String? winner;
  Map<String, int>? lastMoveFrom, lastMoveTo;
  String myColor = 'w';
  String? roomCode;
  bool guestPresent = false;
  Map<String, int>? selected;
  List<ChessMove> legalForSelected = [];
  bool botThinking = false;
  String errorMsg = '';
  final _joinCtrl = TextEditingController();
  Timer? _poll;

  @override
  void dispose() {
    _poll?.cancel();
    _joinCtrl.dispose();
    super.dispose();
  }

  void _startBotGame() {
    setState(() {
      mode = 'bot';
      myColor = 'w';
      state = ChessState.initial();
      status = 'playing';
      winner = null;
      lastMoveFrom = null; lastMoveTo = null;
      selected = null; legalForSelected = [];
      screen = 'game'; errorMsg = '';
    });
  }

  Future<void> _createRoom() async {
    setState(() => errorMsg = '');
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/chess/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.username}),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['success'] != true) { setState(() => errorMsg = d['message'] ?? 'Gagal bikin room'); return; }
      final room = d['room'];
      setState(() {
        mode = 'online';
        myColor = 'w';
        roomCode = room['code'];
        guestPresent = false;
        state = ChessState.fromJson(room);
        status = 'playing'; winner = null;
        lastMoveFrom = null; lastMoveTo = null;
        selected = null; legalForSelected = [];
        screen = 'game';
      });
      _startPolling();
    } catch (_) {
      setState(() => errorMsg = 'Gagal terhubung ke server');
    }
  }

  Future<void> _joinRoom() async {
    final code = _joinCtrl.text.trim().toUpperCase();
    if (code.isEmpty) { setState(() => errorMsg = 'Masukkan kode room dulu'); return; }
    setState(() => errorMsg = '');
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/chess/join'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'code': code, 'username': widget.username}),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['success'] != true) { setState(() => errorMsg = d['message'] ?? 'Gagal gabung room'); return; }
      final room = d['room'];
      setState(() {
        mode = 'online';
        myColor = room['hostColor'] == 'w' ? 'b' : 'w';
        roomCode = room['code'];
        guestPresent = true;
        state = ChessState.fromJson(room);
        status = 'playing'; winner = null;
        lastMoveFrom = null; lastMoveTo = null;
        selected = null; legalForSelected = [];
        screen = 'game';
      });
      _startPolling();
    } catch (_) {
      setState(() => errorMsg = 'Gagal terhubung ke server');
    }
  }

  void _startPolling() {
    _poll?.cancel();
    _poll = Timer.periodic(const Duration(milliseconds: 1300), (_) => _pollState());
  }

  Future<void> _pollState() async {
    if (roomCode == null || !mounted) return;
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/chess/state?code=$roomCode')).timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      if (d['success'] != true || !mounted) return;
      final room = d['room'];
      final newState = ChessState.fromJson(room);
      setState(() {
        state = newState;
        guestPresent = room['guestPresent'] == true;
        status = room['status'] == 'finished' ? (winner != null ? 'checkmate' : 'finished_remote') : _gameStatus(newState);
        winner = room['winner'];
        if (room['lastMove'] != null) {
          final lm = room['lastMove'];
          lastMoveFrom = {'r': lm['from']['r'], 'c': lm['from']['c']};
          lastMoveTo = {'r': lm['to']['r'], 'c': lm['to']['c']};
        }
        selected = null; legalForSelected = [];
      });
    } catch (_) {}
  }

  void _backToMenu() {
    _poll?.cancel(); _poll = null;
    if (mode == 'online' && roomCode != null) {
      http.post(
        Uri.parse('${AppConfig.baseUrl}/api/chess/leave'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'code': roomCode, 'username': widget.username}),
      ).timeout(const Duration(seconds: 6)).catchError((_) => http.Response('', 500));
    }
    setState(() {
      screen = 'menu'; mode = null; state = null; roomCode = null;
      selected = null; legalForSelected = []; errorMsg = ''; _joinCtrl.clear();
    });
  }

  Future<void> _doMove(ChessMove m) async {
    final ns = _applyMove(state!, m);
    final st = _gameStatus(ns);
    String docStatus = 'playing';
    String? win;
    if (st == 'checkmate') { docStatus = 'finished'; win = ns.turn == 'w' ? 'b' : 'w'; }
    else if (st == 'stalemate') { docStatus = 'finished'; win = 'draw'; }

    setState(() {
      state = ns;
      status = st;
      winner = win;
      lastMoveFrom = {'r': m.fromR, 'c': m.fromC};
      lastMoveTo = {'r': m.toR, 'c': m.toC};
      selected = null; legalForSelected = [];
    });

    if (mode == 'online' && roomCode != null) {
      try {
        await http.post(
          Uri.parse('${AppConfig.baseUrl}/api/chess/sync'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'code': roomCode,
            'board': ns.board,
            'turn': ns.turn,
            'castling': ns.castling,
            'enPassant': ns.enPassant,
            'lastMove': {'from': {'r': m.fromR, 'c': m.fromC}, 'to': {'r': m.toR, 'c': m.toC}},
            'status': docStatus,
            'winner': win,
          }),
        ).timeout(const Duration(seconds: 8));
      } catch (_) {
        setState(() => errorMsg = 'Gagal kirim langkah');
      }
    } else if (mode == 'bot' && docStatus == 'playing' && ns.turn == 'b') {
      setState(() => botThinking = true);
      await Future.delayed(const Duration(milliseconds: 350));
      final bm = _botBestMove(state!, 3);
      if (!mounted) return;
      setState(() => botThinking = false);
      if (bm != null) _doMove(bm);
    }
  }

  void _cellClick(int r, int c) {
    if (state == null || status == 'checkmate' || status == 'stalemate') return;
    if (mode == 'online' && myColor != state!.turn) return;
    if (mode == 'bot' && state!.turn != 'w') return;

    if (selected != null) {
      final mv = legalForSelected.where((m) => m.toR == r && m.toC == c).toList();
      if (mv.isNotEmpty) { _doMove(mv.first); return; }
    }

    final piece = state!.board[r][c];
    if (piece != null && piece[0] == state!.turn && piece[0] == myColor) {
      setState(() {
        selected = {'r': r, 'c': c};
        legalForSelected = _legalMoves(state!, state!.turn).where((m) => m.fromR == r && m.fromC == c).toList();
      });
    } else {
      setState(() { selected = null; legalForSelected = []; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
          child: screen == 'menu' ? _buildMenu() : _buildGame(),
        ),
      ),
    );
  }

  Widget _buildMenu() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(mainAxisAlignment: MainAxisAlignment.center, children: const [
        Icon(Icons.extension_rounded, color: _text, size: 26),
        SizedBox(width: 8),
        Text('Catur', style: TextStyle(color: _text, fontSize: 26, fontWeight: FontWeight.w700, fontFamily: 'Rajdhani')),
      ]),
      const SizedBox(height: 4),
      const Text('Main lawan bot, atau lawan temen lewat room', textAlign: TextAlign.center,
        style: TextStyle(color: _textDim, fontSize: 13, fontFamily: 'Rajdhani')),
      const SizedBox(height: 28),

      _menuBtn(
        icon: Icons.smart_toy_rounded, title: 'Lawan Bot', desc: 'Main sendiri lawan AI',
        primary: true, onTap: _startBotGame,
      ),
      const SizedBox(height: 12),
      _menuBtn(
        icon: Icons.group_rounded, title: 'Buat Room (PvP)', desc: 'Bikin room, share kodenya ke lawan',
        onTap: _createRoom,
      ),
      const SizedBox(height: 14),

      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: _panel, border: Border.all(color: _line), borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('GABUNG ROOM', style: TextStyle(color: _textDim, fontSize: 11, letterSpacing: 1.5, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(
            controller: _joinCtrl,
            maxLength: 5,
            textCapitalization: TextCapitalization.characters,
            textAlign: TextAlign.center,
            style: const TextStyle(color: _text, fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 4, fontFamily: 'Rajdhani'),
            decoration: InputDecoration(
              counterText: '',
              hintText: 'KODE',
              hintStyle: TextStyle(color: _textDim.withOpacity(0.5)),
              filled: true, fillColor: Colors.white.withOpacity(0.05),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: _line)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: _line)),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity, height: 48,
            child: ElevatedButton(
              onPressed: _joinRoom,
              style: ElevatedButton.styleFrom(backgroundColor: _accent, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              child: const Text('Gabung', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')),
            ),
          ),
          if (errorMsg.isNotEmpty) Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(errorMsg, style: const TextStyle(color: _checkHi, fontSize: 12.5, fontFamily: 'Rajdhani')),
          ),
        ]),
      ),
      const SizedBox(height: 16),
      const Text('Promosi pion otomatis jadi Ratu.', textAlign: TextAlign.center,
        style: TextStyle(color: _textDim, fontSize: 11, fontFamily: 'Rajdhani')),
    ]);
  }

  Widget _menuBtn({required IconData icon, required String title, required String desc, required VoidCallback onTap, bool primary = false}) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: primary ? const LinearGradient(colors: [_accent2, _accent]) : null,
            color: primary ? null : _panel,
            border: primary ? null : Border.all(color: _line),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(children: [
            Icon(icon, color: Colors.white, size: 22),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')),
              Text(desc, style: TextStyle(color: Colors.white.withOpacity(primary ? 0.8 : 0.5), fontSize: 12, fontFamily: 'Rajdhani')),
            ])),
          ]),
        ),
      ),
    );
  }

  Widget _buildGame() {
    final s = state!;
    final check = status == 'check';
    final kp = check ? _kingPos(s.board, s.turn) : null;
    String statusText;
    if (status == 'checkmate' || status == 'stalemate' || winner != null) {
      statusText = winner == 'draw' ? 'Seri (stalemate)' : 'Skakmat! ${winner == 'w' ? 'Putih' : 'Hitam'} menang';
    } else if (mode == 'online' && !guestPresent) {
      statusText = 'Nunggu lawan gabung...';
    } else if (botThinking) {
      statusText = 'Bot sedang berpikir...';
    } else {
      statusText = (check ? 'Skak! ' : '') + 'Giliran ${s.turn == 'w' ? 'Putih' : 'Hitam'}';
      if (mode == 'online') statusText += myColor == s.turn ? ' (giliran kamu)' : ' (nunggu lawan)';
    }

    final cap = _capturedInfo(s.board);
    final advTop = cap.advWhite < 0 ? '+${-cap.advWhite}' : '';
    final advBottom = cap.advWhite > 0 ? '+${cap.advWhite}' : '';

    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        TextButton(onPressed: _backToMenu, child: const Text('‹ Menu', style: TextStyle(color: _textDim, fontFamily: 'Rajdhani'))),
        Text(mode == 'bot' ? 'Lawan Bot' : 'PvP Online', style: const TextStyle(color: _textDim, fontSize: 12, fontFamily: 'Rajdhani')),
      ]),
      if (mode == 'online' && roomCode != null)
        Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(color: _panel, border: Border.all(color: _line), borderRadius: BorderRadius.circular(12)),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Kode room: $roomCode', style: const TextStyle(color: _text, fontSize: 13, fontFamily: 'Rajdhani')),
          ]),
        ),
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Text(statusText, textAlign: TextAlign.center,
          style: TextStyle(color: check ? _checkHi : _textDim, fontSize: 13.5, fontWeight: check ? FontWeight.bold : FontWeight.normal, fontFamily: 'Rajdhani')),
      ),
      _capturedRow('Dimakan Hitam', cap.byBlack, advTop),
      const SizedBox(height: 4),
      AspectRatio(
        aspectRatio: 1,
        child: Container(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: _line)),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
              itemCount: 64,
              itemBuilder: (context, i) {
                final r = i ~/ 8, c = i % 8;
                final light = (r + c) % 2 == 0;
                final piece = s.board[r][c];
                final isSel = selected != null && selected!['r'] == r && selected!['c'] == c;
                final isLast = (lastMoveFrom != null && lastMoveFrom!['r'] == r && lastMoveFrom!['c'] == c) ||
                    (lastMoveTo != null && lastMoveTo!['r'] == r && lastMoveTo!['c'] == c);
                final isCheckSq = kp != null && kp['r'] == r && kp['c'] == c;
                final legalHere = legalForSelected.where((m) => m.toR == r && m.toC == c).toList();
                final isLegal = legalHere.isNotEmpty;
                final isCapture = isLegal && piece != null;

                return GestureDetector(
                  onTap: () => _cellClick(r, c),
                  child: Container(
                    color: light ? _lightSq : _darkSq,
                    child: Stack(alignment: Alignment.center, children: [
                      if (isSel) Container(color: _sel),
                      if (isLast && !isSel) Container(color: _lastHi),
                      if (isCheckSq) Container(color: _checkHi),
                      if (piece != null)
                        Text(_glyph[piece] ?? '', style: TextStyle(
                          fontSize: 26,
                          color: piece[0] == 'w' ? Colors.white : const Color(0xFF1A1A1A),
                          shadows: piece[0] == 'w'
                              ? [const Shadow(color: Colors.black54, blurRadius: 2, offset: Offset(0, 1))]
                              : [const Shadow(color: Colors.white38, blurRadius: 1, offset: Offset(0, 1))],
                        )),
                      if (isLegal && !isCapture)
                        Container(width: 14, height: 14, decoration: BoxDecoration(shape: BoxShape.circle, color: _accent.withOpacity(0.65))),
                      if (isCapture)
                        Container(
                          margin: const EdgeInsets.all(2),
                          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: _accent.withOpacity(0.65), width: 3)),
                        ),
                    ]),
                  ),
                );
              },
            ),
          ),
        ),
      ),
      const SizedBox(height: 10),
      _capturedRow('Dimakan Putih', cap.byWhite, advBottom),
      if (errorMsg.isNotEmpty) Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(errorMsg, textAlign: TextAlign.center, style: const TextStyle(color: _checkHi, fontSize: 12, fontFamily: 'Rajdhani')),
      ),
      const SizedBox(height: 8),
      SizedBox(
        width: double.infinity, height: 46,
        child: OutlinedButton(
          onPressed: _backToMenu,
          style: OutlinedButton.styleFrom(side: const BorderSide(color: _line), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
          child: const Text('Keluar', style: TextStyle(color: _textDim, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')),
        ),
      ),
    ]);
  }

  Widget _capturedRow(String label, List<String> pieces, String adv) {
    return Container(
      constraints: const BoxConstraints(minHeight: 34),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: _panel, border: Border.all(color: _line), borderRadius: BorderRadius.circular(10)),
      child: Row(children: [
        Text(label, style: const TextStyle(color: _textDim, fontSize: 10, fontFamily: 'Rajdhani')),
        const SizedBox(width: 6),
        Expanded(
          child: Wrap(spacing: 2, children: pieces.map((p) => Text(_glyph[p] ?? '', style: TextStyle(
            fontSize: 16,
            color: p[0] == 'w' ? Colors.white : const Color(0xFF1A1A1A),
            shadows: p[0] == 'w'
                ? [const Shadow(color: Colors.black54, blurRadius: 2)]
                : [const Shadow(color: Colors.white38, blurRadius: 1)],
          ))).toList()),
        ),
        if (adv.isNotEmpty) Text(adv, style: const TextStyle(color: _accent2, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')),
      ]),
    );
  }
}
