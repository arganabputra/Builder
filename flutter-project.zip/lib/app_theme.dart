// ============================================================
// APP THEME - Sistem ganti warna dominan
// Tambah warna baru di appColorPalettes aja
// ============================================================
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ── Definisi satu palet warna ────────────────────────────────
class AppColorPalette {
  final String id;
  final String name;
  final Color primary;    // warna utama (glow, border, button)
  final Color secondary;  // warna aksen kedua
  final Color gradient1;  // gradient start
  final Color gradient2;  // gradient end

  const AppColorPalette({
    required this.id,
    required this.name,
    required this.primary,
    required this.secondary,
    required this.gradient1,
    required this.gradient2,
  });
}

// ── Daftar semua palet yang tersedia ─────────────────────────
const List<AppColorPalette> appColorPalettes = [
  AppColorPalette(
    id: 'purple',
    name: 'Nebula Purple',
    primary: Color(0xFFFF1744),
    secondary: Color(0xFFCE93D8),
    gradient1: Color(0xFF4A0080),
    gradient2: Color(0xFF9C27B0),
  ),
  AppColorPalette(
    id: 'blue',
    name: 'Arctic Blue',
    primary: Color(0xFFFF1744),
    secondary: Color(0xFF2196F3),
    gradient1: Color(0xFF0D47A1),
    gradient2: Color(0xFF00AAFF),
  ),
  AppColorPalette(
    id: 'cyan',
    name: 'Cyber Cyan',
    primary: Color(0xFFFF1744),
    secondary: Color(0xFF00BCD4),
    gradient1: Color(0xFF006064),
    gradient2: Color(0xFF00E5FF),
  ),
  AppColorPalette(
    id: 'green',
    name: 'Matrix Green',
    primary: Color(0xFFFF1744),
    secondary: Color(0xFF4CAF50),
    gradient1: Color(0xFF1B5E20),
    gradient2: Color(0xFF00E676),
  ),
  AppColorPalette(
    id: 'red',
    name: 'Blood Red',
    primary: Color(0xFFFF1744),
    secondary: Color(0xFFE53935),
    gradient1: Color(0xFF7F0000),
    gradient2: Color(0xFFFF1744),
  ),
  AppColorPalette(
    id: 'orange',
    name: 'Blaze Orange',
    primary: Color(0xFFFF1744),
    secondary: Color(0xFFFF9100),
    gradient1: Color(0xFF6D1F00),
    gradient2: Color(0xFFFF6D00),
  ),
  AppColorPalette(
    id: 'pink',
    name: 'Neon Pink',
    primary: Color(0xFFFF1744),
    secondary: Color(0xFFF06292),
    gradient1: Color(0xFF6A0036),
    gradient2: Color(0xFFFF4081),
  ),
  AppColorPalette(
    id: 'gold',
    name: 'Royal Gold',
    primary: Color(0xFFFF1744),
    secondary: Color(0xFFFFA000),
    gradient1: Color(0xFF6D4C00),
    gradient2: Color(0xFFFFD700),
  ),
  AppColorPalette(
    id: 'teal',
    name: 'Deep Teal',
    primary: Color(0xFFFF1744),
    secondary: Color(0xFF00BFA5),
    gradient1: Color(0xFF004D40),
    gradient2: Color(0xFF1DE9B6),
  ),
  AppColorPalette(
    id: 'indigo',
    name: 'Deep Indigo',
    primary: Color(0xFFFF1744),
    secondary: Color(0xFF651FFF),
    gradient1: Color(0xFF1A0066),
    gradient2: Color(0xFF7C4DFF),
  ),
];

// ── ThemeNotifier: state manager warna ──────────────────────
class ThemeNotifier extends ChangeNotifier {
  static const _prefKey = 'selected_theme_id';
  static const _defaultId = 'red'; // DEFAULT: MERAH

  AppColorPalette _current = appColorPalettes.firstWhere(
    (p) => p.id == _defaultId,
  );

  AppColorPalette get current => _current;
  Color get primary => _current.primary;
  Color get secondary => _current.secondary;
  Color get gradient1 => _current.gradient1;
  Color get gradient2 => _current.gradient2;

  // Load dari SharedPreferences saat app start
  Future<void> loadSaved() async {
    final prefs = await SharedPreferences.getInstance();
    final savedId = prefs.getString(_prefKey) ?? _defaultId;
    final found = appColorPalettes.where((p) => p.id == savedId);
    if (found.isNotEmpty) {
      _current = found.first;
      notifyListeners();
    }
  }

  // Ganti tema dan simpan
  Future<void> setTheme(AppColorPalette palette) async {
    _current = palette;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, palette.id);
  }

  // Build MaterialApp theme dari palet aktif
  ThemeData buildTheme() {
    const noDecoration = TextStyle(decoration: TextDecoration.none, decorationColor: Colors.transparent);
    return ThemeData(
      brightness: Brightness.dark,
      fontFamily: 'Rajdhani',
      scaffoldBackgroundColor: Colors.black,
      colorScheme: ColorScheme.dark(
        primary: _current.primary,
        secondary: _current.secondary,
        surface: const Color(0xFF0A0A0A),
      ),
      textTheme: TextTheme(
        displayLarge: noDecoration,
        displayMedium: noDecoration,
        displaySmall: noDecoration,
        headlineLarge: noDecoration,
        headlineMedium: noDecoration,
        headlineSmall: noDecoration,
        titleLarge: noDecoration,
        titleMedium: noDecoration,
        titleSmall: noDecoration,
        bodyLarge: noDecoration,
        bodyMedium: noDecoration,
        bodySmall: noDecoration,
        labelLarge: noDecoration,
        labelMedium: noDecoration,
        labelSmall: noDecoration,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: _current.primary,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}

// ── Global instance (InheritedWidget pattern) ────────────────
class ThemeProvider extends InheritedNotifier<ThemeNotifier> {
  const ThemeProvider({
    super.key,
    required ThemeNotifier notifier,
    required super.child,
  }) : super(notifier: notifier);

  static ThemeNotifier of(BuildContext context) {
    final provider =
        context.dependOnInheritedWidgetOfExactType<ThemeProvider>();
    assert(provider != null, 'ThemeProvider not found in widget tree');
    return provider!.notifier!;
  }
}
