import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'landing_page.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});
  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> with TickerProviderStateMixin {

  // ── Animasi controllers ──────────────────────────────────────
  late AnimationController _bgCtrl;
  late AnimationController _contentCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _tapCtrl;

  late Animation<double> _bgFade;
  late Animation<double> _contentFade;
  late Animation<Offset> _contentSlide;
  late Animation<double> _titleScale;
  late Animation<double> _pulse;
  late Animation<double> _tapFade;

  // ── Typing animation ─────────────────────────────────────────
  String _typedText = '';
  bool _cursorVisible = true;
  Timer? _typeTimer;
  Timer? _cursorTimer;
  int _typeIndex = 0;
  static const _fullText = 'Dominus Core';
  bool _typingDone = false;

  // ── Colors ───────────────────────────────────────────────────
  static const _purple     = Color(0xFFA855F7);
  static const _purpleDark = Color(0xFF7C3AED);
  static const _cyan       = Color(0xFF06B6D4);

  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));

    // BG fade in
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _bgFade = CurvedAnimation(parent: _bgCtrl, curve: Curves.easeIn);

    // Content slide + fade
    _contentCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _contentFade  = CurvedAnimation(parent: _contentCtrl, curve: Curves.easeOut);
    _contentSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _contentCtrl, curve: Curves.easeOutCubic));
    _titleScale = Tween<double>(begin: 0.92, end: 1.0)
        .animate(CurvedAnimation(parent: _contentCtrl, curve: Curves.easeOutCubic));

    // Glow pulse
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.5, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    // Tap hint fade
    _tapCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _tapFade = Tween<double>(begin: 0.4, end: 1.0)
        .animate(CurvedAnimation(parent: _tapCtrl, curve: Curves.easeInOut));

    // Cursor blink
    _cursorTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      if (mounted) setState(() => _cursorVisible = !_cursorVisible);
    });

    // Sequence
    _bgCtrl.forward().then((_) {
      _contentCtrl.forward().then((_) {
        _startTyping();
      });
    });
  }

  void _startTyping() {
    _typeTimer = Timer.periodic(const Duration(milliseconds: 80), (t) {
      if (_typeIndex < _fullText.length) {
        setState(() {
          _typedText = _fullText.substring(0, _typeIndex + 1);
          _typeIndex++;
        });
      } else {
        t.cancel();
        setState(() => _typingDone = true);
      }
    });
  }

  void _goToLanding() {
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 600),
        pageBuilder: (_, __, ___) => const LandingPage(),
        transitionsBuilder: (_, anim, __, child) =>
          FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _contentCtrl.dispose();
    _pulseCtrl.dispose();
    _tapCtrl.dispose();
    _typeTimer?.cancel();
    _cursorTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: _goToLanding,
        child: Stack(
          fit: StackFit.expand,
          children: [

            // ── Background cyberpunk image ──────────────────────
            FadeTransition(
              opacity: _bgFade,
              child: Image.asset(
                'assets/images/welcome.jpg',
                fit: BoxFit.cover,
                width: size.width,
                height: size.height,
              ),
            ),

            // ── Dark overlay gradient ───────────────────────────
            FadeTransition(
              opacity: _bgFade,
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0x88000000),
                      Color(0xBB000000),
                      Color(0xEE000000),
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),

            // ── Glow accent kiri bawah ──────────────────────────
            Positioned(
              bottom: -100,
              left: -80,
              child: AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) => Container(
                  width: 350,
                  height: 350,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        _purple.withOpacity(0.25 * _pulse.value),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // ── Glow accent kanan atas ──────────────────────────
            Positioned(
              top: -60,
              right: -60,
              child: AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) => Container(
                  width: 280,
                  height: 280,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        _cyan.withOpacity(0.15 * _pulse.value),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // ── Konten utama ────────────────────────────────────
            SlideTransition(
              position: _contentSlide,
              child: FadeTransition(
                opacity: _contentFade,
                child: ScaleTransition(
                  scale: _titleScale,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        // Label kecil
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: _purple.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: _purple.withOpacity(0.5), width: 1),
                          ),
                          child: const Text(
                            '✦  DOMINUS CORE',
                            style: TextStyle(
                              color: _purple,
                              fontFamily: 'Rajdhani',
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2.5,
                            ),
                          ),
                        ),

                        const SizedBox(height: 20),

                        // "Welcome to,"
                        const Text(
                          'Welcome to,',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Rajdhani',
                            fontSize: 32,
                            fontWeight: FontWeight.w300,
                            letterSpacing: 1,
                            height: 1.1,
                          ),
                        ),

                        const SizedBox(height: 4),

                        // "Dominus Core" typing animation + glow
                        AnimatedBuilder(
                          animation: _pulse,
                          builder: (_, __) => Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                _typedText,
                                style: TextStyle(
                                  fontFamily: 'Rajdhani',
                                  fontSize: 46,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5,
                                  height: 1.0,
                                  foreground: Paint()
                                    ..shader = const LinearGradient(
                                      colors: [_purple, _cyan],
                                    ).createShader(const Rect.fromLTWH(0, 0, 300, 60)),
                                  shadows: [
                                    Shadow(
                                      color: _purple.withOpacity(0.8 * _pulse.value),
                                      blurRadius: 20,
                                    ),
                                    Shadow(
                                      color: _cyan.withOpacity(0.4 * _pulse.value),
                                      blurRadius: 40,
                                    ),
                                  ],
                                ),
                              ),
                              if (!_typingDone)
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 6),
                                  child: AnimatedOpacity(
                                    opacity: _cursorVisible ? 1.0 : 0.0,
                                    duration: const Duration(milliseconds: 100),
                                    child: const Text(
                                      '|',
                                      style: TextStyle(
                                        color: _purple,
                                        fontSize: 40,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // "By Daniel"
                        Row(children: [
                          Container(width: 30, height: 1, color: _purple.withOpacity(0.6)),
                          const SizedBox(width: 10),
                          const Text(
                            'By Daniel',
                            style: TextStyle(
                              color: Colors.white60,
                              fontFamily: 'Rajdhani',
                              fontSize: 15,
                              letterSpacing: 2,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ]),

                        const SizedBox(height: 28),

                        // Info baris: versi + update
                        ClipRRect(
                          borderRadius: BorderRadius.circular(14),
                          child: BackdropFilter(
                            filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.06),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: Colors.white.withOpacity(0.12), width: 1),
                              ),
                              child: Row(children: [
                                _infoChip(Icons.rocket_launch_rounded, 'Version', 'V1.0', _purple),
                                _divider(),
                                _infoChip(Icons.update_rounded, 'Update', 'Rutin', _cyan),
                                _divider(),
                                _infoChip(Icons.shield_rounded, 'Status', 'Stable', const Color(0xFF22C55E)),
                              ]),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // ── Tap untuk melanjutkan (bawah) ───────────────────
            Positioned(
              bottom: 60,
              left: 0,
              right: 0,
              child: FadeTransition(
                opacity: _contentFade,
                child: Column(children: [
                  FadeTransition(
                    opacity: _tapFade,
                    child: Column(children: [
                      AnimatedBuilder(
                        animation: _pulse,
                        builder: (_, __) => Icon(
                          Icons.touch_app_rounded,
                          color: _purple.withOpacity(0.7 + 0.3 * _pulse.value),
                          size: 28,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'TAP TO CONTINUE',
                        style: TextStyle(
                          color: Colors.white54,
                          fontFamily: 'Rajdhani',
                          fontSize: 11,
                          letterSpacing: 3,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ]),
                  ),
                ]),
              ),
            ),

          ],
        ),
      ),
    );
  }

  Widget _infoChip(IconData icon, String label, String value, Color color) {
    return Expanded(
      child: Column(children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13)),
        Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 10, letterSpacing: 0.5)),
      ]),
    );
  }

  Widget _divider() => Container(width: 1, height: 36, color: Colors.white12, margin: const EdgeInsets.symmetric(horizontal: 8));
}
