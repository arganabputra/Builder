import 'package:shared_preferences/shared_preferences.dart';

// ============================================================
// CONFIG - Ganti baseUrl di sini jika server berubah
// ============================================================
class AppConfig {
  static const String _defaultBaseUrl   = "http://dannmaudieweepanel.xtxintax.my.id:4859";
  static const String _defaultWsBaseUrl = "ws://dannmaudieweepanel.xtxintax.my.id:4859";
  
  static String? _overrideBaseUrl;
  static String? _overrideWsBaseUrl;
  
  static String get baseUrl => _overrideBaseUrl ?? _defaultBaseUrl;
  static String get wsBaseUrl => _overrideWsBaseUrl ?? _defaultWsBaseUrl;
  
  // Set base URL dan save ke SharedPreferences
  static Future<void> setBaseUrl(String newUrl) async {
    _overrideBaseUrl = newUrl;
    _overrideWsBaseUrl = newUrl.replaceFirst('http', 'ws');
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('override_base_url', newUrl);
  }
  
  // Domain lama yang harus di-reset otomatis ke default baru
  static const List<String> _legacyDomains = [
    'http://dancihuypanel.myserverr.web.id:2038',
    'http://panelres.rexzystr.my.id:7031',
    'http://admin.rexzystr.my.id:9233',
    'http://dikzhostpanel.digitalocean-cloud.my.id:10048',
    'http://dikzhostt.digitalocean-cloud.my.id:11703',
    'http://dikzsyicol99.digitalocean-cloud.my.id:10355',
    'http://olineee.jkt48-private.com:3599',
  ];

  // Load base URL dari SharedPreferences saat app startup
  static Future<void> loadBaseUrl() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUrl = prefs.getString('override_base_url');
    if (savedUrl != null && savedUrl.isNotEmpty) {
      // Reset kalau URL lama atau sama dengan default (gak perlu override)
      if (savedUrl == _defaultBaseUrl || _legacyDomains.contains(savedUrl)) {
        await prefs.remove('override_base_url');
        _overrideBaseUrl = null;
        _overrideWsBaseUrl = null;
      } else {
        _overrideBaseUrl = savedUrl;
        _overrideWsBaseUrl = savedUrl.replaceFirst('http', 'ws');
      }
    }
  }
  
  // Reset ke default base URL
  static Future<void> resetBaseUrl() async {
    _overrideBaseUrl = null;
    _overrideWsBaseUrl = null;
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('override_base_url');
  }
}
