import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class SynclavePage extends StatefulWidget {
  const SynclavePage({super.key});
  @override
  State<SynclavePage> createState() => _SynclavePageState();
}

class _SynclavePageState extends State<SynclavePage> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fadeAnim;
  late Animation<double> _pulseAnim;

  static const _bg    = Color(0xFF05080F);
  static const _card  = Color(0xFF0C1220);
  static const _red   = Color(0xFFFF1744);
  static const _border = Color(0xFF1A2235);

  static const _telegramLink = 'https://t.me/synclave';

  static const _topics = [
    _Topic(Icons.phone_android_rounded,   'Pengembangan APK',    'Belajar bikin APK dari nol, mulai dari setup hingga publish'),
    _Topic(Icons.code_rounded,            'Flutter & Dart',      'Tutorial coding Flutter, widget, state management, dan API integration'),
    _Topic(Icons.terminal_rounded,        'Backend & API',       'Node.js, Express, database, dan cara bikin API yang solid'),
    _Topic(Icons.design_services_rounded, 'UI/UX Design',       'Prinsip desain premium, dark UI, dan cara bikin tampilan yang keren'),
    _Topic(Icons.security_rounded,        'App Security',        'Cara melindungi app dari reverse engineering dan vulnerability'),
    _Topic(Icons.groups_rounded,          'Diskusi & Sharing',   'Sharing project, minta feedback, dan kolaborasi bareng member lain'),
  ];

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true), curve: Curves.easeInOut));
    _ctrl.forward();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  Future<void> _join() async {
    final uri = Uri.parse(_telegramLink);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: FadeTransition(
        opacity: _fadeAnim,
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            // ── AppBar ──
            SliverAppBar(
              expandedHeight: 280,
              pinned: true,
              backgroundColor: _bg,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
                onPressed: () => Navigator.pop(context),
              ),
              flexibleSpace: FlexibleSpaceBar(
                background: Stack(children: [
                  // Background gradient
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [_red.withOpacity(0.15), _bg],
                      ),
                    ),
                  ),
                  // Grid pattern
                  Positioned.fill(child: CustomPaint(painter: _GridPainter())),
                  // Glow
                  Positioned(
                    top: -60, left: 0, right: 0,
                    child: Container(
                      height: 200,
                      decoration: BoxDecoration(
                        gradient: RadialGradient(
                          colors: [_red.withOpacity(0.18), Colors.transparent],
                          radius: 0.8,
                        ),
                      ),
                    ),
                  ),
                  // Content
                  Positioned(
                    bottom: 30, left: 0, right: 0,
                    child: Column(children: [
                      // Avatar
                      Container(
                        width: 90, height: 90,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(colors: [_red.withOpacity(0.3), _red.withOpacity(0.05)]),
                          border: Border.all(color: _red.withOpacity(0.5), width: 2),
                          boxShadow: [BoxShadow(color: _red.withOpacity(0.3), blurRadius: 30, spreadRadius: 4)],
                        ),
                        child: const Icon(Icons.groups_rounded, color: _red, size: 44),
                      ),
                      const SizedBox(height: 12),
                      const Text('SynClave', style: TextStyle(
                        color: Colors.white, fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w900, fontSize: 28, letterSpacing: 2,
                      )),
                      const SizedBox(height: 4),
                      Text('Komunitas Developer & Builder', style: TextStyle(
                        color: Colors.white.withOpacity(0.45), fontFamily: 'Rajdhani', fontSize: 13,
                      )),
                    ]),
                  ),
                ]),
              ),
            ),

            SliverToBoxAdapter(child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                // Stats row
                Row(children: [
                  _statChip(Icons.telegram_rounded, 'Telegram', 'Community'),
                  const SizedBox(width: 10),
                  _statChip(Icons.auto_stories_rounded, '6 Topik', 'Pembelajaran'),
                  const SizedBox(width: 10),
                  _statChip(Icons.lock_open_rounded, 'Gratis', 'Untuk Semua'),
                ]),
                const SizedBox(height: 20),

                // Deskripsi
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: _card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _border),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Container(width: 3, height: 14,
                        decoration: BoxDecoration(color: _red, borderRadius: BorderRadius.circular(2))),
                      const SizedBox(width: 8),
                      const Text('TENTANG SYNCLAVE', style: TextStyle(
                        color: Colors.white54, fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w700, fontSize: 11, letterSpacing: 2)),
                    ]),
                    const SizedBox(height: 12),
                    Text(
                      'SynClave adalah komunitas bagi kamu yang ingin belajar dan berkembang di dunia pengembangan aplikasi mobile. '
                      'Di sini kamu bisa belajar cara bikin APK sendiri, coding Flutter, sampai membangun backend yang solid.\n\n'
                      'Gak perlu pengalaman sebelumnya — semua level welcome. Yang penting ada niat buat belajar dan berbagi.',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.65),
                        fontFamily: 'Rajdhani', fontSize: 13, height: 1.7,
                      ),
                    ),
                  ]),
                ),
                const SizedBox(height: 16),

                // Topik
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: _card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _border),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Container(width: 3, height: 14,
                        decoration: BoxDecoration(color: _red, borderRadius: BorderRadius.circular(2))),
                      const SizedBox(width: 8),
                      const Text('YANG DIBAHAS', style: TextStyle(
                        color: Colors.white54, fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w700, fontSize: 11, letterSpacing: 2)),
                    ]),
                    const SizedBox(height: 14),
                    ..._topics.map((t) => _topicRow(t)),
                  ]),
                ),
                const SizedBox(height: 24),

                // Join button
                GestureDetector(
                  onTap: _join,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_red, _red.withOpacity(0.7)],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: _red.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 6))],
                    ),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.telegram_rounded, color: Colors.white, size: 20),
                      SizedBox(width: 10),
                      Text('GABUNG SEKARANG', style: TextStyle(
                        color: Colors.white, fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1.5,
                      )),
                    ]),
                  ),
                ),
                const SizedBox(height: 12),
                Center(
                  child: Text('Gratis • Semua level • Aktif setiap hari',
                    style: TextStyle(color: Colors.white.withOpacity(0.25), fontFamily: 'Rajdhani', fontSize: 11)),
                ),
              ]),
            )),
          ],
        ),
      ),
    );
  }

  Widget _statChip(IconData icon, String val, String label) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _border),
      ),
      child: Column(children: [
        Icon(icon, color: _red, size: 18),
        const SizedBox(height: 5),
        Text(val, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 12)),
        Text(label, style: TextStyle(color: Colors.white.withOpacity(0.35), fontFamily: 'Rajdhani', fontSize: 9)),
      ]),
    ),
  );

  Widget _topicRow(_Topic t) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: Row(children: [
      Container(
        width: 38, height: 38,
        decoration: BoxDecoration(
          color: _red.withOpacity(0.08),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _red.withOpacity(0.2)),
        ),
        child: Icon(t.icon, color: _red.withOpacity(0.8), size: 18),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t.title, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 13)),
        const SizedBox(height: 2),
        Text(t.desc, style: TextStyle(color: Colors.white.withOpacity(0.4), fontFamily: 'Rajdhani', fontSize: 11, height: 1.4)),
      ])),
    ]),
  );
}

class _Topic {
  final IconData icon;
  final String title;
  final String desc;
  const _Topic(this.icon, this.title, this.desc);
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 28.0;
    final paint = Paint()
      ..color = const Color(0xFFFF1744).withOpacity(0.07)
      ..strokeWidth = 0.7;
    for (double x = 0; x <= size.width; x += spacing)
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y <= size.height; y += spacing)
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
  }
  @override
  bool shouldRepaint(_GridPainter old) => false;
}
