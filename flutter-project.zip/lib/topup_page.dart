// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════════
//  TOP UP SALDO — PAYMENT GATEWAY QRIS
// ═══════════════════════════════════════════════════════════════
class TopUpPage extends StatefulWidget {
  final String sessionKey;
  final int currentBalance;
  const TopUpPage({super.key, required this.sessionKey, required this.currentBalance});

  @override
  State<TopUpPage> createState() => _TopUpPageState();
}

class _TopUpPageState extends State<TopUpPage> {
  final _amountCtrl = TextEditingController();
  final _amounts = const [10000, 25000, 50000, 100000, 250000, 500000];

  // step: 0 = pilih nominal, 1 = bayar QRIS
  int _step = 0;
  bool _loading = false;

  String? _topupId;
  String? _qrisImageUrl;
  int _amount = 0;
  int _fee = 0;
  int _total = 0;
  DateTime? _expiresAt;

  Timer? _pollTimer;
  Timer? _clockTimer;
  Duration _remaining = Duration.zero;

  @override
  void dispose() {
    _amountCtrl.dispose();
    _pollTimer?.cancel();
    _clockTimer?.cancel();
    super.dispose();
  }

  String _fmtRupiah(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      final posFromEnd = s.length - i;
      buf.write(s[i]);
      if (posFromEnd > 1 && posFromEnd % 3 == 1) buf.write('.');
    }
    return 'Rp $buf';
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
      backgroundColor: const Color(0xFF1A1A1A),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  Future<void> _createInvoice() async {
    final amount = int.tryParse(_amountCtrl.text);
    if (amount == null || amount < 1000) { _toast('Minimum top up Rp 1.000'); return; }

    setState(() => _loading = true);
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/marketplace/topup-qris'),
        headers: {'x-session-key': widget.sessionKey, 'Content-Type': 'application/json'},
        body: jsonEncode({'amount': amount}),
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        final t = data['topup'];
        setState(() {
          _topupId = t['id'];
          _qrisImageUrl = t['qrisImageUrl'];
          _amount = t['amount'];
          _fee = t['fee'] ?? 0;
          _total = t['total'] ?? amount;
          _expiresAt = DateTime.tryParse(t['expiresAt'] ?? '') ?? DateTime.now().add(const Duration(minutes: 15));
          _step = 1;
        });
        _startClock();
        _startPolling();
      } else {
        _toast(data['message'] ?? 'Gagal membuat QRIS');
      }
    } catch (_) {
      _toast('Gagal konek ke server');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _startClock() {
    _clockTimer?.cancel();
    _updateRemaining();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) => _updateRemaining());
  }

  void _updateRemaining() {
    if (!mounted || _expiresAt == null) return;
    final diff = _expiresAt!.difference(DateTime.now());
    setState(() => _remaining = diff.isNegative ? Duration.zero : diff);
    if (diff.isNegative) {
      _clockTimer?.cancel();
      _pollTimer?.cancel();
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 4), (_) => _checkStatus());
  }

  Future<void> _checkStatus() async {
    if (_topupId == null) return;
    try {
      final res = await http.get(
        Uri.parse('${AppConfig.baseUrl}/api/marketplace/topup-qris/$_topupId'),
        headers: {'x-session-key': widget.sessionKey},
      );
      final data = jsonDecode(res.body);
      if (data['success'] != true) return;

      if (data['status'] == 'paid') {
        _pollTimer?.cancel();
        _clockTimer?.cancel();
        if (!mounted) return;
        await _showSuccess(data['balance'] ?? 0);
      } else if (data['status'] == 'expired') {
        _pollTimer?.cancel();
        _clockTimer?.cancel();
        if (mounted) _toast('QRIS sudah kedaluwarsa');
      }
    } catch (_) {
      // diamkan, coba lagi di polling berikutnya
    }
  }

  Future<void> _showSuccess(int newBalance) async {
    final theme = ThemeProvider.of(context);
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF111111),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.check_circle_rounded, color: theme.primary, size: 56),
          const SizedBox(height: 12),
          const Text('PEMBAYARAN BERHASIL', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 6),
          Text('Saldo bertambah ${_fmtRupiah(_amount)}', style: const TextStyle(color: Colors.white60, fontFamily: 'Rajdhani')),
          const SizedBox(height: 4),
          Text('Saldo sekarang: ${_fmtRupiah(newBalance)}', style: TextStyle(color: theme.primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
        ]),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: theme.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              onPressed: () => Navigator.pop(context),
              child: const Text('OKE', style: TextStyle(color: Colors.black, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
    );
    if (mounted) Navigator.pop(context, newBalance);
  }

  String _fmtDuration(Duration d) {
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final theme = ThemeProvider.of(context);
    final primary = theme.primary;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, color: primary),
          onPressed: () {
            if (_step == 1) {
              // Balik ke pilih nominal, batalkan polling QRIS lama
              _pollTimer?.cancel();
              _clockTimer?.cancel();
              setState(() => _step = 0);
            } else {
              Navigator.pop(context);
            }
          },
        ),
        title: Text('TOP UP SALDO', style: TextStyle(color: primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 2)),
      ),
      body: _step == 0 ? _buildAmountStep(primary) : _buildQrisStep(primary),
    );
  }

  // ── Step 0: pilih nominal ─────────────────────────────────────
  Widget _buildAmountStep(Color primary) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: primary.withOpacity(0.08),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: primary.withOpacity(0.25)),
          ),
          child: Row(children: [
            Icon(Icons.account_balance_wallet_rounded, color: primary, size: 22),
            const SizedBox(width: 10),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Saldo saat ini', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
              Text(_fmtRupiah(widget.currentBalance), style: TextStyle(color: primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 18)),
            ]),
          ]),
        ),
        const SizedBox(height: 24),
        const Text('PILIH NOMINAL', style: TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1)),
        const SizedBox(height: 10),
        Wrap(spacing: 10, runSpacing: 10, children: _amounts.map((a) {
          final selected = _amountCtrl.text == a.toString();
          return GestureDetector(
            onTap: () => setState(() => _amountCtrl.text = a.toString()),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: selected ? primary.withOpacity(0.2) : primary.withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: selected ? primary : primary.withOpacity(0.2), width: selected ? 1.5 : 1),
              ),
              child: Text(_fmtRupiah(a), style: TextStyle(color: selected ? primary : Colors.white70, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13)),
            ),
          );
        }).toList()),
        const SizedBox(height: 20),
        const Text('ATAU MASUKKAN NOMINAL', style: TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1)),
        const SizedBox(height: 10),
        TextField(
          controller: _amountCtrl,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          onChanged: (_) => setState(() {}),
          style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 16),
          decoration: InputDecoration(
            hintText: 'Minimal Rp 1.000',
            hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani'),
            prefixIcon: Icon(Icons.payments_outlined, color: primary.withOpacity(0.6), size: 20),
            filled: true,
            fillColor: const Color(0xFF0D0D0D),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: primary.withOpacity(0.3))),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.white12)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: primary)),
          ),
        ),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.03),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(children: [
            Icon(Icons.qr_code_2_rounded, color: primary, size: 20),
            const SizedBox(width: 10),
            const Expanded(child: Text('Pembayaran khusus via QRIS. Scan pakai e-wallet / m-banking apa aja.', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12))),
          ]),
        ),
        const SizedBox(height: 28),
        SizedBox(
          width: double.infinity, height: 52,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            onPressed: _loading ? null : _createInvoice,
            child: _loading
                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                : const Text('LANJUT BAYAR QRIS', style: TextStyle(color: Colors.black, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16)),
          ),
        ),
      ]),
    );
  }

  // ── Step 1: bayar QRIS ─────────────────────────────────────────
  Widget _buildQrisStep(Color primary) {
    final expired = _remaining == Duration.zero;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        Container(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
          decoration: BoxDecoration(
            color: expired ? Colors.red.withOpacity(0.1) : primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: expired ? Colors.red.withOpacity(0.4) : primary.withOpacity(0.4)),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(expired ? Icons.timer_off_rounded : Icons.timer_outlined, color: expired ? Colors.redAccent : primary, size: 18),
            const SizedBox(width: 8),
            Text(
              expired ? 'QRIS KEDALUWARSA' : 'Bayar dalam ${_fmtDuration(_remaining)}',
              style: TextStyle(color: expired ? Colors.redAccent : primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14),
            ),
          ]),
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF0D0D0D),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: primary.withOpacity(0.2)),
          ),
          child: Column(children: [
            const Text('SCAN QRIS UNTUK BAYAR', style: TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1)),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Opacity(
                opacity: expired ? 0.3 : 1,
                child: Image.network(
                  _qrisImageUrl ?? '',
                  width: 240, height: 240, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Container(
                    width: 240, height: 240,
                    color: Colors.white10,
                    child: const Center(child: Text('QRIS tidak tersedia\nHubungi admin', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani'))),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            _rowDetail('Nominal Top Up', _fmtRupiah(_amount), primary),
            if (_fee > 0) _rowDetail('Fee QRIS', '+ ${_fmtRupiah(_fee)}', primary),
            const Divider(color: Colors.white12, height: 24),
            _rowDetail('Total Bayar', _fmtRupiah(_total), primary, big: true),
          ]),
        ),
        const SizedBox(height: 20),
        Row(children: [
          Icon(expired ? Icons.error_outline_rounded : Icons.sync_rounded, color: expired ? Colors.redAccent : Colors.white38, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              expired
                  ? 'Waktu habis. Balik ke halaman sebelumnya buat bikin QRIS baru.'
                  : 'Saldo otomatis ketambah setelah pembayaran terverifikasi. Jangan tutup halaman ini.',
              style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12),
            ),
          ),
        ]),
        if (expired) ...[
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity, height: 50,
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(side: BorderSide(color: primary), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              onPressed: () => setState(() => _step = 0),
              child: Text('BUAT QRIS BARU', style: TextStyle(color: primary, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ]),
    );
  }

  Widget _rowDetail(String label, String value, Color primary, {bool big = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: big ? 14 : 13)),
      Text(value, style: TextStyle(color: big ? primary : Colors.white70, fontFamily: 'Rajdhani', fontWeight: big ? FontWeight.w900 : FontWeight.bold, fontSize: big ? 18 : 13)),
    ]),
  );
}
