// chat_page.dart — Redirect ke PublicChatPage (private chat system baru)
// File ini dipertahankan agar import lama di loader_page.dart tidak error.
// Semua logic chat privat ada di public_chat_page.dart (PrivateChatRoomPage).

export 'public_chat_page.dart' show PrivateChatRoomPage;
