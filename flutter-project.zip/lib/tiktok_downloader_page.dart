// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:share_plus/share_plus.dart';

class TikTokDownloaderPage extends StatefulWidget {
  final String sessionKey;
  const TikTokDownloaderPage({super.key, required this.sessionKey});

  @override
  State<TikTokDownloaderPage> createState() => _TikTokDownloaderPageState();
}

class _TikTokDownloaderPageState extends State<TikTokDownloaderPage>
    with TickerProviderStateMixin {
  final TextEditingController _urlController = TextEditingController();
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  static const Color _primaryBlue = Color(0xFFFF1744);
  static const Color _primaryCyan = Color(0xFFFF4081);
  static const Color _darkBg = Color(0xFF080D14);
  static const Color _cardBg = Color(0xFF0D1520);
  static const Color _cardBorder = Color(0xFF1A2840);

  bool _isLoading = false;
  Map<String, dynamic>? _result;
  String? _errorMsg;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    _urlController.dispose();
    super.dispose();
  }

  Future<void> _fetchVideo() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() => _errorMsg = "Masukkan link TikTok dulu!");
      return;
    }
    if (!url.contains('tiktok.com') && !url.contains('vm.tiktok')) {
      setState(() => _errorMsg = "Link tidak valid. Gunakan link TikTok.");
      return;
    }

    setState(() {
      _isLoading = true;
      _result = null;
      _errorMsg = null;
    });

    try {
      // Menggunakan API tikwm.com (public, no watermark)
      final apiUrl = Uri.parse(
          'https://www.tikwm.com/api/?url=${Uri.encodeComponent(url)}&hd=1');
      final response = await http.get(
        apiUrl,
        headers: {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'},
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        // Support berbagai format response API
        Map<String, dynamic>? videoData;

        if (data['code'] == 0 && data['data'] != null) {
          videoData = data['data'];
        } else if (data['status'] == true && data['result'] != null) {
          videoData = data['result'];
        } else if (data['success'] == true && data['data'] != null) {
          videoData = data['data'];
        } else if (data['data'] != null) {
          videoData = data['data'];
        } else if (data['result'] != null) {
          videoData = data['result'];
        }

        if (videoData != null) {
          setState(() {
            _result = videoData;
            _isLoading = false;
          });
        } else {
          // Debug: tampilkan raw response
          final rawPreview = response.body.length > 150 ? response.body.substring(0, 150) : response.body;
          setState(() {
            _errorMsg = "Gagal: ${data['msg'] ?? data['message'] ?? data['error'] ?? rawPreview}";
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _errorMsg = "Server error ${response.statusCode}: ${response.body.length > 100 ? response.body.substring(0, 100) : response.body}";
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMsg = "Koneksi gagal: ${e.toString()}";
        _isLoading = false;
      });
    }
  }

  bool _downloading = false;

  Future<void> _launchUrl(String url, {String label = "video"}) async {
    if (url.isEmpty) {
      if (mounted) setState(() => _errorMsg = "URL tidak tersedia.");
      return;
    }
    if (_downloading) return;
    if (mounted) setState(() { _downloading = true; _errorMsg = null; });

    try {
      final res = await http.get(
        Uri.parse(url),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G960F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
          'Referer': 'https://www.tiktok.com/',
        },
      ).timeout(const Duration(seconds: 45));

      if (res.statusCode == 200 && res.bodyBytes.isNotEmpty) {
        // Simpan ke folder khusus app dulu (nggak butuh izin storage sama sekali,
        // aman di semua versi Android termasuk 11+ yang scoped storage).
        final dir = await getTemporaryDirectory();
        final ext = label == "Audio" ? "mp3" : "mp4";
        final fileName = "TikTok_${DateTime.now().millisecondsSinceEpoch}.$ext";
        final path = "${dir.path}/$fileName";
        final file = File(path);
        await file.writeAsBytes(res.bodyBytes);

        if (mounted) {
          // Munculin share sheet biar user bisa "Save to Files" / simpan ke galeri.
          await Share.shareXFiles([XFile(path)], text: fileName);
        }
      } else {
        if (mounted) setState(() => _errorMsg = "Gagal download. Server response: ${res.statusCode}");
      }
    } catch (e) {
      if (mounted) setState(() => _errorMsg = "Gagal download: ${e.toString()}");
    }

    if (mounted) setState(() => _downloading = false);
  }

  String _formatNumber(dynamic n) {
    if (n == null) return '0';
    final num = int.tryParse(n.toString()) ?? 0;
    if (num >= 1000000) return '${(num / 1000000).toStringAsFixed(1)}M';
    if (num >= 1000) return '${(num / 1000).toStringAsFixed(1)}K';
    return num.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _darkBg,
      body: Stack(
        children: [
          // Background gradient
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF060C15), Color(0xFF080D14), Color(0xFF060C15)],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        const SizedBox(height: 8),
                        _buildInputCard(),
                        const SizedBox(height: 20),
                        if (_isLoading) _buildLoadingWidget(),
                        if (_errorMsg != null) _buildErrorWidget(),
                        if (_result != null) _buildResultCard(),
                        const SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: _darkBg,
            border: Border(
              bottom: BorderSide(color: _primaryBlue.withValues(alpha: 0.2), width: 1),
            ),
          ),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(
                    color: _cardBg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _cardBorder),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70, size: 16),
                ),
              ),
              const SizedBox(width: 12),
              // TikTok icon style
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF010101), Color(0xFF1A1A1A)],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _primaryBlue.withValues(alpha: 0.4)),
                ),
                child: const Center(
                  child: Text("TT", style: TextStyle(
                    color: Colors.white, fontSize: 12,
                    fontWeight: FontWeight.w900, fontFamily: "Rajdhani",
                  )),
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      colors: [Color(0xFFFF1744), Color(0xFFFF4081)],
                    ).createShader(bounds),
                    child: const Text(
                      "TIKTOK DOWNLOADER",
                      style: TextStyle(
                        color: Colors.white, fontSize: 15,
                        fontWeight: FontWeight.w900, fontFamily: "Rajdhani",
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                  Text(
                    "No Watermark • HD Quality",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 10, fontFamily: "Rajdhani",
                    ),
                  ),
                ],
              ),
            ],
          ),
    );
  }

  Widget _buildInputCard() {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, child) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _cardBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _cardBorder, width: 1.5),
            boxShadow: [
              BoxShadow(
                color: _primaryBlue.withValues(alpha: 0.06 * _glowAnimation.value),
                blurRadius: 25, spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 32, height: 32,
                    decoration: BoxDecoration(
                      color: _primaryBlue.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _primaryBlue.withValues(alpha: 0.3)),
                    ),
                    child: Icon(Icons.link_rounded, color: _primaryBlue, size: 16),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    "PASTE LINK TIKTOK",
                    style: TextStyle(
                      color: Colors.white, fontSize: 13,
                      fontWeight: FontWeight.bold, fontFamily: "Rajdhani",
                      letterSpacing: 1.5,
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () async {
                      final data = await Clipboard.getData('text/plain');
                      if (data?.text != null) {
                        _urlController.text = data!.text!;
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: _primaryCyan.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _primaryCyan.withValues(alpha: 0.3)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.content_paste_rounded, color: _primaryCyan, size: 12),
                          const SizedBox(width: 4),
                          Text("Paste", style: TextStyle(color: _primaryCyan, fontSize: 11, fontFamily: "Rajdhani")),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                decoration: BoxDecoration(
                  color: _darkBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _cardBorder),
                ),
                child: TextField(
                  controller: _urlController,
                  style: const TextStyle(color: Colors.white, fontFamily: "Rajdhani", fontSize: 13),
                  decoration: InputDecoration(
                    hintText: "https://www.tiktok.com/@user/video/...",
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.25), fontFamily: "Rajdhani", fontSize: 12),
                    prefixIcon: Icon(Icons.videocam_outlined, color: _primaryBlue.withValues(alpha: 0.6), size: 18),
                    suffixIcon: _urlController.text.isNotEmpty
                        ? GestureDetector(
                            onTap: () => setState(() => _urlController.clear()),
                            child: Icon(Icons.clear_rounded, color: Colors.white38, size: 16),
                          )
                        : null,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
              ),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: _isLoading ? null : _fetchVideo,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: double.infinity,
                  height: 50,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: _isLoading
                          ? [_cardBorder, _cardBorder]
                          : [_primaryBlue.withValues(alpha: 0.9), _primaryCyan.withValues(alpha: 0.7)],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: _isLoading ? [] : [
                      BoxShadow(
                        color: _primaryBlue.withValues(alpha: 0.3 * _glowAnimation.value),
                        blurRadius: 20, spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: Center(
                    child: _isLoading
                        ? const SizedBox(
                            width: 20, height: 20,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                          )
                        : Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Icon(Icons.download_rounded, color: Colors.white, size: 18),
                              SizedBox(width: 8),
                              Text(
                                "FETCH VIDEO",
                                style: TextStyle(
                                  color: Colors.white, fontWeight: FontWeight.bold,
                                  fontFamily: "Rajdhani", letterSpacing: 2, fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLoadingWidget() {
    return Container(
      padding: const EdgeInsets.all(30),
      child: Column(
        children: [
          AnimatedBuilder(
            animation: _glowAnimation,
            builder: (context, child) => Container(
              width: 60, height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _primaryBlue.withValues(alpha: 0.1),
                border: Border.all(color: _primaryBlue.withValues(alpha: _glowAnimation.value), width: 2),
                boxShadow: [BoxShadow(color: _primaryBlue.withValues(alpha: 0.3 * _glowAnimation.value), blurRadius: 20)],
              ),
              child: const Icon(Icons.search_rounded, color: Colors.white54, size: 28),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            "Mengambil info video...",
            style: TextStyle(color: Colors.white.withOpacity(0.6), fontFamily: "Rajdhani", fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorWidget() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.red.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _errorMsg!,
              style: const TextStyle(color: Colors.redAccent, fontFamily: "Rajdhani", fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultCard() {
    final data = _result!;
    final String title = data['title'] ?? 'No Title';
    final String author = data['author']?['nickname'] ?? 'Unknown';
    // thumb already declared above
    final String noWmUrl = data['play'] ?? data['nowm'] ?? data['no_watermark'] ?? data['video'] ?? data['wmplay'] ?? '';
    final String hdUrl = data['hdplay'] ?? data['hd'] ?? data['hd_video'] ?? noWmUrl;
    final String audioUrl = data['music'] ?? data['audio'] ?? data['music_url'] ?? '';
    final String thumb = data['cover'] ?? data['thumbnail'] ?? data['image'] ?? '';
    final dynamic likeCount = data['digg_count'] ?? 0;
    final dynamic commentCount = data['comment_count'] ?? 0;
    final dynamic shareCount = data['share_count'] ?? 0;

    return Container(
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _cardBorder, width: 1.5),
        boxShadow: [
          BoxShadow(color: _primaryBlue.withValues(alpha: 0.08), blurRadius: 20, spreadRadius: 2),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Thumbnail
          if (thumb.isNotEmpty)
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
              child: Stack(
                children: [
                  Image.network(
                    thumb, width: double.infinity, height: 200, fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(height: 200, color: _darkBg),
                  ),
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.transparent, _cardBg.withValues(alpha: 0.8)],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 12, left: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _primaryBlue.withValues(alpha: 0.4)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.check_circle_rounded, color: _primaryCyan, size: 12),
                          const SizedBox(width: 5),
                          Text("Video Ditemukan!", style: TextStyle(color: _primaryCyan, fontSize: 11, fontFamily: "Rajdhani", fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Author
                Row(
                  children: [
                    Container(
                      width: 32, height: 32,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _primaryBlue.withValues(alpha: 0.1),
                        border: Border.all(color: _primaryBlue.withValues(alpha: 0.3)),
                      ),
                      child: Icon(Icons.person_rounded, color: _primaryBlue, size: 16),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "@$author",
                      style: TextStyle(color: _primaryBlue, fontSize: 13, fontFamily: "Rajdhani", fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // Title
                Text(
                  title,
                  style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: "Rajdhani", height: 1.4),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 14),
                // Stats row
                Row(
                  children: [
                    _statChip(Icons.favorite_rounded, _formatNumber(likeCount), Colors.redAccent),
                    const SizedBox(width: 8),
                    _statChip(Icons.comment_rounded, _formatNumber(commentCount), _primaryBlue),
                    const SizedBox(width: 8),
                    _statChip(Icons.share_rounded, _formatNumber(shareCount), _primaryCyan),
                  ],
                ),
                const SizedBox(height: 16),
                const Divider(color: Color(0xFF1A2840), height: 1),
                const SizedBox(height: 16),
                // Download buttons
                if (noWmUrl.isNotEmpty)
                  _downloadButton(
                    icon: Icons.hd_rounded,
                    label: "Download No Watermark",
                    sublabel: "Tanpa logo TikTok",
                    color: _primaryBlue,
                    onTap: () => _launchUrl(noWmUrl, label: "Video"),
                  ),
                if (hdUrl.isNotEmpty && hdUrl != noWmUrl) ...[
                  const SizedBox(height: 10),
                  _downloadButton(
                    icon: Icons.high_quality_rounded,
                    label: "Download HD",
                    sublabel: "Resolusi terbaik",
                    color: _primaryCyan,
                    onTap: () => _launchUrl(hdUrl, label: "Video_HD"),
                  ),
                ],
                if (audioUrl.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  _downloadButton(
                    icon: Icons.music_note_rounded,
                    label: "Download Audio",
                    sublabel: "MP3 only",
                    color: const Color(0xFFFFB347),
                    onTap: () => _launchUrl(audioUrl, label: "Audio"),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statChip(IconData icon, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 11),
          const SizedBox(width: 4),
          Text(value, style: TextStyle(color: color, fontSize: 11, fontFamily: "Rajdhani", fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _downloadButton({
    required IconData icon,
    required String label,
    required String sublabel,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: _downloading ? null : onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: color.withValues(alpha: _downloading ? 0.04 : 0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withValues(alpha: _downloading ? 0.15 : 0.3)),
        ),
        child: Row(
          children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: TextStyle(color: Colors.white, fontFamily: "Rajdhani", fontWeight: FontWeight.bold, fontSize: 13)),
                  Text(sublabel, style: TextStyle(color: Colors.white.withOpacity(0.4), fontFamily: "Rajdhani", fontSize: 11)),
                ],
              ),
            ),
            _downloading
              ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: color, strokeWidth: 2))
              : Icon(Icons.download_rounded, color: color, size: 20),
          ],
        ),
      ),
    );
  }
}
