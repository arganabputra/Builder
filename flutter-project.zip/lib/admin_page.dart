import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

class AdminPage extends StatefulWidget {
  final String sessionKey;
  const AdminPage({super.key, required this.sessionKey});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> with TickerProviderStateMixin {
  // ── Theme (samain gaya Dominus — dark premium minimalist) ──
  static const Color _red = Color(0xFFFF1744);
  static const Color _bg = Color(0xFF04070D);
  static const Color _card = Color(0xFF0A0F1A);

  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  final List<String> roleOptions = [
    'member', 'vip', 'reseller', 'reseller1',
    'owner', 'partner', 'staff', 'high admin', 'dev',
  ];
  String selectedRole = 'all';
  bool isLoading = false;
  bool _filterExpanded = false;
  late AnimationController _filterCtrl;
  late List<AnimationController> _chipCtrls;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _filterCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 250));
    final chips = ['all', ...roleOptions];
    _chipCtrls = List.generate(chips.length, (i) =>
      AnimationController(vsync: this, duration: const Duration(milliseconds: 120)));
    _fetchUsers();
  }

  @override
  void dispose() {
    _filterCtrl.dispose();
    for (final c in _chipCtrls) c.dispose();
    super.dispose();
  }

  void _toggleFilter() {
    if (_filterExpanded) {
      for (int i = _chipCtrls.length - 1; i >= 0; i--) {
        Future.delayed(Duration(milliseconds: ((_chipCtrls.length - 1 - i) * 30)), () {
          if (mounted) _chipCtrls[i].reverse();
        });
      }
      Future.delayed(Duration(milliseconds: _chipCtrls.length * 30 + 80), () {
        if (mounted) _filterCtrl.reverse();
      });
    } else {
      _filterCtrl.forward();
      for (int i = 0; i < _chipCtrls.length; i++) {
        Future.delayed(Duration(milliseconds: i * 35), () {
          if (mounted) _chipCtrls[i].forward();
        });
      }
    }
    setState(() => _filterExpanded = !_filterExpanded);
  }

  // ══════════════════════════════════════════════════════════
  //  API LOGIC
  // ══════════════════════════════════════════════════════════

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/user/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _applyFilter();
      } else {
        _snack(data['message'] ?? 'Tidak diizinkan melihat daftar user.', isError: true);
      }
    } catch (_) {
      _snack("Gagal memuat user list.", isError: true);
    }
    if (mounted) setState(() => isLoading = false);
  }

  void _applyFilter() {
    setState(() {
      filteredList = selectedRole == 'all'
          ? List.from(fullUserList)
          : fullUserList.where((u) => (u['role'] ?? '').toString().toLowerCase() == selectedRole).toList();
    });
  }

  Future<void> _deleteUser(String username) async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/user/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _snack("User '${data['user']['username']}' berhasil dihapus.");
        _fetchUsers();
      } else {
        _snack(data['message'] ?? 'Gagal menghapus user.', isError: true);
        setState(() => isLoading = false);
      }
    } catch (_) {
      _snack("Tidak dapat menghubungi server.", isError: true);
      setState(() => isLoading = false);
    }
  }

  void _snack(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(fontFamily: "Rajdhani", fontWeight: FontWeight.w600)),
        backgroundColor: isError ? const Color(0xFFB91C1C) : _red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(14),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  //  ROLE STYLE HELPERS
  // ══════════════════════════════════════════════════════════

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'member': return const Color(0xFF60A5FA);
      case 'vip': return const Color(0xFFFBBF24);
      case 'reseller': return const Color(0xFF38BDF8);
      case 'reseller1': return const Color(0xFF22D3EE);
      case 'owner': return const Color(0xFFA78BFA);
      case 'partner': return const Color(0xFFEC4899);
      case 'staff': return const Color(0xFF34D399);
      case 'high admin': return const Color(0xFFF87171);
      case 'dev': return _red;
      default: return Colors.white54;
    }
  }

  // status expired: -1 = permanent, 0..3 = mepet, else aman
  Map<String, dynamic> _expiredInfo(dynamic expiredDate) {
    final raw = (expiredDate ?? '').toString();
    if (raw.isEmpty || raw.toLowerCase() == 'permanent') {
      return {'label': 'PERMANENT', 'color': const Color(0xFF34D399)};
    }
    try {
      final d = DateTime.parse(raw);
      final diff = d.difference(DateTime.now()).inDays;
      if (diff < 0) return {'label': 'EXPIRED', 'color': const Color(0xFFF87171)};
      if (diff <= 3) return {'label': '$diff hari lagi', 'color': const Color(0xFFFBBF24)};
      return {'label': raw, 'color': Colors.white54};
    } catch (_) {
      return {'label': raw, 'color': Colors.white54};
    }
  }

  // ══════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Column(children: [
          _buildHeader(),
          _buildFilterChips(),
          Expanded(
            child: isLoading && fullUserList.isEmpty
                ? const Center(child: CircularProgressIndicator(color: _red))
                : RefreshIndicator(
                    color: _red,
                    backgroundColor: _card,
                    onRefresh: _fetchUsers,
                    child: _buildUserList(),
                  ),
          ),
        ]),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openCreateUserSheet,
        backgroundColor: _red,
        icon: const Icon(Icons.person_add_alt_1_rounded, color: Colors.white),
        label: const Text('Create User', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, color: Colors.white)),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _red.withOpacity(0.12),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _red.withOpacity(0.3)),
          ),
          child: const Icon(Icons.admin_panel_settings_rounded, color: _red, size: 22),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Admin Panel', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 0.5)),
            Text('${fullUserList.length} total user', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
          ]),
        ),
        IconButton(
          onPressed: isLoading ? null : _fetchUsers,
          icon: const Icon(Icons.refresh_rounded, color: Colors.white54),
        ),
        IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.close_rounded, color: Colors.white38),
        ),
      ]),
    );
  }

  Widget _buildFilterChips() {
    final chips = ['all', ...roleOptions];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Toggle button
      GestureDetector(
        onTap: _toggleFilter,
        child: Container(
          margin: const EdgeInsets.fromLTRB(20, 4, 20, 0),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _filterExpanded ? _red.withOpacity(0.4) : Colors.white.withOpacity(0.07)),
          ),
          child: Row(children: [
            Icon(Icons.filter_list_rounded, color: _filterExpanded ? _red : Colors.white54, size: 16),
            const SizedBox(width: 8),
            Text(
              selectedRole == 'all' ? 'SEMUA ROLE' : selectedRole.toUpperCase(),
              style: TextStyle(
                color: _filterExpanded ? _red : Colors.white70,
                fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 0.8,
              ),
            ),
            const Spacer(),
            AnimatedRotation(
              turns: _filterExpanded ? 0.5 : 0,
              duration: const Duration(milliseconds: 200),
              child: Icon(Icons.keyboard_arrow_down_rounded, color: _filterExpanded ? _red : Colors.white38, size: 18),
            ),
          ]),
        ),
      ),

      // Dropdown filter chips
      SizeTransition(
        sizeFactor: CurvedAnimation(parent: _filterCtrl, curve: Curves.easeOut),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
          child: Wrap(spacing: 8, runSpacing: 8, children: List.generate(chips.length, (i) {
            final role = chips[i];
            final isSelected = selectedRole == role;
            final color = role == 'all' ? _red : _roleColor(role);
            return ScaleTransition(
              scale: CurvedAnimation(parent: _chipCtrls[i], curve: Curves.easeOutBack),
              child: GestureDetector(
                onTap: () {
                  setState(() => selectedRole = role);
                  _applyFilter();
                  _toggleFilter();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: isSelected ? color.withOpacity(0.15) : _card,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: isSelected ? color.withOpacity(0.6) : Colors.white.withOpacity(0.08)),
                  ),
                  child: Text(
                    role.toUpperCase(),
                    style: TextStyle(
                      color: isSelected ? color : Colors.white54,
                      fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 11, letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            );
          })),
        ),
      ),
    ]);
  }

  Widget _buildUserList() {
    if (filteredList.isEmpty) {
      return ListView(children: [
        SizedBox(height: MediaQuery.of(context).size.height * 0.25),
        Icon(Icons.person_off_rounded, color: Colors.white.withOpacity(0.15), size: 56),
        const SizedBox(height: 12),
        Center(child: Text('Tidak ada user untuk filter ini', style: TextStyle(color: Colors.white.withOpacity(0.3), fontFamily: 'Rajdhani'))),
      ]);
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
      itemCount: filteredList.length,
      itemBuilder: (_, i) {
        final user = filteredList[i];
        final role = (user['role'] ?? 'member').toString();
        final rc = _roleColor(role);
        final exp = _expiredInfo(user['expiredDate']);
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withOpacity(0.06)),
          ),
          child: Row(children: [
            Container(
              width: 42, height: 42,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: rc.withOpacity(0.12),
                border: Border.all(color: rc.withOpacity(0.4)),
              ),
              child: Text(
                (user['username'] ?? '?').toString().substring(0, 1).toUpperCase(),
                style: TextStyle(color: rc, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(user['username'] ?? '-', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 14)),
                const SizedBox(height: 4),
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(color: rc.withOpacity(0.12), borderRadius: BorderRadius.circular(5)),
                    child: Text(role.toUpperCase(), style: TextStyle(color: rc, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 10)),
                  ),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(
                      exp['label'],
                      style: TextStyle(color: exp['color'], fontFamily: 'Rajdhani', fontWeight: FontWeight.w600, fontSize: 11),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ]),
              ]),
            ),
            IconButton(
              onPressed: () => _confirmDelete(user['username']),
              icon: const Icon(Icons.delete_outline_rounded, color: Colors.white38, size: 20),
            ),
          ]),
        );
      },
    );
  }

  void _confirmDelete(String username) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: Colors.red.withOpacity(0.3))),
        title: const Text('Hapus User?', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 16)),
        content: Text('User "$username" akan dihapus permanen.', style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani'))),
          TextButton(
            onPressed: () { Navigator.pop(context); _deleteUser(username); },
            child: const Text('Hapus', style: TextStyle(color: Color(0xFFF87171), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  //  CREATE USER (via STORAN / QRIS)
  // ══════════════════════════════════════════════════════════

  void _openCreateUserSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _CreateUserSheet(
        sessionKey: sessionKey,
        roleOptions: roleOptions,
        roleColor: _roleColor,
        onCreated: _fetchUsers,
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════
//  CREATE USER BOTTOM SHEET — pilih role + durasi → bayar QRIS
// ══════════════════════════════════════════════════════════

class _CreateUserSheet extends StatefulWidget {
  final String sessionKey;
  final List<String> roleOptions;
  final Color Function(String) roleColor;
  final VoidCallback onCreated;

  const _CreateUserSheet({
    required this.sessionKey,
    required this.roleOptions,
    required this.roleColor,
    required this.onCreated,
  });

  @override
  State<_CreateUserSheet> createState() => _CreateUserSheetState();
}

class _CreateUserSheetState extends State<_CreateUserSheet> {
  static const Color _red = Color(0xFFFF1744);
  static const Color _card = Color(0xFF0A0F1A);

  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  String _role = 'member';
  String _duration = 'monthly'; // 'monthly' | 'permanent'
  bool _loading = false;

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final username = _usernameCtrl.text.trim();
    final password = _passwordCtrl.text.trim();
    if (username.isEmpty || password.isEmpty) {
      _snack('Username & password wajib diisi.', isError: true);
      return;
    }

    setState(() => _loading = true);
    try {
      final url = Uri.parse(
        '${AppConfig.baseUrl}/api/user/createUserStoran'
        '?key=${widget.sessionKey}&username=$username&password=$password&role=$_role&durationType=$_duration',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['valid'] != true || data['authorized'] != true) {
        _snack(data['message'] ?? 'Gagal membuat invoice.', isError: true);
        setState(() => _loading = false);
        return;
      }

      // Role gratis (dev) — langsung jadi tanpa QRIS
      if (data['created'] == true) {
        _snack("User '$username' berhasil dibuat.");
        widget.onCreated();
        if (mounted) Navigator.pop(context);
        return;
      }

      if (data['awaitingPayment'] == true) {
        if (mounted) {
          Navigator.pop(context); // tutup sheet create, buka sheet QRIS
          showModalBottomSheet(
            context: context,
            backgroundColor: Colors.transparent,
            isScrollControlled: true,
            isDismissible: false,
            enableDrag: false,
            builder: (_) => _StoranQrisSheet(
              sessionKey: widget.sessionKey,
              externalId: data['externalId'],
              amount: data['amount'],
              total: data['total'],
              qrisImageUrl: data['qrisImageUrl'],
              username: username,
              onCreated: widget.onCreated,
            ),
          );
        }
        return;
      }

      _snack(data['message'] ?? 'Gagal membuat user.', isError: true);
    } catch (_) {
      _snack('Gagal menghubungi server.', isError: true);
    }
    if (mounted) setState(() => _loading = false);
  }

  void _snack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w600)),
        backgroundColor: isError ? const Color(0xFFB91C1C) : _red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(14),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
        decoration: const BoxDecoration(
          color: Color(0xFF04070D),
          borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
        ),
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 18),
            const Text('Create User', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 20)),
            const SizedBox(height: 4),
            const Text('Bayar storan sesuai role sebelum akun dibuat.', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
            const SizedBox(height: 20),
            _field('Username', _usernameCtrl),
            const SizedBox(height: 12),
            _field('Password', _passwordCtrl),
            const SizedBox(height: 16),
            const Text('ROLE', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 11, letterSpacing: 1)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8, runSpacing: 8,
              children: widget.roleOptions.map((r) {
                final sel = _role == r;
                final c = widget.roleColor(r);
                return GestureDetector(
                  onTap: () => setState(() => _role = r),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: sel ? c.withOpacity(0.15) : _card,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: sel ? c.withOpacity(0.6) : Colors.white.withOpacity(0.08)),
                    ),
                    child: Text(r.toUpperCase(), style: TextStyle(color: sel ? c : Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 11)),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            const Text('DURASI', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 11, letterSpacing: 1)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: _durationBtn('monthly', 'Monthly')),
              const SizedBox(width: 10),
              Expanded(child: _durationBtn('permanent', 'Permanent')),
            ]),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity, height: 52,
              child: ElevatedButton(
                onPressed: _loading ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _red,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: _loading
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
                    : const Text('Lanjut Bayar Storan', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _durationBtn(String value, String label) {
    final sel = _duration == value;
    return GestureDetector(
      onTap: () => setState(() => _duration = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: sel ? _red.withOpacity(0.12) : _card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: sel ? _red.withOpacity(0.5) : Colors.white.withOpacity(0.08)),
        ),
        child: Text(label, style: TextStyle(color: sel ? _red : Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 13)),
      ),
    );
  }

  Widget _field(String label, TextEditingController ctrl) {
    return TextField(
      controller: ctrl,
      style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani'),
      cursorColor: _red,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani'),
        filled: true,
        fillColor: _card,
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.white.withOpacity(0.08))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _red)),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════
//  QRIS PAYMENT SHEET — bayar storan, auto-poll status
// ══════════════════════════════════════════════════════════

class _StoranQrisSheet extends StatefulWidget {
  final String sessionKey;
  final String externalId;
  final int amount;
  final int total;
  final String qrisImageUrl;
  final String username;
  final VoidCallback onCreated;

  const _StoranQrisSheet({
    required this.sessionKey,
    required this.externalId,
    required this.amount,
    required this.total,
    required this.qrisImageUrl,
    required this.username,
    required this.onCreated,
  });

  @override
  State<_StoranQrisSheet> createState() => _StoranQrisSheetState();
}

class _StoranQrisSheetState extends State<_StoranQrisSheet> {
  static const Color _red = Color(0xFFFF1744);
  static const Color _card = Color(0xFF0A0F1A);

  Timer? _pollTimer;
  Duration _remaining = const Duration(minutes: 15);
  Timer? _countdownTimer;
  bool _checking = false;
  bool _expired = false;

  @override
  void initState() {
    super.initState();
    _pollTimer = Timer.periodic(const Duration(seconds: 4), (_) => _checkStatus());
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (_remaining.inSeconds <= 0) {
        setState(() => _expired = true);
        _pollTimer?.cancel();
        _countdownTimer?.cancel();
        return;
      }
      setState(() => _remaining -= const Duration(seconds: 1));
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _countdownTimer?.cancel();
    super.dispose();
  }

  Future<void> _checkStatus() async {
    if (_checking || _expired) return;
    _checking = true;
    try {
      final res = await http.get(Uri.parse(
        '${AppConfig.baseUrl}/api/user/checkStoranPayment?key=${widget.sessionKey}&externalId=${widget.externalId}',
      ));
      final data = jsonDecode(res.body);
      if (data['paid'] == true && data['created'] == true) {
        _pollTimer?.cancel();
        _countdownTimer?.cancel();
        widget.onCreated();
        if (mounted) {
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text("User '${widget.username}' berhasil dibuat!", style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w600)),
              backgroundColor: const Color(0xFF34D399),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              margin: const EdgeInsets.all(14),
            ),
          );
        }
      }
    } catch (_) {}
    _checking = false;
  }

  String _fmtRp(int v) => 'Rp ${v.toString().replaceAllMapped(RegExp(r"(\d)(?=(\d{3})+(?!\d))"), (m) => "${m[1]}.")}';

  String _fmtTime(Duration d) {
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 28),
      decoration: const BoxDecoration(
        color: Color(0xFF04070D),
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Bayar Storan — ${widget.username}', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 17)),
            IconButton(
              icon: const Icon(Icons.close_rounded, color: Colors.white, size: 22),
              onPressed: () => Navigator.pop(context),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (_expired) ...[
          Icon(Icons.timer_off_rounded, color: Colors.white.withOpacity(0.25), size: 56),
          const SizedBox(height: 12),
          const Text('Waktu pembayaran habis.', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani')),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity, height: 48,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(backgroundColor: _card, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              child: const Text('Tutup', style: TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700)),
            ),
          ),
        ] else ...[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: _red.withOpacity(0.2), blurRadius: 30, spreadRadius: 2)]),
            child: Image.network(widget.qrisImageUrl, width: 280, height: 280, fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => const SizedBox(width: 280, height: 280, child: Icon(Icons.qr_code_2_rounded, size: 100, color: Colors.black26)),
            ),
          ),
          const SizedBox(height: 28),
          Text(_fmtRp(widget.total), style: const TextStyle(color: _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 36, letterSpacing: 1.5)),
          const SizedBox(height: 6),
          Text('Storan role • Total dgn fee QRIS', style: TextStyle(color: Colors.white.withOpacity(0.35), fontFamily: 'Rajdhani', fontSize: 11)),
          const SizedBox(height: 30),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            decoration: BoxDecoration(color: _red.withOpacity(0.12), borderRadius: BorderRadius.circular(14), border: Border.all(color: _red.withOpacity(0.4), width: 1.5)),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.access_time_rounded, color: _red, size: 18),
              const SizedBox(width: 10),
              Text(_fmtTime(_remaining), style: const TextStyle(color: _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 0.5)),
            ]),
          ),
          const SizedBox(height: 20),
          const SizedBox(
            width: 24, height: 24,
            child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white38),
          ),
          const SizedBox(height: 12),
          Text('Menunggu pembayaran...', style: TextStyle(color: Colors.white.withOpacity(0.4), fontFamily: 'Rajdhani', fontSize: 12, letterSpacing: 0.5)),
        ],
      ]),
    );
  }
}
