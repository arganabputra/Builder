// tools_page.dart

import 'dart:ui';
import 'package:flutter/material.dart';
import 'chat_ai_page.dart';
import 'nik_check_page.dart';
import 'phone_lookup.dart'; 
import 'subdomain_finder_page.dart';
import 'anime.dart';
import 'sender_page.dart';
import 'tiktok_downloader_page.dart';
import 'nik_parse.dart';
import 'ddos_panel.dart';
import 'loader_page.dart';
import 'public_chat_page.dart';
import 'marketplace_page.dart';
import 'device_dashboard.dart';
import 'iqc_page.dart';
import 'chess_page.dart';
import 'tebak_kata_page.dart';

// Urutan tier role, dari rendah ke tinggi.
const List<String> _toolsTierOrder = ['member', 'reseller', 'vip', 'owner', 'partner', 'staff', 'kingz', 'dev'];
int _toolsTierIndex(String role) {
  final i = _toolsTierOrder.indexOf(role.toLowerCase());
  return i == -1 ? 0 : i;
}

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final String username;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.username,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _headerController;
  late AnimationController _listController;
  late Animation<double> _headerAnimation;
  late List<Animation<double>> _itemAnimations;

  // Definisi Warna Tema: BLACK & BLUE (RYU EDITION)
  static const Color primaryColor = Color(0xFFFF1744); // Material Blue

  @override
  void initState() {
    super.initState();
    
    _headerController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _listController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _headerAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _headerController, curve: Curves.easeOutBack),
    );

    _itemAnimations = List.generate(
      17, // Jumlah tools
      (index) => Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(
          parent: _listController,
          curve: Interval(
            index * 0.06,
            0.5 + (index * 0.06),
            curve: Curves.easeOutBack,
          ),
        ),
      ),
    );

    _headerController.forward();
    _listController.forward();
  }

  @override
  void dispose() {
    _headerController.dispose();
    _listController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF060607),
      body: Stack(
        children: [
          // --- Background dasar ---
          Container(color: const Color(0xFF060607)),

          // --- Glow ambient berlapis (signature premium look) ---
          Positioned(
            top: -140, left: -100,
            child: Container(
              width: 320, height: 320,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [primaryColor.withOpacity(0.22), Colors.transparent]),
              ),
            ),
          ),
          Positioned(
            bottom: -160, right: -120,
            child: Container(
              width: 380, height: 380,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [const Color(0xFFFFC107).withOpacity(0.10), Colors.transparent]),
              ),
            ),
          ),

          // --- Pola Grid (CustomPainter), halus ---
          Positioned.fill(
            child: CustomPaint(
              painter: GridPatternPainter(),
            ),
          ),

          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildNewHeader(),
                const SizedBox(height: 6),
                Expanded(child: _buildNewGridList()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- HEADER ---
  Widget _buildNewHeader() {
    final tools = _toolsList();
    final myTier = _toolsTierIndex(widget.userRole);
    final unlockedCount = tools.where((t) => myTier >= _toolsTierIndex(t['minRole'] as String)).length;

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: [primaryColor.withOpacity(0.14), const Color(0xFF0B0B0D).withOpacity(0.55)],
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
              boxShadow: [BoxShadow(color: primaryColor.withOpacity(0.15), blurRadius: 30, spreadRadius: -6)],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Container(
                    width: 46, height: 46,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [primaryColor, const Color(0xFFFF1744)]),
                      boxShadow: [BoxShadow(color: primaryColor.withOpacity(0.5), blurRadius: 16, spreadRadius: -2)],
                    ),
                    child: const Icon(Icons.auto_awesome_mosaic_rounded, color: Colors.white, size: 22),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      "TOOLS",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                        fontFamily: "Rajdhani",
                        letterSpacing: 3.0,
                        height: 1,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [const Color(0xFFFFC107).withOpacity(0.22), const Color(0xFFFFC107).withOpacity(0.06)]),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFFFC107).withOpacity(0.45)),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.workspace_premium_rounded, color: Color(0xFFFFC107), size: 12),
                      const SizedBox(width: 5),
                      Text(widget.userRole.toUpperCase(),
                        style: const TextStyle(color: Color(0xFFFFC107), fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1)),
                    ]),
                  ),
                ]),
                const SizedBox(height: 10),
                SizedBox(
                  height: 18,
                  child: MarqueeText(
                    text: "koleksi lengkap utilitas premium • siap pakai 24 jam",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.55),
                      fontSize: 12.5,
                      fontFamily: "Rajdhani",
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(children: [
                  Expanded(child: _toolsStatChip(icon: Icons.apps_rounded, label: 'TOTAL TOOLS', value: '${tools.length}', color: primaryColor)),
                  const SizedBox(width: 10),
                  Expanded(child: _toolsStatChip(icon: Icons.lock_open_rounded, label: 'TERBUKA', value: '$unlockedCount/${tools.length}', color: const Color(0xFFFFC107))),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _toolsStatChip({required IconData icon, required String label, required String value, required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.22)),
      ),
      child: Row(children: [
        Container(
          width: 34, height: 34,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withOpacity(0.14),
            border: Border.all(color: color.withOpacity(0.35)),
          ),
          child: Icon(icon, color: color, size: 16),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(value, style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 17, height: 1)),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 9, letterSpacing: 0.8)),
          ]),
        ),
      ]),
    );
  }

  List<Map<String, dynamic>> _toolsList() {
    return [
      {'icon': Icons.bug_report, 'label': 'Dominus Bug', 'minRole': 'reseller', 'category': 'Serangan', 'color': const Color(0xFFFF1744)},
      {'icon': Icons.send_rounded, 'label': 'Telegram Spam', 'minRole': 'reseller', 'category': 'Serangan', 'color': const Color(0xFFFF1744)},
      {'icon': Icons.security_rounded, 'label': 'DDoS Attack', 'minRole': 'vip', 'category': 'Serangan', 'color': const Color(0xFFFF1744)},
      {'icon': Icons.send_rounded, 'label': 'Manage Sender', 'minRole': 'member', 'category': 'Komunikasi', 'color': const Color(0xFF00B0FF)},
      {'icon': Icons.smart_toy_rounded, 'label': 'Chat AI', 'minRole': 'reseller', 'category': 'Komunikasi', 'color': const Color(0xFF00B0FF)},
      {'icon': Icons.forum_rounded, 'label': 'Chat Public', 'minRole': 'member', 'category': 'Komunikasi', 'color': const Color(0xFF00B0FF)},
      {'icon': Icons.videocam_rounded, 'label': 'TikTok DL', 'minRole': 'member', 'category': 'Media', 'color': const Color(0xFFE040FB)},
      {'icon': Icons.movie_creation_outlined, 'label': 'Anime', 'minRole': 'member', 'category': 'Media', 'color': const Color(0xFFE040FB)},
      {'icon': Icons.badge_outlined, 'label': 'NIK Check', 'minRole': 'vip', 'category': 'Data', 'color': const Color(0xFF00E676)},
      {'icon': Icons.badge, 'label': 'NIK Parse', 'minRole': 'vip', 'category': 'Data', 'color': const Color(0xFF00E676)},
      {'icon': Icons.phone_android_rounded, 'label': 'Phone Lookup', 'minRole': 'vip', 'category': 'Data', 'color': const Color(0xFF00E676)},
      {'icon': Icons.dns_outlined, 'label': 'Subdomain', 'minRole': 'reseller', 'category': 'Jaringan', 'color': const Color(0xFFFFAB00)},
      {'icon': Icons.smartphone_rounded, 'label': 'RAT Dashboard', 'minRole': 'owner', 'category': 'Jaringan', 'color': const Color(0xFFFFAB00)},
      {'icon': Icons.quiz_rounded, 'label': 'IQC Challenge', 'minRole': 'member', 'category': 'Lainnya', 'color': const Color(0xFF7C4DFF)},
      {'icon': Icons.storefront_rounded, 'label': 'Marketplace', 'minRole': 'member', 'category': 'Lainnya', 'color': const Color(0xFF7C4DFF)},
      {'icon': Icons.extension_rounded, 'label': 'Catur', 'minRole': 'member', 'category': 'Game', 'color': const Color(0xFFFFD54F)},
      {'icon': Icons.abc_rounded, 'label': 'Tebak Kata', 'minRole': 'member', 'category': 'Game', 'color': const Color(0xFFBA68C8)},
    ];
  }

  // --- GRID LIST ---
  Widget _buildNewGridList() {
    final newTools = _toolsList();
    final myTier = _toolsTierIndex(widget.userRole);

    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.74,
      ),
      itemCount: newTools.length,
      itemBuilder: (context, index) {
        final tool = newTools[index];
        final locked = myTier < _toolsTierIndex(tool['minRole'] as String);
        final animation = index < _itemAnimations.length
            ? _itemAnimations[index]
            : AlwaysStoppedAnimation(1.0);
        return _buildAnimatedToolItem(
          icon: tool['icon'] as IconData,
          label: tool['label'] as String,
          description: '',
          category: tool['category'] as String,
          accentColor: tool['color'] as Color,
          animation: animation,
          locked: locked,
          minRole: tool['minRole'] as String,
          onTap: locked
            ? () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text('Fitur ini butuh role ${(tool['minRole'] as String).toUpperCase()} ke atas',
                  style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
                backgroundColor: const Color(0xFFFFC107).withOpacity(0.95),
                behavior: SnackBarBehavior.floating,
              ))
            : () => _navigateToTool(tool['label'] as String),
        );
      },
    );
  }

  // --- NAVIGASI TOOLS ---
  void _navigateToTool(String toolName) {
    Widget page;
    switch (toolName) {
      case 'Dominus Bug':
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => Scaffold(body: Center(child: Text('Dominus Bug - Coming Soon', style: TextStyle(color: Colors.white))))));
        return;
      case 'Telegram Spam':
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => Scaffold(body: Center(child: Text('Telegram Spam - Coming Soon', style: TextStyle(color: Colors.white))))));
        return;
      case 'DDoS Attack':
        page = AttackPanel(sessionKey: widget.sessionKey, listDDoS: []);
        break;
      case 'Manage Sender':
        page = SenderPage(sessionKey: widget.sessionKey);
        break;
      case 'Chat AI':
        page = ChatAIPage(sessionKey: widget.sessionKey);
        break;
      case 'Chat Public':
        page = PublicChatPage(username: widget.username, sessionKey: widget.sessionKey);
        break;
      case 'TikTok DL':
        page = TikTokDownloaderPage(sessionKey: widget.sessionKey);
        break;
      case 'NIK Check':
        page = NIKCheckPage(sessionKey: widget.sessionKey);
        break;
      case 'Phone Lookup':
        page = PhoneLookupPage(sessionKey: widget.sessionKey);
        break;
      case 'Subdomain':
        page = SubdomainFinderPage(sessionKey: widget.sessionKey);
        break;
      case 'Anime':
        page = HomeAnimePage();
        break;
      case 'IQC Challenge':
        page = const IQCPage();
        break;
      case 'Marketplace':
        page = MarketplacePage(sessionKey: widget.sessionKey, username: widget.username);
        break;
      case 'RAT Dashboard':
        page = DeviceDashboardPage(sessionKey: widget.sessionKey, username: widget.username);
        break;
      case 'NIK Parse':
        page = NikParsePage();
        break;
      case 'Catur':
        page = ChessPage(username: widget.username);
        break;
      case 'Tebak Kata':
        page = TebakKataPage(username: widget.username);
        break;
      default:
        return;
    }

    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => page,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(1.0, 0.0);
          const end = Offset.zero;
          const curve = Curves.easeInOut;
          var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
          return SlideTransition(position: animation.drive(tween), child: child);
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  Widget _buildAnimatedToolItem({
    required IconData icon,
    required String label,
    required String description,
    required Animation<double> animation,
    required VoidCallback onTap,
    bool locked = false,
    String minRole = 'member',
    String category = 'Lainnya',
    Color accentColor = primaryColor,
  }) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, (1 - animation.value) * 50),
          child: Opacity(
            opacity: animation.value,
            child: _InteractiveToolItem(
              icon: icon, label: label, description: description, onTap: onTap,
              locked: locked, minRole: minRole, category: category, accentColor: accentColor,
            ),
          ),
        );
      },
    );
  }
}

// --- MARQUEE TEXT WIDGET ---
class MarqueeText extends StatefulWidget {
  final String text;
  final TextStyle style;
  
  const MarqueeText({super.key, required this.text, required this.style});

  @override
  State<MarqueeText> createState() => _MarqueeTextState();
}

class _MarqueeTextState extends State<MarqueeText> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return ClipRect(
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              final width = MediaQuery.of(context).size.width;
              final dx = width - (_controller.value * (width + 300)); 
              return Transform.translate(
                offset: Offset(dx, 0),
                child: child,
              );
            },
            child: Text(
              widget.text,
              style: widget.style,
              maxLines: 1,
              overflow: TextOverflow.visible,
            ),
          ),
        );
      },
    );
  }
}

class _InteractiveToolItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final String description;
  final VoidCallback onTap;
  final bool locked;
  final String minRole;
  final String category;
  final Color accentColor;

  const _InteractiveToolItem({
    required this.icon,
    required this.label,
    required this.description,
    required this.onTap,
    this.locked = false,
    this.minRole = 'member',
    this.category = 'Lainnya',
    this.accentColor = const Color(0xFFFF1744),
  });

  @override
  State<_InteractiveToolItem> createState() => _InteractiveToolItemState();
}

class _InteractiveToolItemState extends State<_InteractiveToolItem> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  bool _isPressed = false;

  static const Color _lockColor = Color(0xFFFFC107);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: const Duration(milliseconds: 200), vsync: this);
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = widget.locked ? _lockColor : widget.accentColor;
    return GestureDetector(
      onTapDown: (_) {
        setState(() => _isPressed = true);
        _controller.forward();
      },
      onTapUp: (_) {
        setState(() => _isPressed = false);
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () {
        setState(() => _isPressed = false);
        _controller.reverse();
      },
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            // --- lapisan luar = "border gradient" (padding 1.3px nampilin gradient di tepi) ---
            child: Container(
              padding: const EdgeInsets.all(1.3),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(19),
                gradient: LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: widget.locked
                      ? [_lockColor.withOpacity(0.35), Colors.white.withOpacity(0.04)]
                      : [
                          widget.accentColor.withOpacity(_isPressed ? 1.0 : 0.65),
                          widget.accentColor.withOpacity(0.05),
                        ],
                ),
                boxShadow: widget.locked
                    ? []
                    : [BoxShadow(color: accent.withOpacity(_isPressed ? 0.4 : 0.16), blurRadius: 20, spreadRadius: -8, offset: const Offset(0, 8))],
              ),
              child: Container(
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [Color(0xFF121214), Color(0xFF09090A)],
                  ),
                ),
                child: Stack(children: [
                  // subtle corner shine warna aksen tool
                  Positioned(
                    top: -34, right: -34,
                    child: Container(
                      width: 90, height: 90,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [accent.withOpacity(0.16), Colors.transparent]),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          widget.locked ? 'TERKUNCI' : widget.category.toUpperCase(),
                          style: TextStyle(
                            color: accent.withOpacity(0.85),
                            fontSize: 8.5,
                            fontWeight: FontWeight.bold,
                            fontFamily: "Rajdhani",
                            letterSpacing: 1.2,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          width: 50, height: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            gradient: widget.locked
                                ? null
                                : LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [widget.accentColor, widget.accentColor.withOpacity(0.55)]),
                            color: widget.locked ? Colors.white.withOpacity(0.04) : null,
                            boxShadow: widget.locked ? [] : [BoxShadow(color: widget.accentColor.withOpacity(0.5), blurRadius: 14, spreadRadius: -4)],
                          ),
                          child: Icon(widget.icon, color: widget.locked ? Colors.white30 : Colors.white, size: 22),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          widget.label,
                          style: TextStyle(
                            color: widget.locked ? Colors.white54 : Colors.white,
                            fontSize: 12.5,
                            fontWeight: FontWeight.bold,
                            fontFamily: "Rajdhani",
                            letterSpacing: 0.3,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  if (widget.locked)
                    Positioned.fill(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter, end: Alignment.bottomCenter,
                                colors: [Colors.black.withOpacity(0.35), Colors.black.withOpacity(0.74)],
                              ),
                            ),
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Container(
                                width: 30, height: 30,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _lockColor.withOpacity(0.14),
                                  border: Border.all(color: _lockColor.withOpacity(0.5)),
                                ),
                                child: const Icon(Icons.lock_rounded, color: _lockColor, size: 15),
                              ),
                              const SizedBox(height: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                decoration: BoxDecoration(
                                  color: _lockColor.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: _lockColor.withOpacity(0.4)),
                                ),
                                child: Text('${widget.minRole.toUpperCase()}+',
                                  style: const TextStyle(color: _lockColor, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 9)),
                              ),
                            ]),
                          ),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }
}

// --- PAINTER UNTUK GRID ---
class GridPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFFF1744).withValues(alpha: 0.2) // Dibuat halus
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.5;
    const gridSize = 30.0;
    for (double x = 0; x < size.width; x += gridSize) canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y < size.height; y += gridSize) canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
