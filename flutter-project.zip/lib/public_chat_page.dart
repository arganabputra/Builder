// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'config.dart';
import 'story_page.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io';

// ─── Config ───────────────────────────────────────────────────

// ─── Colors ───────────────────────────────────────────────────
class _C {
  static const bg      = Color(0xFF080D14);
  static const card    = Color(0xFF0D1520);
  static const border  = Color(0xFF1A2840);
  static const cyan    = Color(0xFFFF1744);   // warna utama (merah)
  static const cyanD   = Color(0xFF7F0000);   // merah tua (konsisten)
  static const green   = Color(0xFF10B981);
  static const red     = Color(0xFFEF4444);
  static const textSec = Color(0xFF6B7280);
}

// ═══════════════════════════════════════════════════════════════
//  DOMINUS CHAT HOME — 1 halaman, scroll ke bawah
//  ┌─────────────────────────────┐
//  │  Header: Dominus Chat + 🔍  │
//  ├─────────────────────────────┤
//  │  🌐 Public Chat (tap masuk) │
//  │  👥 Grup Dominus (tap masuk)│
//  ├─────────────────────────────┤
//  │  Pesan Pribadi              │
//  │  [list DM percakapan]       │
//  └─────────────────────────────┘
// ═══════════════════════════════════════════════════════════════
class PublicChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  const PublicChatPage({super.key, required this.username, this.sessionKey = ''});

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  int _unreadPrivate = 0;
  Timer? _unreadTimer;
  List<Map<String, dynamic>> _dmList = [];
  bool _dmLoading = true;
  List<Map<String, dynamic>> _storyUsers = [];

  @override
  void initState() {
    super.initState();
    _fetchUnread();
    _fetchDmList();
    _fetchStoryUsers();
    _unreadTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _fetchUnread();
      _fetchDmList();
      _fetchStoryUsers();
    });
  }

  @override
  void dispose() {
    _unreadTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchUnread() async {
    try {
      final r = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/chat/private/unread'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.username}),
      ).timeout(const Duration(seconds: 6));
      final d = jsonDecode(r.body);
      if (d['success'] == true && mounted) {
        setState(() => _unreadPrivate = d['total'] ?? 0);
      }
    } catch (_) {}
  }

  Future<void> _fetchDmList() async {
    try {
      final r = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/chat/private/list'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.username}),
      ).timeout(const Duration(seconds: 8));
      final d = jsonDecode(r.body);
      if (d['success'] == true && mounted) {
        setState(() {
          _dmList = List<Map<String, dynamic>>.from(d['users'] ?? []);
          _dmLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _dmLoading = false);
    }
  }

  Future<void> _fetchStoryUsers() async {
    if (widget.sessionKey.isEmpty) return;
    try {
      final res = await http.get(
        Uri.parse('${AppConfig.baseUrl}/api/story/all?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 8));
      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        setState(() => _storyUsers = List<Map<String, dynamic>>.from(data['users']));
      }
    } catch (_) {}
  }

  Widget _buildStoryBar() {
    final hasStory = _storyUsers.isNotEmpty;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
        child: Row(children: [
          Text('Story', style: TextStyle(
            color: Colors.white.withOpacity(0.45),
            fontFamily: 'Rajdhani', fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1.5,
          )),
          const Spacer(),
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => StoryPage(username: widget.username, sessionKey: widget.sessionKey)),
            ).then((_) => _fetchStoryUsers()),
            child: Text('Lihat Semua', style: TextStyle(color: _C.red, fontFamily: 'Rajdhani', fontSize: 12, fontWeight: FontWeight.bold)),
          ),
        ]),
      ),
      SizedBox(
        height: 90,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          itemCount: hasStory ? _storyUsers.length + 1 : 1,
          itemBuilder: (ctx, i) {
            // Tombol tambah story
            if (i == 0) {
              return GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => StoryPage(username: widget.username, sessionKey: widget.sessionKey)),
                ).then((_) => _fetchStoryUsers()),
                child: Container(
                  width: 62, margin: const EdgeInsets.symmetric(horizontal: 5),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Container(
                      width: 56, height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: _C.border, width: 2),
                        color: _C.card,
                      ),
                      child: const Icon(Icons.add, color: _C.red, size: 26),
                    ),
                    const SizedBox(height: 5),
                    Text('Kamu', style: TextStyle(color: Colors.white.withOpacity(0.5), fontFamily: 'Rajdhani', fontSize: 10), overflow: TextOverflow.ellipsis),
                  ]),
                ),
              );
            }
            final user = _storyUsers[i - 1];
            final hasUnread = user['hasUnread'] as bool? ?? false;
            final uname = user['username'] as String;
            final userIdx = _storyUsers.indexWhere((u) => u['username'] == uname);
            return GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => StoryViewerPage(
                  users: _storyUsers,
                  initialUserIndex: userIdx,
                  username: widget.username,
                  sessionKey: widget.sessionKey,
                  onViewed: _fetchStoryUsers,
                )),
              ).then((_) => _fetchStoryUsers()),
              child: Container(
                width: 62, margin: const EdgeInsets.symmetric(horizontal: 5),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    width: 58, height: 58,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: hasUnread
                          ? const LinearGradient(
                              colors: [Color(0xFFFF1744), Color(0xFFFF6B35), Color(0xFFFF1744)],
                              begin: Alignment.topLeft, end: Alignment.bottomRight)
                          : LinearGradient(colors: [_C.textSec.withValues(alpha: 0.4), _C.textSec.withValues(alpha: 0.2)]),
                      boxShadow: hasUnread ? [BoxShadow(color: _C.red.withValues(alpha: 0.4), blurRadius: 10)] : null,
                    ),
                    padding: const EdgeInsets.all(2.5),
                    child: CircleAvatar(
                      backgroundColor: _C.card,
                      child: Text(
                        uname.isNotEmpty ? uname[0].toUpperCase() : '?',
                        style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(uname, style: TextStyle(
                    color: hasUnread ? Colors.white : Colors.white.withOpacity(0.5),
                    fontFamily: 'Rajdhani', fontSize: 10, fontWeight: hasUnread ? FontWeight.bold : FontWeight.normal,
                  ), overflow: TextOverflow.ellipsis),
                ]),
              ),
            );
          },
        ),
      ),
      Container(height: 1, margin: const EdgeInsets.only(top: 6), color: _C.border.withValues(alpha: 0.5)),
    ]);
  }

  void _openSearch() {
    final ctrl = TextEditingController();
    showDialog(context: context, builder: (_) => Dialog(
      backgroundColor: _C.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: _C.border),
      ),
      child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(children: [
          Container(width: 30, height: 30,
            decoration: BoxDecoration(color: _C.red.withValues(alpha: 0.12), shape: BoxShape.circle),
            child: const Icon(Icons.person_search_rounded, color: _C.red, size: 15)),
          const SizedBox(width: 10),
          const Text('Cari Username', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 16)),
        ]),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(color: _C.bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)),
          child: TextField(
            controller: ctrl, autofocus: true,
            style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani'),
            decoration: const InputDecoration(
              hintText: 'Masukkan username...',
              hintStyle: TextStyle(color: _C.textSec, fontFamily: 'Rajdhani'),
              prefixIcon: Icon(Icons.alternate_email_rounded, color: _C.red, size: 17),
              border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(padding: const EdgeInsets.symmetric(vertical: 11),
              decoration: BoxDecoration(color: _C.bg, borderRadius: BorderRadius.circular(10), border: Border.all(color: _C.border)),
              child: const Center(child: Text('Batal', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)))),
          )),
          const SizedBox(width: 10),
          Expanded(child: GestureDetector(
            onTap: () {
              final u = ctrl.text.trim();
              if (u.isEmpty || u == widget.username) return;
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) =>
                PrivateChatRoomPage(myUsername: widget.username, toUsername: u),
              )).then((_) { _fetchDmList(); _fetchUnread(); });
            },
            child: Container(padding: const EdgeInsets.symmetric(vertical: 11),
              decoration: BoxDecoration(gradient: const LinearGradient(colors: [_C.red, _C.cyanD]), borderRadius: BorderRadius.circular(10)),
              child: const Center(child: Text('Chat', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)))),
          )),
        ]),
      ])),
    ));
  }

  @override
  Widget _glassCard({required Widget child, required Color accent, EdgeInsetsGeometry? padding}) {
    return Container(
      padding: padding ?? const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Colors.white.withOpacity(0.05), Colors.white.withOpacity(0.015)],
        ),
        border: Border.all(color: accent.withOpacity(0.28)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 10)),
          BoxShadow(color: accent.withOpacity(0.06), blurRadius: 24, spreadRadius: 1),
        ],
      ),
      child: child,
    );
  }

  Widget _sectionLabel(String text) {
    return Row(children: [
      Container(width: 3, height: 14, decoration: BoxDecoration(color: _C.red, borderRadius: BorderRadius.circular(2))),
      const SizedBox(width: 8),
      Text(text, style: TextStyle(
        color: Colors.white.withOpacity(0.55),
        fontFamily: 'Rajdhani', fontSize: 12,
        fontWeight: FontWeight.bold, letterSpacing: 1.5,
      )),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.red, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(children: [
          Container(
            width: 32, height: 32,
            decoration: BoxDecoration(
              color: _C.red.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: _C.red.withValues(alpha: 0.3)),
            ),
            child: const Icon(Icons.forum_rounded, color: _C.red, size: 16),
          ),
          const SizedBox(width: 10),
          const Text('Dominus Chat', style: TextStyle(
            color: Colors.white, fontFamily: 'Rajdhani',
            fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 1,
          )),
        ]),
        actions: [
          // Tombol cari user untuk DM
          GestureDetector(
            onTap: _openSearch,
            child: Container(
              margin: const EdgeInsets.only(right: 16),
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: _C.red.withValues(alpha: 0.12),
                shape: BoxShape.circle,
                border: Border.all(color: _C.red.withValues(alpha: 0.3)),
              ),
              child: const Icon(Icons.person_search_rounded, color: _C.red, size: 18),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _C.border),
        ),
      ),
      body: Stack(children: [
        // ── Ambient glow ───────────────────────────────────────
        Positioned(
          top: -220, left: 0, right: 0,
          child: IgnorePointer(
            child: Center(
              child: Container(
                width: 560, height: 560,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [_C.red.withOpacity(0.16), _C.red.withOpacity(0.03), Colors.transparent],
                    stops: const [0.0, 0.45, 0.7],
                  ),
                ),
              ),
            ),
          ),
        ),
        ListView(
        padding: EdgeInsets.zero,
        children: [
          // ── Story Bar ─────────────────────────────────────────
          if (widget.sessionKey.isNotEmpty) _buildStoryBar(),

          // ── Section: Chat Bersama ─────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: _sectionLabel('CHAT BERSAMA'),
          ),

          // ── Kartu: Public Chat ────────────────────────────────
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => _PublicChatScreen(username: widget.username),
            )),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: _glassCard(
                accent: _C.red,
                child: Row(children: [
                  Container(
                    width: 46, height: 46,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [_C.red.withValues(alpha: 0.35), _C.cyanD.withValues(alpha: 0.25)]),
                      border: Border.all(color: _C.red.withValues(alpha: 0.45), width: 1.5),
                      boxShadow: [BoxShadow(color: _C.red.withOpacity(0.25), blurRadius: 12)],
                    ),
                    child: const Icon(Icons.public_rounded, color: Colors.white, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Public Chat', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
                    const SizedBox(height: 2),
                    Text('Semua user bisa baca & kirim', style: TextStyle(color: Colors.white.withOpacity(0.45), fontFamily: 'Rajdhani', fontSize: 12)),
                  ])),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: _C.red.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(8), border: Border.all(color: _C.red.withValues(alpha: 0.3))),
                    child: const Text('OPEN', style: TextStyle(color: _C.red, fontFamily: 'Rajdhani', fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  ),
                  const SizedBox(width: 8),
                  const Icon(Icons.chevron_right_rounded, color: _C.textSec, size: 20),
                ]),
              ),
            ),
          ),

          // ── Kartu: Grup Dominus (auto join) ───────────────────
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => _GroupChatScreen(username: widget.username),
            )),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
              child: _glassCard(
                accent: const Color(0xFF8B5CF6),
                child: Row(children: [
                Container(
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [const Color(0xFF8B5CF6).withValues(alpha: 0.35), const Color(0xFF6D28D9).withValues(alpha: 0.25)]),
                    border: Border.all(color: const Color(0xFF8B5CF6).withValues(alpha: 0.45), width: 1.5),
                    boxShadow: [BoxShadow(color: const Color(0xFF8B5CF6).withOpacity(0.25), blurRadius: 12)],
                  ),
                  child: const Icon(Icons.workspace_premium_rounded, color: Colors.white, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Dominus Global', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text('Grup resmi • Semua member otomatis masuk', style: TextStyle(color: Colors.white.withOpacity(0.45), fontFamily: 'Rajdhani', fontSize: 12)),
                ])),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: const Color(0xFF8B5CF6).withValues(alpha: 0.12), borderRadius: BorderRadius.circular(8), border: Border.all(color: const Color(0xFF8B5CF6).withValues(alpha: 0.3))),
                  child: const Text('GRUP', style: TextStyle(color: Color(0xFF8B5CF6), fontFamily: 'Rajdhani', fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
                ),
                const SizedBox(width: 8),
                const Icon(Icons.chevron_right_rounded, color: _C.textSec, size: 20),
                ]),
              ),
            ),
          ),

          // ── Section: Pesan Pribadi ────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 22, 16, 10),
            child: Row(children: [
              _sectionLabel('PESAN PRIBADI'),
              const Spacer(),
              if (_unreadPrivate > 0)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: _C.red, borderRadius: BorderRadius.circular(10)),
                  child: Text('$_unreadPrivate belum dibaca',
                    style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 10, fontWeight: FontWeight.bold)),
                ),
            ]),
          ),

          // ── DM List ───────────────────────────────────────────
          if (_dmLoading)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 30),
              child: Center(child: CircularProgressIndicator(color: _C.red, strokeWidth: 2)),
            )
          else if (_dmList.isEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 30),
              child: _glassCard(
                accent: _C.red,
                padding: const EdgeInsets.symmetric(vertical: 26),
                child: Column(children: [
                  Icon(Icons.mark_chat_read_outlined, color: _C.red.withValues(alpha: 0.3), size: 38),
                  const SizedBox(height: 10),
                  Text('Belum ada pesan pribadi', style: TextStyle(color: Colors.white.withOpacity(0.4), fontFamily: 'Rajdhani', fontSize: 13, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.person_search_rounded, color: Colors.white.withOpacity(0.25), size: 13),
                    const SizedBox(width: 5),
                    Text('Tap ikon cari di atas buat mulai chat', style: TextStyle(color: Colors.white.withOpacity(0.25), fontFamily: 'Rajdhani', fontSize: 11)),
                  ]),
                ]),
              ),
            )
          else
            ...List.generate(_dmList.length, (i) {
              final u     = _dmList[i];
              final unread = u['unread'] ?? 0;
              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => PrivateChatRoomPage(myUsername: widget.username, toUsername: u['otherUser']),
                )).then((_) { _fetchDmList(); _fetchUnread(); }),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                  child: _glassCard(
                    accent: unread > 0 ? _C.red : Colors.white,
                    padding: const EdgeInsets.all(13),
                    child: Row(children: [
                    Stack(clipBehavior: Clip.none, children: [
                      Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(colors: [_C.red.withValues(alpha: 0.3), _C.cyanD.withValues(alpha: 0.2)]),
                          border: Border.all(color: _C.red.withValues(alpha: 0.35), width: 1.5),
                        ),
                        child: Center(child: Text(
                          u['otherUser'].toString().isNotEmpty ? u['otherUser'].toString()[0].toUpperCase() : '?',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17, fontFamily: 'Rajdhani'),
                        )),
                      ),
                      if (unread > 0)
                        Positioned(top: -3, right: -3,
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: const BoxDecoration(color: _C.red, shape: BoxShape.circle),
                            child: Text(unread > 9 ? '9+' : '$unread',
                              style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold)),
                          )),
                    ]),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Text(u['otherUser'] ?? '', style: TextStyle(
                          color: Colors.white, fontFamily: 'Rajdhani',
                          fontWeight: unread > 0 ? FontWeight.w900 : FontWeight.bold, fontSize: 14)),
                        Text(u['lastTime'] ?? '', style: TextStyle(
                          color: unread > 0 ? _C.red : _C.textSec,
                          fontFamily: 'Rajdhani', fontSize: 11,
                          fontWeight: unread > 0 ? FontWeight.bold : FontWeight.normal)),
                      ]),
                      const SizedBox(height: 2),
                      Text(u['lastMessage'] ?? 'Tap untuk chat',
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: unread > 0 ? Colors.white70 : Colors.white38,
                          fontFamily: 'Rajdhani', fontSize: 12,
                          fontWeight: unread > 0 ? FontWeight.bold : FontWeight.normal)),
                    ])),
                    ]),
                  ),
                ),
              );
            }),

          const SizedBox(height: 20),
        ],
        ),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  PUBLIC TAB
// ═══════════════════════════════════════════════════════════════
class _PublicChatScreen extends StatefulWidget {
  final String username;
  const _PublicChatScreen({super.key, required this.username});

  @override
  State<_PublicChatScreen> createState() => _PublicChatScreenState();
}

class _PublicChatScreenState extends State<_PublicChatScreen> {
  final _ctrl   = TextEditingController();
  final _scroll = ScrollController();
  List<Map<String, dynamic>> _msgs = [];
  Timer? _timer;
  Timer? _onlineTimer;
  bool _sending  = false;
  bool _loading  = true;
  // Reply state
  Map<String, dynamic>? _replyTo;
  // Voice
  bool _isRecording = false;
  int  _recSeconds  = 0;
  Timer? _recTimer;
  final _recorder = FlutterSoundRecorder();
  String? _recPath;

  @override
  void initState() {
    super.initState();
    _fetch();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _fetch());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _onlineTimer?.cancel();
    _recTimer?.cancel();
    if (_recorder.isRecording) _recorder.closeRecorder();
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _fetch() async {
    try {
      final r = await http.post(
        Uri.parse('${AppConfig.baseUrl}/get-public-chat'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 8));
      final d = jsonDecode(r.body);
      if ((d['success'] == true || d is List) && mounted) {
        final List raw = d is List ? d : (d['messages'] ?? []);
        setState(() { _msgs = raw.cast<Map<String, dynamic>>(); _loading = false; });
        _scrollBot();
      }
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _send({
    String? msg,
    String? mediaBase64,
    String? mediaType,
    Map? location,
    String? voiceBase64,
    int? voiceDuration,
  }) async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      await http.post(
        Uri.parse('${AppConfig.baseUrl}/send-public-chat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'message': msg ?? '',
          if (mediaBase64 != null) 'mediaBase64': mediaBase64,
          if (mediaType  != null) 'mediaType': mediaType,
          if (location   != null) 'location': location,
          if (voiceBase64 != null) 'voiceBase64': voiceBase64,
          if (voiceDuration != null) 'voiceDuration': voiceDuration,
          'type': voiceBase64 != null ? 'voice'
              : location != null ? 'location'
              : (mediaType ?? 'text'),
          if (_replyTo != null) 'replyTo': {
            'id':       _replyTo!['id'],
            'username': _replyTo!['username'],
            'message':  _replyTo!['message'] ?? '',
            'type':     _replyTo!['type'] ?? 'text',
          },
        }),
      ).timeout(const Duration(seconds: 30));
      _ctrl.clear();
      setState(() => _replyTo = null);
      await _fetch();
    } catch (_) {}
    if (mounted) setState(() => _sending = false);
  }

  Future<void> _pickMedia(String type) async {
    final picker = ImagePicker();
    XFile? file;
    if (type == 'image')  file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    else if (type == 'camera') file = await picker.pickImage(source: ImageSource.camera, imageQuality: 70);
    else if (type == 'video')  file = await picker.pickVideo(source: ImageSource.gallery);
    if (file == null) return;
    final bytes = await file.readAsBytes();
    await _send(mediaBase64: base64Encode(bytes), mediaType: type == 'video' ? 'video' : 'image');
  }

  Future<void> _sendLocation() async {
    try {
      bool svc = await Geolocator.isLocationServiceEnabled();
      if (!svc) { _snack('GPS tidak aktif'); return; }
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.deniedForever) { _snack('Izin lokasi ditolak'); return; }
      final pos = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      await _send(location: {'lat': pos.latitude, 'lng': pos.longitude});
    } catch (_) { _snack('Gagal ambil lokasi'); }
  }

  // ── Voice Record ──────────────────────────────────────────────
  Future<void> _startRecord() async {
    try {
      final status = await Permission.microphone.request();
      if (!status.isGranted) { _snack('Izin mikrofon ditolak'); return; }
      await _recorder.openRecorder();
      final dir = await getTemporaryDirectory();
      _recPath = '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.aac';
      await _recorder.startRecorder(toFile: _recPath, codec: Codec.aacADTS);
      setState(() { _isRecording = true; _recSeconds = 0; });
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _recSeconds++);
      });
    } catch (e) { _snack('Gagal rekam: $e'); }
  }

  Future<void> _stopRecord({bool cancel = false}) async {
    _recTimer?.cancel();
    try {
      final path = await _recorder.stopRecorder();
      await _recorder.closeRecorder();
      setState(() { _isRecording = false; _recSeconds = 0; });
      if (cancel || path == null) { _recPath = null; return; }
      final bytes = await File(path).readAsBytes();
      final b64   = base64Encode(bytes);
      await _send(voiceBase64: b64, voiceDuration: _recSeconds);
    } catch (_) { if (mounted) setState(() => _isRecording = false); }
  }

  void _setReply(Map<String, dynamic> msg) {
    setState(() => _replyTo = msg);
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani')),
      backgroundColor: Colors.red, behavior: SnackBarBehavior.floating));
  }

  void _scrollBot() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    });
  }

  Future<void> _deleteMsg(Map<String, dynamic> msg) async {
    try {
      await http.post(Uri.parse('${AppConfig.baseUrl}/delete-public-chat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.username, 'msgId': msg['id']}),
      ).timeout(const Duration(seconds: 8));
      _fetch();
    } catch (_) {}
  }

  void _reactMsg(Map<String, dynamic> msg, String emoji) {
    // Reaction support — extend API if needed
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Reaksi $emoji dikirim', style: const TextStyle(fontFamily: 'Rajdhani')),
      backgroundColor: _C.card, behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 1),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      // Online bar
      Container(
        margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)),
        child: Row(children: [
          Container(width: 8, height: 8, decoration: const BoxDecoration(shape: BoxShape.circle, color: _C.green)),
          const SizedBox(width: 8),
          Text('${_msgs.map((m) => m['username']).toSet().length} pengguna aktif',
            style: const TextStyle(color: _C.green, fontFamily: 'Rajdhani', fontSize: 12, fontWeight: FontWeight.bold)),
          const Spacer(),
          const Text('Auto 3s', style: TextStyle(color: _C.textSec, fontFamily: 'Rajdhani', fontSize: 10)),
        ]),
      ),
      // Messages
      Expanded(
        child: _loading
            ? const Center(child: CircularProgressIndicator(color: _C.red, strokeWidth: 2))
            : _msgs.isEmpty
                ? _emptyState('Belum ada pesan.\nJadi yang pertama! 👋')
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                    itemCount: _msgs.length,
                    itemBuilder: (_, i) => _ChatBubble(
                      msg: _msgs[i],
                      myUser: widget.username,
                      onReply: _setReply,
                      onDelete: _deleteMsg,
                      onReact: _reactMsg,
                    ),
                  ),
      ),
      // Input bar (includes reply preview + voice)
      _InputBar(
        ctrl: _ctrl,
        sending: _sending,
        replyTo: _replyTo,
        isRecording: _isRecording,
        recSeconds: _recSeconds,
        onCancelReply: () => setState(() => _replyTo = null),
        onSend: () => _send(msg: _ctrl.text.trim()),
        onMedia: _pickMedia,
        onLocation: _sendLocation,
        onStartRecord: _startRecord,
        onStopRecord: () => _stopRecord(),
        onCancelRecord: () => _stopRecord(cancel: true),
      ),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════
//  PRIVATE CHAT ROOM
// ═══════════════════════════════════════════════════════════════
class PrivateChatRoomPage extends StatefulWidget {
  final String myUsername;
  final String toUsername;
  const PrivateChatRoomPage({super.key, required this.myUsername, required this.toUsername});

  @override
  State<PrivateChatRoomPage> createState() => _PrivateChatRoomPageState();
}

class _PrivateChatRoomPageState extends State<PrivateChatRoomPage> {
  final _ctrl   = TextEditingController();
  final _scroll = ScrollController();
  List<Map<String, dynamic>> _msgs = [];
  Timer? _timer;
  Timer? _onlineTimer;
  bool _sending  = false;
  bool _loading  = true;
  bool _isOnline = false;
  Map<String, dynamic>? _replyTo;
  // Voice
  bool _isRecording = false;
  int  _recSeconds  = 0;
  Timer? _recTimer;
  final _recorder = FlutterSoundRecorder();
  String? _recPath;

  @override
  void initState() {
    super.initState();
    _fetch();
    _markRead();
    _checkOnline();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) { _fetch(); _markRead(); });
    _onlineTimer = Timer.periodic(const Duration(seconds: 5), (_) { if (mounted) _checkOnline(); });
  }

  Future<void> _checkOnline() async {
    try {
      final r = await http.get(
        Uri.parse('${AppConfig.baseUrl}/api/chat/online?username=${widget.toUsername}'),
      ).timeout(const Duration(seconds: 5));
      final d = jsonDecode(r.body);
      if (mounted) setState(() => _isOnline = d['isOnline'] == true);
    } catch (_) {}
  }

  @override
  void dispose() {
    _timer?.cancel();
    _onlineTimer?.cancel();
    _recTimer?.cancel();
    if (_recorder.isRecording) _recorder.closeRecorder();
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _fetch() async {
    try {
      final r = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/chat/private/messages'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.myUsername, 'toUser': widget.toUsername}),
      ).timeout(const Duration(seconds: 8));
      final d = jsonDecode(r.body);
      if (d['success'] == true && mounted) {
        setState(() { _msgs = List<Map<String, dynamic>>.from(d['messages']); _loading = false; });
        _scrollBot();
      }
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _markRead() async {
    try {
      await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/chat/private/read'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.myUsername, 'toUser': widget.toUsername}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  Future<void> _send({
    String? msg,
    String? mediaBase64,
    String? mediaType,
    Map? location,
    String? voiceBase64,
    int? voiceDuration,
  }) async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/chat/private/send'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.myUsername, 'toUser': widget.toUsername,
          'message': msg ?? '',
          if (mediaBase64  != null) 'mediaBase64': mediaBase64,
          if (mediaType    != null) 'mediaType': mediaType,
          if (location     != null) 'location': location,
          if (voiceBase64  != null) 'voiceBase64': voiceBase64,
          if (voiceDuration != null) 'voiceDuration': voiceDuration,
          'type': voiceBase64 != null ? 'voice'
              : location != null ? 'location'
              : (mediaType ?? 'text'),
          if (_replyTo != null) 'replyTo': {
            'id':       _replyTo!['id'],
            'username': _replyTo!['username'],
            'message':  _replyTo!['message'] ?? '',
            'type':     _replyTo!['type'] ?? 'text',
          },
        }),
      ).timeout(const Duration(seconds: 30));
      _ctrl.clear();
      setState(() => _replyTo = null);
      await _fetch();
    } catch (_) {}
    if (mounted) setState(() => _sending = false);
  }

  Future<void> _pickMedia(String type) async {
    final picker = ImagePicker();
    XFile? file;
    if (type == 'image')  file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    else if (type == 'camera') file = await picker.pickImage(source: ImageSource.camera, imageQuality: 70);
    else if (type == 'video')  file = await picker.pickVideo(source: ImageSource.gallery);
    if (file == null) return;
    final bytes = await file.readAsBytes();
    await _send(mediaBase64: base64Encode(bytes), mediaType: type == 'video' ? 'video' : 'image');
  }

  Future<void> _sendLocation() async {
    try {
      bool svc = await Geolocator.isLocationServiceEnabled();
      if (!svc) { _snack('GPS tidak aktif'); return; }
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.deniedForever) { _snack('Izin lokasi ditolak'); return; }
      final pos = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      await _send(location: {'lat': pos.latitude, 'lng': pos.longitude});
    } catch (_) { _snack('Gagal ambil lokasi'); }
  }

  Future<void> _startRecord() async {
    try {
      final status = await Permission.microphone.request();
      if (!status.isGranted) { _snack('Izin mikrofon ditolak'); return; }
      await _recorder.openRecorder();
      final dir = await getTemporaryDirectory();
      _recPath = '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.aac';
      await _recorder.startRecorder(toFile: _recPath, codec: Codec.aacADTS);
      setState(() { _isRecording = true; _recSeconds = 0; });
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _recSeconds++);
      });
    } catch (e) { _snack('Gagal rekam: $e'); }
  }

  Future<void> _stopRecord({bool cancel = false}) async {
    _recTimer?.cancel();
    try {
      final path = await _recorder.stopRecorder();
      await _recorder.closeRecorder();
      setState(() { _isRecording = false; _recSeconds = 0; });
      if (cancel || path == null) { _recPath = null; return; }
      final bytes = await File(path).readAsBytes();
      await _send(voiceBase64: base64Encode(bytes), voiceDuration: _recSeconds);
    } catch (_) { if (mounted) setState(() => _isRecording = false); }
  }

  Future<void> _deleteMsg(Map<String, dynamic> msg) async {
    try {
      await http.post(Uri.parse('${AppConfig.baseUrl}/api/chat/private/delete'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.myUsername, 'msgId': msg['id']}),
      ).timeout(const Duration(seconds: 8));
      _fetch();
    } catch (_) {}
  }

  void _reactMsg(Map<String, dynamic> msg, String emoji) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Reaksi \$emoji dikirim', style: const TextStyle(fontFamily: 'Rajdhani')),
      backgroundColor: _C.card, behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 1),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani')),
      backgroundColor: Colors.red, behavior: SnackBarBehavior.floating));
  }

  void _scrollBot() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.bg, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.red, size: 18), onPressed: () => Navigator.pop(context)),
        title: Row(children: [
          Stack(clipBehavior: Clip.none, children: [
            Container(width: 36, height: 36,
              decoration: BoxDecoration(shape: BoxShape.circle,
                gradient: LinearGradient(colors: [_C.red.withValues(alpha: 0.3), _C.cyanD.withValues(alpha: 0.2)]),
                border: Border.all(color: _C.red.withValues(alpha: 0.4))),
              child: Center(child: Text(widget.toUsername[0].toUpperCase(),
                style: const TextStyle(color: _C.red, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani', fontSize: 16)))),
            Positioned(right: 0, bottom: 0,
              child: Container(width: 10, height: 10,
                decoration: BoxDecoration(
                  color: _isOnline ? _C.green : _C.textSec,
                  shape: BoxShape.circle,
                  border: Border.all(color: _C.bg, width: 1.5)))),
          ]),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.toUsername, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
            Text(_isOnline ? 'Online' : 'Offline', style: TextStyle(color: _isOnline ? _C.green : _C.textSec, fontFamily: 'Rajdhani', fontSize: 11)),
          ]),
        ]),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: _C.border)),
      ),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator(color: _C.red, strokeWidth: 2))
              : _msgs.isEmpty
                  ? _emptyState('Kirim pesan pertama! 💬')
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                      itemCount: _msgs.length,
                      itemBuilder: (_, i) => _ChatBubble(
                        msg: _msgs[i],
                        myUser: widget.myUsername,
                        onReply: (m) => setState(() => _replyTo = m),
                        onDelete: _deleteMsg,
                        onReact: _reactMsg,
                      ),
                    ),
        ),
        _InputBar(
          ctrl: _ctrl,
          sending: _sending,
          replyTo: _replyTo,
          isRecording: _isRecording,
          recSeconds: _recSeconds,
          onCancelReply: () => setState(() => _replyTo = null),
          onSend: () => _send(msg: _ctrl.text.trim()),
          onMedia: _pickMedia,
          onLocation: _sendLocation,
          onStartRecord: _startRecord,
          onStopRecord: () => _stopRecord(),
          onCancelRecord: () => _stopRecord(cancel: true),
        ),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  GROUP CHAT SCREEN — Dominus Global (semua user otomatis masuk)
// ═══════════════════════════════════════════════════════════════
class _GroupChatScreen extends StatefulWidget {
  final String username;
  const _GroupChatScreen({required this.username});

  @override
  State<_GroupChatScreen> createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<_GroupChatScreen> {
  final _ctrl   = TextEditingController();
  final _scroll = ScrollController();
  List<Map<String, dynamic>> _msgs = [];
  Timer? _timer;
  Timer? _onlineTimer;
  bool _sending = false;
  bool _loading = true;
  Map<String, dynamic>? _replyTo;
  bool _isRecording = false;
  int  _recSeconds  = 0;
  Timer? _recTimer;
  final _recorder = FlutterSoundRecorder();

  @override
  void initState() {
    super.initState();
    _fetch();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _fetch());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _onlineTimer?.cancel();
    _recTimer?.cancel();
    if (_recorder.isRecording) _recorder.closeRecorder();
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _fetch() async {
    try {
      final r = await http.post(
        Uri.parse('${AppConfig.baseUrl}/group/messages'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.username}),
      ).timeout(const Duration(seconds: 8));
      final d = jsonDecode(r.body);
      if ((d['success'] == true) && mounted) {
        setState(() {
          _msgs = List<Map<String, dynamic>>.from(d['messages'] ?? []);
          _loading = false;
        });
        _scrollBot();
      }
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _send({String? msg, String? mediaBase64, String? mediaType,
      Map? location, String? voiceBase64, int? voiceDuration}) async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      await http.post(
        Uri.parse('${AppConfig.baseUrl}/group/send'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'message': msg ?? '',
          if (mediaBase64   != null) 'mediaBase64': mediaBase64,
          if (mediaType     != null) 'mediaType': mediaType,
          if (location      != null) 'location': location,
          if (voiceBase64   != null) 'voiceBase64': voiceBase64,
          if (voiceDuration != null) 'voiceDuration': voiceDuration,
          'type': voiceBase64 != null ? 'voice'
              : location != null ? 'location'
              : (mediaType ?? 'text'),
          if (_replyTo != null) 'replyTo': {
            'id': _replyTo!['id'], 'username': _replyTo!['username'],
            'message': _replyTo!['message'] ?? '', 'type': _replyTo!['type'] ?? 'text',
          },
        }),
      ).timeout(const Duration(seconds: 30));
      _ctrl.clear();
      setState(() => _replyTo = null);
      await _fetch();
    } catch (_) {}
    if (mounted) setState(() => _sending = false);
  }

  Future<void> _pickMedia(String type) async {
    final picker = ImagePicker();
    XFile? file;
    if (type == 'image')       file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    else if (type == 'camera') file = await picker.pickImage(source: ImageSource.camera, imageQuality: 70);
    else if (type == 'video')  file = await picker.pickVideo(source: ImageSource.gallery);
    if (file == null) return;
    final bytes = await file.readAsBytes();
    await _send(mediaBase64: base64Encode(bytes), mediaType: type == 'video' ? 'video' : 'image');
  }

  Future<void> _sendLocation() async {
    try {
      bool svc = await Geolocator.isLocationServiceEnabled();
      if (!svc) { _snack('GPS tidak aktif'); return; }
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.deniedForever) { _snack('Izin lokasi ditolak'); return; }
      final pos = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      await _send(location: {'lat': pos.latitude, 'lng': pos.longitude});
    } catch (_) { _snack('Gagal ambil lokasi'); }
  }

  Future<void> _startRecord() async {
    try {
      final status = await Permission.microphone.request();
      if (!status.isGranted) { _snack('Izin mikrofon ditolak'); return; }
      await _recorder.openRecorder();
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.aac';
      await _recorder.startRecorder(toFile: path, codec: Codec.aacADTS);
      setState(() { _isRecording = true; _recSeconds = 0; });
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _recSeconds++);
      });
    } catch (e) { _snack('Gagal rekam: $e'); }
  }

  Future<void> _stopRecord({bool cancel = false}) async {
    _recTimer?.cancel();
    try {
      final path = await _recorder.stopRecorder();
      await _recorder.closeRecorder();
      setState(() { _isRecording = false; _recSeconds = 0; });
      if (cancel || path == null) return;
      final bytes = await File(path).readAsBytes();
      await _send(voiceBase64: base64Encode(bytes), voiceDuration: _recSeconds);
    } catch (_) { if (mounted) setState(() => _isRecording = false); }
  }

  Future<void> _deleteMsg(Map<String, dynamic> msg) async {
    try {
      await http.post(Uri.parse('${AppConfig.baseUrl}/api/chat/private/delete'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.username, 'msgId': msg['id']}),
      ).timeout(const Duration(seconds: 8));
      _fetch();
    } catch (_) {}
  }

  void _reactMsg(Map<String, dynamic> msg, String emoji) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Reaksi \$emoji dikirim', style: const TextStyle(fontFamily: 'Rajdhani')),
      backgroundColor: _C.card, behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 1),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani')),
      backgroundColor: Colors.red, behavior: SnackBarBehavior.floating));
  }

  void _scrollBot() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.bg, elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.red, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(children: [
          Container(width: 36, height: 36,
            decoration: const BoxDecoration(shape: BoxShape.circle,
              gradient: LinearGradient(colors: [Color(0xFF8B5CF6), Color(0xFF6D28D9)])),
            child: const Center(child: Text('👑', style: TextStyle(fontSize: 18)))),
          const SizedBox(width: 10),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Dominus Global', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
            Text('Grup Resmi • Auto Join', style: TextStyle(color: Color(0xFF8B5CF6), fontFamily: 'Rajdhani', fontSize: 10, fontWeight: FontWeight.bold)),
          ]),
        ]),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: _C.border)),
      ),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator(color: _C.red, strokeWidth: 2))
              : _msgs.isEmpty
                  ? _emptyState('Belum ada pesan.\nJadi yang pertama! 👑')
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                      itemCount: _msgs.length,
                      itemBuilder: (_, i) => _ChatBubble(
                        msg: _msgs[i], myUser: widget.username,
                        onReply: (m) => setState(() => _replyTo = m),
                      ),
                    ),
        ),
        _InputBar(
          ctrl: _ctrl, sending: _sending, replyTo: _replyTo,
          isRecording: _isRecording, recSeconds: _recSeconds,
          onCancelReply: () => setState(() => _replyTo = null),
          onSend: () => _send(msg: _ctrl.text.trim()),
          onMedia: _pickMedia, onLocation: _sendLocation,
          onStartRecord: _startRecord,
          onStopRecord: () => _stopRecord(),
          onCancelRecord: () => _stopRecord(cancel: true),
        ),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  CHAT BUBBLE  (dengan reply + voice)
// ═══════════════════════════════════════════════════════════════
class _ChatBubble extends StatelessWidget {
  final Map<String, dynamic> msg;
  final String myUser;
  final void Function(Map<String, dynamic>) onReply;
  final void Function(Map<String, dynamic>)? onDelete;
  final void Function(Map<String, dynamic>, String)? onReact;

  const _ChatBubble({required this.msg, required this.myUser, required this.onReply, this.onDelete, this.onReact});

  Future<Map<String, dynamic>?> _fetchProfile(String username) async {
    try {
      final r = await http.get(Uri.parse('${AppConfig.baseUrl}/api/user/profile?username=$username'))
          .timeout(const Duration(seconds: 8));
      final d = jsonDecode(r.body);
      if (d['success'] == true) return d['user'];
    } catch (_) {}
    return null;
  }

  void _showProfile(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _C.card,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _ProfileSheet(username: msg['username'] ?? '', myUser: myUser, fetchProfile: _fetchProfile),
    );
  }

  void _showIphoneMenu(BuildContext context) {
    final isMe = msg['username'] == myUser;
    final type  = msg['type'] ?? 'text';
    final text  = msg['message'] as String? ?? '';

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.55),
      transitionDuration: const Duration(milliseconds: 220),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) {
        return SafeArea(
          child: Align(
            alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.fromLTRB(isMe ? 16 : 56, 0, isMe ? 56 : 16, 0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  // ── Emoji reactions ──────────────────────────
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1C2533),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.white10),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 6))],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: ['👍', '❤️', '😂', '😮', '😢', '🙏'].map((emoji) =>
                        GestureDetector(
                          onTap: () {
                            Navigator.pop(ctx);
                            onReact?.call(msg, emoji);
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 6),
                            child: Text(emoji, style: const TextStyle(fontSize: 26)),
                          ),
                        ),
                      ).toList(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  // ── Action list ──────────────────────────────
                  Container(
                    width: 240,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1C2533),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white10),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 6))],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _menuItem(ctx, Icons.star_border_rounded, 'Beri Bintang', Colors.white, () {}),
                        _divider(),
                        _menuItem(ctx, Icons.reply_rounded, 'Balas', Colors.white, () { onReply(msg); }),
                        _divider(),
                        _menuItem(ctx, Icons.forward_rounded, 'Teruskan', Colors.white, () {}),
                        if (type == 'text' && text.isNotEmpty) ...[
                          _divider(),
                          _menuItem(ctx, Icons.copy_rounded, 'Salin', Colors.white, () {
                            Clipboard.setData(ClipboardData(text: text));
                          }),
                        ],
                        _divider(),
                        _menuItem(ctx, Icons.volume_up_rounded, 'Ucapkan', Colors.white, () {}),
                        if (isMe) ...[
                          _divider(),
                          _menuItem(ctx, Icons.delete_rounded, 'Hapus', const Color(0xFFFF453A), () {
                            onDelete?.call(msg);
                          }),
                        ] else ...[
                          _divider(),
                          _menuItem(ctx, Icons.flag_rounded, 'Laporkan', Colors.white, () {}),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _menuItem(BuildContext ctx, IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: () { Navigator.pop(ctx); onTap(); },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        child: Row(children: [
          Expanded(child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 16))),
          Icon(icon, color: color, size: 20),
        ]),
      ),
    );
  }

  Widget _divider() => Container(height: 0.5, color: Colors.white12);

  @override
  Widget build(BuildContext context) {
    final isMe = msg['username'] == myUser;
    final type  = msg['type'] ?? 'text';

    return Dismissible(
      key: ValueKey(msg['id'] ?? '${msg['username']}_${msg['timestamp']}'),
      direction: isMe ? DismissDirection.endToStart : DismissDirection.startToEnd,
      confirmDismiss: (_) async { onReply(msg); return false; },
      background: _replyDismissBackground(isMe, false),
      secondaryBackground: _replyDismissBackground(isMe, true),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(
          mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (!isMe) ...[
              GestureDetector(
                onTap: () => _showProfile(context),
                child: Container(width: 30, height: 30,
                  decoration: BoxDecoration(shape: BoxShape.circle,
                    color: _C.red.withValues(alpha: 0.12), border: Border.all(color: _C.red.withValues(alpha: 0.3))),
                  child: Center(child: Text((msg['username'] ?? '?')[0].toUpperCase(),
                    style: const TextStyle(color: _C.red, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')))),
              ),
              const SizedBox(width: 8),
            ],
            Flexible(
              child: GestureDetector(
                onLongPress: () => _showIphoneMenu(context),
                child: Column(crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start, children: [
                  if (!isMe)
                    GestureDetector(
                      onTap: () => _showProfile(context),
                      child: Padding(padding: const EdgeInsets.only(left: 4, bottom: 3),
                        child: Text(msg['username'] ?? '', style: const TextStyle(color: _C.red, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 11))),
                    ),
                  // Reply preview inside bubble
                  if (msg['replyTo'] != null) ...[
                    Container(
                      margin: const EdgeInsets.only(bottom: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: _C.red.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border(left: BorderSide(color: _C.red, width: 3)),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(msg['replyTo']['username'] ?? '',
                          style: const TextStyle(color: _C.red, fontFamily: 'Rajdhani', fontSize: 10, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 2),
                        Text(
                          msg['replyTo']['type'] == 'image' ? '📷 Foto'
                            : msg['replyTo']['type'] == 'video' ? '🎥 Video'
                            : msg['replyTo']['type'] == 'voice' ? '🎤 Pesan suara'
                            : msg['replyTo']['type'] == 'location' ? '📍 Lokasi'
                            : (msg['replyTo']['message'] ?? ''),
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 11),
                        ),
                      ]),
                    ),
                  ],
                  // Main bubble
                  GestureDetector(
                    onTap: () {
                      if (type == 'image') {
                        if (msg['mediaUrl'] != null) {
                          _openImageUrl(context, msg['mediaUrl'] as String);
                        } else if (msg['mediaBase64'] != null) {
                          _openImage(context, base64Decode(msg['mediaBase64']));
                        }
                      } else if (type == 'location' && msg['location'] != null) {
                        _openMap(msg['location']['lat'], msg['location']['lng']);
                      }
                    },
                    child: Container(
                      padding: type == 'image' || type == 'video' ? EdgeInsets.zero
                          : type == 'voice' ? const EdgeInsets.symmetric(horizontal: 12, vertical: 10)
                          : const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
                      decoration: BoxDecoration(
                        gradient: isMe ? const LinearGradient(colors: [_C.cyanD, _C.red], begin: Alignment.topLeft, end: Alignment.bottomRight) : null,
                        color: isMe ? null : _C.card,
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(16), topRight: const Radius.circular(16),
                          bottomLeft: Radius.circular(isMe ? 16 : 4),
                          bottomRight: Radius.circular(isMe ? 4 : 16),
                        ),
                        border: isMe ? null : Border.all(color: _C.border),
                        boxShadow: isMe ? [BoxShadow(color: _C.red.withValues(alpha: 0.2), blurRadius: 8)] : null,
                      ),
                      child: _buildContent(context, type, isMe),
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(msg['time'] ?? '', style: const TextStyle(color: _C.textSec, fontFamily: 'Rajdhani', fontSize: 10)),
                    if (isMe) ...[
                      const SizedBox(width: 4),
                      Icon(
                        msg['read'] == true ? Icons.done_all_rounded : Icons.done_rounded,
                        size: 13,
                        color: msg['read'] == true ? const Color(0xFF00BCD4) : _C.textSec,
                      ),
                    ],
                  ]),
                ]),
              ),
            ),
            if (isMe) const SizedBox(width: 4),
          ],
        ),
      ),
    );
  }

  Widget _replyDismissBackground(bool isMe, bool secondary) {
    return Container(
      alignment: secondary ? Alignment.centerRight : Alignment.centerLeft,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.reply_rounded, color: _C.red.withValues(alpha: 0.7), size: 22),
        const SizedBox(width: 6),
        Text('Balas', style: TextStyle(color: _C.red.withValues(alpha: 0.7), fontFamily: 'Rajdhani', fontSize: 12, fontWeight: FontWeight.bold)),
      ]),
    );
  }

  Widget _buildContent(BuildContext context, String type, bool isMe) {
    if (type == 'image' && (msg['mediaUrl'] != null || msg['mediaBase64'] != null)) {
      final borderRadius = BorderRadius.only(
        topLeft: const Radius.circular(15), topRight: const Radius.circular(15),
        bottomLeft: Radius.circular(isMe ? 15 : 3), bottomRight: Radius.circular(isMe ? 3 : 15),
      );
      Widget imageWidget;
      if (msg['mediaUrl'] != null) {
        imageWidget = Image.network(
          msg['mediaUrl'] as String,
          width: 200, height: 200, fit: BoxFit.cover,
          loadingBuilder: (_, child, progress) => progress == null ? child
              : Container(width: 200, height: 200, color: _C.card,
                  child: const Center(child: CircularProgressIndicator(color: _C.red, strokeWidth: 2))),
          errorBuilder: (_, __, ___) => Container(width: 200, height: 200, color: _C.card,
              child: const Center(child: Icon(Icons.broken_image_rounded, color: _C.textSec, size: 40))),
        );
      } else {
        imageWidget = Image.memory(base64Decode(msg['mediaBase64']), width: 200, height: 200, fit: BoxFit.cover);
      }
      return ClipRRect(
        borderRadius: borderRadius,
        child: Stack(children: [
          imageWidget,
          Positioned(bottom: 6, right: 6,
            child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), borderRadius: BorderRadius.circular(6)),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.zoom_in_rounded, color: Colors.white70, size: 10), SizedBox(width: 3),
                Text('Tap', style: TextStyle(color: Colors.white70, fontSize: 9, fontFamily: 'Rajdhani')),
              ]))),
        ]),
      );
    }

    if (type == 'video') {
      return Container(width: 200, height: 120,
        decoration: BoxDecoration(color: Colors.black,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(15), topRight: const Radius.circular(15),
            bottomLeft: Radius.circular(isMe ? 15 : 3), bottomRight: Radius.circular(isMe ? 3 : 15),
          )),
        child: const Stack(alignment: Alignment.center, children: [
          Icon(Icons.play_circle_fill_rounded, color: Colors.white70, size: 50),
          Positioned(bottom: 8, right: 8, child: Text('Video', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 10))),
        ]));
    }

    if (type == 'voice') {
      return _VoiceBubble(msg: msg, isMe: isMe);
    }

    if (type == 'location' && msg['location'] != null) {
      final loc = msg['location'];
      return Container(width: 200,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 200, height: 100,
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.only(topLeft: Radius.circular(15), topRight: Radius.circular(15)),
              color: _C.bg,
            ),
            child: ClipRRect(
              borderRadius: const BorderRadius.only(topLeft: Radius.circular(15), topRight: Radius.circular(15)),
              child: Image.network(
                'https://maps.googleapis.com/maps/api/staticmap?center=${loc['lat']},${loc['lng']}&zoom=15&size=400x200&markers=color:red%7C${loc['lat']},${loc['lng']}&key=YOUR_KEY',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: _C.border,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.location_on_rounded, color: _C.red.withValues(alpha: 0.5), size: 32),
                    const Text('Lokasi', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 11)),
                  ])),
              ),
            ),
          ),
          Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(Icons.location_on_rounded, color: isMe ? Colors.white : _C.red, size: 14), const SizedBox(width: 6),
              const Text('Lokasi Saya', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 12))]),
            const SizedBox(height: 3),
            Text('${loc['lat'].toStringAsFixed(4)}, ${loc['lng'].toStringAsFixed(4)}',
              style: const TextStyle(color: Colors.white60, fontFamily: 'Rajdhani', fontSize: 10)),
            const SizedBox(height: 6),
            GestureDetector(
              onTap: () => _openMap(loc['lat'], loc['lng']),
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.open_in_new_rounded, color: Colors.white, size: 12), SizedBox(width: 4),
                  Text('Buka Maps', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.bold)),
                ])),
            ),
          ])),
        ]),
      );
    }

    return Text(msg['message'] ?? '',
      style: TextStyle(color: isMe ? Colors.white : Colors.white.withOpacity(0.9), fontFamily: 'Rajdhani', fontSize: 13, height: 1.4));
  }

  void _openImage(BuildContext context, Uint8List bytes) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white), onPressed: () => Navigator.pop(context))),
      body: Center(child: InteractiveViewer(panEnabled: true, minScale: 0.5, maxScale: 5,
        child: Image.memory(bytes, fit: BoxFit.contain))),
    )));
  }

  void _openImageUrl(BuildContext context, String url) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white), onPressed: () => Navigator.pop(context))),
      body: Center(child: InteractiveViewer(panEnabled: true, minScale: 0.5, maxScale: 5,
        child: Image.network(url, fit: BoxFit.contain,
          loadingBuilder: (_, child, progress) => progress == null ? child
              : const Center(child: CircularProgressIndicator(color: _C.red, strokeWidth: 2)),
          errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image_rounded, color: _C.textSec, size: 60)),
        ))),
    )));
  }

  void _openMap(double lat, double lng) async {
    final url = 'https://www.google.com/maps/search/?api=1&query=$lat,$lng';
    if (await canLaunchUrl(Uri.parse(url))) await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }
}

// ═══════════════════════════════════════════════════════════════
//  VOICE BUBBLE  (audio player)
// ═══════════════════════════════════════════════════════════════
class _VoiceBubble extends StatefulWidget {
  final Map<String, dynamic> msg;
  final bool isMe;
  const _VoiceBubble({required this.msg, required this.isMe});

  @override
  State<_VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<_VoiceBubble> {
  final _player = FlutterSoundPlayer();
  bool _playing  = false;
  bool _loading  = false;
  double _pos    = 0.0;
  Duration _dur  = Duration.zero;
  Duration _cur  = Duration.zero;

  @override
  void initState() {
    super.initState();
    _player.openPlayer().then((_) async {
      await _player.setSubscriptionDuration(const Duration(milliseconds: 100));
      _player.onProgress?.listen((e) {
        if (!mounted) return;
        setState(() {
          _cur = e.position;
          _dur = e.duration == Duration.zero ? _dur : e.duration;
          _pos = _dur.inMilliseconds > 0
              ? (_cur.inMilliseconds / _dur.inMilliseconds).clamp(0.0, 1.0)
              : 0.0;
        });
      });
    });
  }

  @override
  void dispose() {
    _player.closePlayer();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Future<void> _togglePlay() async {
    if (_playing) {
      await _player.pausePlayer();
      setState(() => _playing = false);
      return;
    }
    if (_loading) return;
    setState(() => _loading = true);
    try {
      void onFinish() {
        if (mounted) setState(() { _playing = false; _pos = 0.0; _cur = Duration.zero; });
      }

      if (widget.msg['voiceUrl'] != null) {
        final url = widget.msg['voiceUrl'] as String;
        final codec = url.endsWith('.m4a') || url.endsWith('.aac') ? Codec.aacADTS
            : url.endsWith('.mp3') ? Codec.mp3 : Codec.defaultCodec;
        await _player.startPlayer(
          fromURI: url,
          codec: codec,
          whenFinished: onFinish,
        );
        setState(() => _playing = true);
      } else if (widget.msg['voiceBase64'] != null) {
        final bytes = base64Decode(widget.msg['voiceBase64']);
        final dir   = await getTemporaryDirectory();
        final file  = File('${dir.path}/play_${widget.msg['id'] ?? DateTime.now().millisecondsSinceEpoch}.aac');
        await file.writeAsBytes(bytes);
        await _player.startPlayer(
          fromURI: file.path,
          codec: Codec.aacADTS,
          whenFinished: onFinish,
        );
        setState(() => _playing = true);
      }
    } catch (e) {
      debugPrint('Voice play error: $e');
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final dur = widget.msg['voiceDuration'] != null
        ? Duration(seconds: widget.msg['voiceDuration'])
        : _dur;

    return SizedBox(
      width: 220,
      child: Row(children: [
        // Play/Pause button
        GestureDetector(
          onTap: _togglePlay,
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              color: widget.isMe ? Colors.white.withOpacity(0.2) : _C.red.withValues(alpha: 0.15),
              shape: BoxShape.circle,
              border: Border.all(color: widget.isMe ? Colors.white38 : _C.red.withValues(alpha: 0.4)),
            ),
            child: _loading
                ? const Padding(padding: EdgeInsets.all(10),
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    color: widget.isMe ? Colors.white : _C.red, size: 22),
          ),
        ),
        const SizedBox(width: 8),
        // Waveform + progress
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Fake waveform (bar-bar)
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: SizedBox(
              height: 28,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(20, (i) {
                  final heights = [0.4, 0.7, 0.5, 0.9, 0.6, 0.8, 0.4, 1.0, 0.7, 0.5,
                                   0.9, 0.6, 0.8, 0.4, 0.7, 0.5, 0.6, 0.8, 0.5, 0.7];
                  final filled = i / 20.0 <= _pos;
                  return Container(
                    width: 3, height: 28 * heights[i],
                    decoration: BoxDecoration(
                      color: filled
                          ? (widget.isMe ? Colors.white : _C.red)
                          : (widget.isMe ? Colors.white.withOpacity(0.3) : _C.red.withValues(alpha: 0.25)),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  );
                }),
              ),
            ),
          ),
          const SizedBox(height: 3),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(_playing ? _fmt(_cur) : _fmt(dur),
              style: TextStyle(color: widget.isMe ? Colors.white70 : _C.textSec, fontFamily: 'Rajdhani', fontSize: 9)),
            Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.mic_rounded, color: widget.isMe ? Colors.white54 : _C.textSec, size: 10),
              const SizedBox(width: 2),
              Text('Suara', style: TextStyle(color: widget.isMe ? Colors.white54 : _C.textSec, fontFamily: 'Rajdhani', fontSize: 9)),
            ]),
          ]),
        ])),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  INPUT BAR  (reply preview + voice record mode)
// ═══════════════════════════════════════════════════════════════
class _InputBar extends StatelessWidget {
  final TextEditingController ctrl;
  final bool sending;
  final Map<String, dynamic>? replyTo;
  final bool isRecording;
  final int recSeconds;
  final VoidCallback onCancelReply;
  final VoidCallback onSend;
  final Function(String) onMedia;
  final VoidCallback onLocation;
  final VoidCallback onStartRecord;
  final VoidCallback onStopRecord;
  final VoidCallback onCancelRecord;

  const _InputBar({
    required this.ctrl,
    required this.sending,
    required this.replyTo,
    required this.isRecording,
    required this.recSeconds,
    required this.onCancelReply,
    required this.onSend,
    required this.onMedia,
    required this.onLocation,
    required this.onStartRecord,
    required this.onStopRecord,
    required this.onCancelRecord,
  });

  String _fmtSec(int s) {
    final m = (s ~/ 60).toString().padLeft(2, '0');
    final sec = (s % 60).toString().padLeft(2, '0');
    return '$m:$sec';
  }

  void _showAttach(BuildContext context) {
    showModalBottomSheet(context: context, backgroundColor: _C.card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 16),
        const Text('Kirim Media', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 16),
        Row(children: [
          _attachBtn(context, Icons.photo_library_rounded,   'Galeri',  _C.red,                () { Navigator.pop(context); onMedia('image'); }),
          const SizedBox(width: 10),
          _attachBtn(context, Icons.camera_alt_rounded,      'Kamera',  const Color(0xFF8B5CF6), () { Navigator.pop(context); onMedia('camera'); }),
          const SizedBox(width: 10),
          _attachBtn(context, Icons.videocam_rounded,        'Video',   const Color(0xFFEC4899), () { Navigator.pop(context); onMedia('video'); }),
          const SizedBox(width: 10),
          _attachBtn(context, Icons.location_on_rounded,    'Lokasi',  const Color(0xFF10B981), () { Navigator.pop(context); onLocation(); }),
        ]),
        const SizedBox(height: 16),
      ])),
    );
  }

  Widget _attachBtn(BuildContext context, IconData icon, String label, Color color, VoidCallback onTap) {
    return Expanded(child: GestureDetector(onTap: onTap,
      child: Container(padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withValues(alpha: 0.3))),
        child: Column(children: [Icon(icon, color: color, size: 24), const SizedBox(height: 5),
          Text(label, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.bold))]))));
  }

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      // Reply preview bar
      if (replyTo != null)
        Container(
          padding: const EdgeInsets.fromLTRB(16, 8, 12, 8),
          decoration: BoxDecoration(color: _C.card, border: Border(top: BorderSide(color: _C.border))),
          child: Row(children: [
            Container(width: 3, height: 36, decoration: BoxDecoration(color: _C.red, borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Balas ${replyTo!['username'] ?? ''}',
                style: const TextStyle(color: _C.red, fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.bold)),
              const SizedBox(height: 1),
              Text(
                replyTo!['type'] == 'image' ? '📷 Foto'
                  : replyTo!['type'] == 'video' ? '🎥 Video'
                  : replyTo!['type'] == 'voice' ? '🎤 Pesan suara'
                  : replyTo!['type'] == 'location' ? '📍 Lokasi'
                  : (replyTo!['message'] ?? ''),
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 12),
              ),
            ])),
            GestureDetector(
              onTap: onCancelReply,
              child: const Icon(Icons.close_rounded, color: Colors.white38, size: 20),
            ),
          ]),
        ),

      // Recording mode OR normal input
      Container(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
        decoration: const BoxDecoration(color: _C.bg, border: Border(top: BorderSide(color: _C.border, width: 1))),
        child: isRecording
            ? _buildRecordingBar(context)
            : _buildNormalBar(context),
      ),
    ]);
  }

  Widget _buildRecordingBar(BuildContext context) {
    return Row(children: [
      // Cancel record
      GestureDetector(
        onTap: onCancelRecord,
        child: Container(width: 44, height: 44,
          decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), shape: BoxShape.circle, border: Border.all(color: Colors.red.withOpacity(0.4))),
          child: const Icon(Icons.delete_rounded, color: Colors.red, size: 20)),
      ),
      const SizedBox(width: 12),
      // Timer + waveform anim
      Expanded(child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.red.withOpacity(0.4))),
        child: Row(children: [
          Container(width: 10, height: 10, decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Text(_fmtSec(recSeconds),
            style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(width: 10),
          const Expanded(child: Text('Merekam suara...', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 12), overflow: TextOverflow.ellipsis)),
        ]),
      )),
      const SizedBox(width: 12),
      // Stop & send
      GestureDetector(
        onTap: onStopRecord,
        child: Container(width: 44, height: 44,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [_C.red, _C.cyanD]),
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: _C.red.withValues(alpha: 0.3), blurRadius: 10)]),
          child: const Icon(Icons.send_rounded, color: Colors.white, size: 20)),
      ),
    ]);
  }

  Widget _buildNormalBar(BuildContext context) {
    return Row(children: [
      GestureDetector(onTap: () => _showAttach(context),
        child: Container(width: 40, height: 40,
          decoration: BoxDecoration(color: _C.red.withValues(alpha: 0.1), shape: BoxShape.circle, border: Border.all(color: _C.red.withValues(alpha: 0.3))),
          child: const Icon(Icons.attach_file_rounded, color: _C.red, size: 18))),
      const SizedBox(width: 10),
      Expanded(child: Container(
        decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(24), border: Border.all(color: _C.border)),
        child: Row(children: [
          const SizedBox(width: 16),
          Expanded(child: TextField(controller: ctrl, maxLines: 4, minLines: 1,
            style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 14),
            decoration: const InputDecoration(hintText: 'Tulis pesan...', hintStyle: TextStyle(color: _C.textSec, fontFamily: 'Rajdhani', fontSize: 13),
              border: InputBorder.none, isDense: true, contentPadding: EdgeInsets.symmetric(vertical: 12)),
            onSubmitted: (_) => onSend())),
          const SizedBox(width: 8),
        ]),
      )),
      const SizedBox(width: 10),
      // Mic button — tahan = rekam, lepas = kirim (kayak WA)
      GestureDetector(
        onLongPressStart: (_) => onStartRecord(),
        onLongPressEnd:   (_) => onStopRecord(),
        onLongPressCancel: () => onCancelRecord(),
        child: Container(width: 44, height: 44,
          decoration: BoxDecoration(
            color: isRecording
                ? _C.red.withValues(alpha: 0.3)
                : _C.red.withValues(alpha: 0.1),
            shape: BoxShape.circle,
            border: Border.all(color: _C.red.withValues(alpha: isRecording ? 0.8 : 0.3))),
          child: Icon(
            isRecording ? Icons.stop_rounded : Icons.mic_rounded,
            color: _C.red, size: 20)),
      ),
      const SizedBox(width: 8),
      GestureDetector(onTap: sending ? null : onSend,
        child: AnimatedContainer(duration: const Duration(milliseconds: 200),
          width: 44, height: 44,
          decoration: BoxDecoration(
            gradient: sending ? null : const LinearGradient(colors: [_C.red, _C.cyanD]),
            color: sending ? _C.card : null, shape: BoxShape.circle,
            boxShadow: sending ? null : [BoxShadow(color: _C.red.withValues(alpha: 0.3), blurRadius: 10)]),
          child: sending
              ? const Center(child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: _C.red, strokeWidth: 2)))
              : const Icon(Icons.send_rounded, color: Colors.white, size: 18))),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════
//  PROFILE BOTTOM SHEET  (tidak berubah)
// ═══════════════════════════════════════════════════════════════
class _ProfileSheet extends StatefulWidget {
  final String username;
  final String myUser;
  final Future<Map<String, dynamic>?> Function(String) fetchProfile;
  const _ProfileSheet({required this.username, required this.myUser, required this.fetchProfile});

  @override
  State<_ProfileSheet> createState() => _ProfileSheetState();
}

class _ProfileSheetState extends State<_ProfileSheet> {
  Map<String, dynamic>? _profile;
  bool _loading = true;

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'kingz': return const Color(0xFFEF4444);
      case 'staff':      return const Color(0xFF10B981);
      case 'partner':    return const Color(0xFFEC4899);
      case 'owner':      return const Color(0xFF8B5CF6);
      case 'vip':        return const Color(0xFFFFD700);
      case 'reseller':   return const Color(0xFF3B82F6);
      default:           return _C.red;
    }
  }

  IconData _roleIcon(String role) {
    switch (role.toLowerCase()) {
      case 'kingz': return Icons.workspace_premium_rounded;
      case 'staff': return Icons.admin_panel_settings_rounded;
      case 'partner': return Icons.handshake_rounded;
      case 'owner': return Icons.shield_rounded;
      case 'vip': return Icons.star_rounded;
      case 'reseller': return Icons.storefront_rounded;
      default: return Icons.person_rounded;
    }
  }

  String _roleLabel(String role) {
    switch (role.toLowerCase()) {
      case 'kingz': return 'KINGZ';
      case 'staff':      return 'STAFF';
      case 'partner':    return 'PARTNER';
      case 'owner':      return 'OWNER';
      case 'vip':        return 'VIP';
      case 'reseller':   return 'RESELLER';
      default:           return 'MEMBER';
    }
  }

  @override
  void initState() {
    super.initState();
    widget.fetchProfile(widget.username).then((p) {
      if (mounted) setState(() { _profile = p; _loading = false; });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom + 24, left: 20, right: 20, top: 16),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 20),
        if (_loading)
          const Padding(padding: EdgeInsets.symmetric(vertical: 30), child: CircularProgressIndicator(color: _C.red, strokeWidth: 2))
        else ...[
          Container(width: 72, height: 72,
            decoration: BoxDecoration(shape: BoxShape.circle,
              gradient: LinearGradient(colors: [_C.red.withValues(alpha: 0.3), _C.cyanD.withValues(alpha: 0.2)]),
              border: Border.all(color: _C.red.withValues(alpha: 0.5), width: 2.5),
              boxShadow: [BoxShadow(color: _C.red.withValues(alpha: 0.2), blurRadius: 16)]),
            child: Center(child: Text(widget.username[0].toUpperCase(),
              style: const TextStyle(color: _C.red, fontSize: 28, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')))),
          const SizedBox(height: 12),
          Text(widget.username, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 22, letterSpacing: 1)),
          const SizedBox(height: 8),
          if (_profile != null) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: _roleColor(_profile!['role'] ?? 'member').withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _roleColor(_profile!['role'] ?? 'member').withValues(alpha: 0.4))),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(_roleIcon(_profile!['role'] ?? 'member'), color: _roleColor(_profile!['role'] ?? 'member'), size: 14),
                const SizedBox(width: 5),
                Text(_roleLabel(_profile!['role'] ?? 'member'),
                  style: TextStyle(color: _roleColor(_profile!['role'] ?? 'member'), fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13)),
              ])),
            const SizedBox(height: 16),
            Container(width: double.infinity, padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: _C.bg, borderRadius: BorderRadius.circular(16), border: Border.all(color: _C.border)),
              child: Column(children: [
                _infoRow(Icons.calendar_month_rounded, 'Expired', _profile!['expiredDate'] ?? '-'),
                const SizedBox(height: 10),
                _infoRow(Icons.verified_user_outlined, 'Status', _profile!['expiredDate'] == '9999-12-31' ? 'Permanent' : 'Aktif'),
              ])),
            const SizedBox(height: 16),
          ] else ...[
            const SizedBox(height: 8),
            Container(padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: _C.bg, borderRadius: BorderRadius.circular(14), border: Border.all(color: _C.border)),
              child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.info_outline_rounded, color: _C.textSec, size: 15), SizedBox(width: 8),
                Text('Data profil tidak tersedia', style: TextStyle(color: _C.textSec, fontFamily: 'Rajdhani', fontSize: 13)),
              ])),
            const SizedBox(height: 16),
          ],
          GestureDetector(
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) =>
                PrivateChatRoomPage(myUsername: widget.myUser, toUsername: widget.username)));
            },
            child: Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(gradient: const LinearGradient(colors: [_C.red, _C.cyanD]), borderRadius: BorderRadius.circular(14),
                boxShadow: [BoxShadow(color: _C.red.withValues(alpha: 0.3), blurRadius: 12)]),
              child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.chat_rounded, color: Colors.white, size: 18), SizedBox(width: 8),
                Text('Chat Privat', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 1)),
              ])),
          ),
          const SizedBox(height: 8),
          GestureDetector(onTap: () => Navigator.pop(context),
            child: Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(color: _C.bg, borderRadius: BorderRadius.circular(14), border: Border.all(color: _C.border)),
              child: const Center(child: Text('Tutup', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold))))),
        ],
      ]),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Row(children: [
      Icon(icon, color: _C.red.withValues(alpha: 0.6), size: 15), const SizedBox(width: 10),
      Text('$label: ', style: const TextStyle(color: _C.textSec, fontFamily: 'Rajdhani', fontSize: 13)),
      Expanded(child: Text(value, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13), overflow: TextOverflow.ellipsis)),
    ]);
  }
}

Widget _emptyState(String text) {
  return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Container(width: 70, height: 70,
      decoration: BoxDecoration(shape: BoxShape.circle, color: _C.red.withValues(alpha: 0.08), border: Border.all(color: _C.red.withValues(alpha: 0.2))),
      child: Icon(Icons.chat_bubble_outline_rounded, color: _C.red.withValues(alpha: 0.4), size: 30)),
    const SizedBox(height: 16),
    Text(text, textAlign: TextAlign.center, style: const TextStyle(color: _C.textSec, fontFamily: 'Rajdhani', fontSize: 14, height: 1.5)),
  ]));
}
