// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'config.dart';

class _C {
  static const bg      = Color(0xFF080D14);
  static const card    = Color(0xFF0D1520);
  static const border  = Color(0xFF1A2840);
  static const red     = Color(0xFFFF1744);
  static const redDark = Color(0xFF7F0000);
  static const green   = Color(0xFF10B981);
  static const textSec = Color(0xFF6B7280);
}

// ═══════════════════════════════════════════════════════════════
//  STORY LIST — WA Style
// ═══════════════════════════════════════════════════════════════
class StoryPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  const StoryPage({super.key, required this.username, required this.sessionKey});
  @override State<StoryPage> createState() => _StoryPageState();
}

class _StoryPageState extends State<StoryPage> {
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _fetchStories(); }

  Future<void> _fetchStories() async {
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/story/all?key=${widget.sessionKey}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) setState(() { _users = List<Map<String, dynamic>>.from(data['users']); _loading = false; });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _uploadStory() async {
    final picker = ImagePicker();
    showModalBottomSheet(
      context: context, backgroundColor: _C.card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.only(top: 12, bottom: 16), decoration: BoxDecoration(color: _C.textSec, borderRadius: BorderRadius.circular(2))),
        _sheetTile(Icons.image_rounded, 'Foto dari Galeri', () async { Navigator.pop(context); final xf = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80); if (xf != null) await _processAndUpload(xf.path, 'image'); }),
        _sheetTile(Icons.camera_alt_rounded, 'Foto dari Kamera', () async { Navigator.pop(context); final xf = await picker.pickImage(source: ImageSource.camera, imageQuality: 80); if (xf != null) await _processAndUpload(xf.path, 'image'); }),
        _sheetTile(Icons.videocam_rounded, 'Video dari Galeri', () async { Navigator.pop(context); final xf = await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(seconds: 30)); if (xf != null) await _processAndUpload(xf.path, 'video'); }),
        const SizedBox(height: 8),
      ])),
    );
  }

  ListTile _sheetTile(IconData icon, String label, VoidCallback onTap) => ListTile(
    leading: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: _C.red.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: _C.red)),
    title: Text(label, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
    onTap: onTap,
  );

  Future<void> _processAndUpload(String filePath, String mediaType) async {
    final captionCtrl = TextEditingController();
    final caption = await showDialog<String>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _C.card, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Tambah Caption', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
      content: TextField(controller: captionCtrl, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani'),
        decoration: InputDecoration(hintText: 'Caption (opsional)...', hintStyle: const TextStyle(color: _C.textSec), filled: true, fillColor: _C.bg, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)), maxLines: 3),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, ''), child: const Text('Skip', style: TextStyle(color: _C.textSec))),
        TextButton(onPressed: () => Navigator.pop(context, captionCtrl.text), child: const Text('Upload', style: TextStyle(color: _C.red, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold))),
      ],
    ));
    if (caption == null) return;
    if (!mounted) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const Center(child: CircularProgressIndicator(color: _C.red)));
    try {
      final bytes = await File(filePath).readAsBytes();
      final res = await http.post(Uri.parse('${AppConfig.baseUrl}/api/story/upload'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'mediaBase64': base64Encode(bytes), 'mediaType': mediaType, 'caption': caption}),
      ).timeout(const Duration(seconds: 60));
      if (mounted) Navigator.pop(context);
      final data = jsonDecode(res.body);
      _showSnack(data['success'] == true ? '✅ Story berhasil diupload!' : '❌ ${data['message']}');
      if (data['success'] == true) _fetchStories();
    } catch (e) { if (mounted) Navigator.pop(context); _showSnack('❌ Gagal upload'); }
  }

  void _showSnack(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
    backgroundColor: _C.card, behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));

  void _openViewer(int idx) => Navigator.push(context, PageRouteBuilder(
    pageBuilder: (_, __, ___) => StoryViewerPage(users: _users, initialUserIndex: idx, username: widget.username, sessionKey: widget.sessionKey, onViewed: _fetchStories),
    transitionsBuilder: (_, anim, __, child) => FadeTransition(opacity: anim, child: child),
    transitionDuration: const Duration(milliseconds: 250),
  ));

  @override
  Widget build(BuildContext context) {
    final myIdx   = _users.indexWhere((u) => u['username'] == widget.username);
    final myUser  = myIdx != -1 ? _users[myIdx] : null;
    final others  = _users.where((u) => u['username'] != widget.username).toList();

    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.bg, surfaceTintColor: Colors.transparent, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20), onPressed: () => Navigator.pop(context)),
        title: const Text('Story', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 22, letterSpacing: 1)),
        actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _C.textSec, size: 22), onPressed: _fetchStories)],
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: _C.border)),
      ),
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: _C.red))
        : RefreshIndicator(color: _C.red, backgroundColor: _C.card, onRefresh: _fetchStories,
            child: ListView(padding: const EdgeInsets.only(bottom: 24), children: [
              _sectionLabel('Story Saya'),
              _buildMyStoryTile(myUser, myIdx),
              if (others.isNotEmpty) ...[
                _sectionLabel('Story Terbaru'),
                ...others.map((u) => _buildStoryTile(u, _users.indexWhere((x) => x['username'] == u['username']))),
              ],
              if (_users.isEmpty)
                Padding(padding: const EdgeInsets.only(top: 60), child: Column(children: [
                  Icon(Icons.auto_stories_rounded, color: _C.red.withValues(alpha: 0.3), size: 56),
                  const SizedBox(height: 16),
                  const Text('Belum ada story', style: TextStyle(color: _C.textSec, fontFamily: 'Rajdhani', fontSize: 15)),
                ])),
            ])),
    );
  }

  Widget _sectionLabel(String label) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
    child: Text(label, style: TextStyle(color: Colors.white.withOpacity(0.38), fontFamily: 'Rajdhani', fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1.4)),
  );

  Widget _buildMyStoryTile(Map<String, dynamic>? myUser, int myIdx) {
    final hasStory = myUser != null;
    return GestureDetector(
      onTap: hasStory ? () => _openViewer(myIdx) : _uploadStory,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: _C.border)),
        child: Row(children: [
          Stack(children: [
            Container(
              width: 54, height: 54,
              decoration: BoxDecoration(shape: BoxShape.circle,
                gradient: hasStory
                  ? const LinearGradient(colors: [Color(0xFF00BCD4), Color(0xFF009688)], begin: Alignment.topLeft, end: Alignment.bottomRight)
                  : LinearGradient(colors: [_C.border, _C.border.withValues(alpha: 0.5)])),
              padding: const EdgeInsets.all(2.5),
              child: CircleAvatar(backgroundColor: _C.bg, child: Text(widget.username.isNotEmpty ? widget.username[0].toUpperCase() : '?',
                style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 20)))),
            Positioned(right: 0, bottom: 0, child: Container(
              width: 20, height: 20,
              decoration: BoxDecoration(color: hasStory ? _C.green : _C.red, shape: BoxShape.circle, border: Border.all(color: _C.bg, width: 2)),
              child: Icon(hasStory ? Icons.play_arrow_rounded : Icons.add_rounded, color: Colors.white, size: 12))),
          ]),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Story Saya', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 3),
            Text(hasStory ? '${(myUser['stories'] as List).length} status aktif • Ketuk untuk melihat' : 'Ketuk untuk menambahkan status',
              style: TextStyle(color: hasStory ? _C.green : _C.textSec, fontFamily: 'Rajdhani', fontSize: 12)),
          ])),
          GestureDetector(onTap: _uploadStory,
            child: Container(width: 32, height: 32,
              decoration: BoxDecoration(color: _C.red.withValues(alpha: 0.12), shape: BoxShape.circle, border: Border.all(color: _C.red.withValues(alpha: 0.3))),
              child: const Icon(Icons.add_rounded, color: _C.red, size: 18))),
        ]),
      ),
    );
  }

  Widget _buildStoryTile(Map<String, dynamic> user, int globalIdx) {
    final hasUnread = user['hasUnread'] as bool? ?? false;
    final stories   = user['stories'] as List;
    final ts        = stories.isNotEmpty ? _timeAgo(stories.last['createdAt'] as int) : '';
    return GestureDetector(
      onTap: () => _openViewer(globalIdx),
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(18),
          border: Border.all(color: hasUnread ? _C.red.withValues(alpha: 0.35) : _C.border)),
        child: Row(children: [
          Container(
            width: 54, height: 54,
            decoration: BoxDecoration(shape: BoxShape.circle,
              gradient: hasUnread
                ? const LinearGradient(colors: [Color(0xFFFF1744), Color(0xFFFF6B35), Color(0xFFFF1744)], begin: Alignment.topLeft, end: Alignment.bottomRight)
                : LinearGradient(colors: [_C.textSec.withValues(alpha: 0.4), _C.textSec.withValues(alpha: 0.2)]),
              boxShadow: hasUnread ? [BoxShadow(color: _C.red.withValues(alpha: 0.3), blurRadius: 8)] : null),
            padding: const EdgeInsets.all(2.5),
            child: CircleAvatar(backgroundColor: _C.bg, child: Text((user['username'] as String).isNotEmpty ? (user['username'] as String)[0].toUpperCase() : '?',
              style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 20)))),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(user['username'] as String, style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: hasUnread ? FontWeight.w900 : FontWeight.bold, fontSize: 15), overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Text(hasUnread ? '${stories.length} status dikirim • $ts' : 'Sudah dilihat • $ts',
              style: TextStyle(color: hasUnread ? Colors.white70 : _C.textSec, fontFamily: 'Rajdhani', fontSize: 12)),
          ])),
          if (hasUnread) Container(width: 10, height: 10, decoration: const BoxDecoration(color: _C.red, shape: BoxShape.circle)),
        ]),
      ),
    );
  }

  String _timeAgo(int ms) {
    final d = Duration(milliseconds: DateTime.now().millisecondsSinceEpoch - ms);
    if (d.inMinutes < 1) return 'Baru saja';
    if (d.inMinutes < 60) return '${d.inMinutes}m lalu';
    if (d.inHours < 24) return '${d.inHours}j lalu';
    return '${d.inDays}h lalu';
  }
}

// ═══════════════════════════════════════════════════════════════
//  STORY VIEWER
// ═══════════════════════════════════════════════════════════════
class StoryViewerPage extends StatefulWidget {
  final List<Map<String, dynamic>> users;
  final int initialUserIndex;
  final String username;
  final String sessionKey;
  final VoidCallback onViewed;
  const StoryViewerPage({super.key, required this.users, required this.initialUserIndex, required this.username, required this.sessionKey, required this.onViewed});
  @override State<StoryViewerPage> createState() => _StoryViewerPageState();
}

class _StoryViewerPageState extends State<StoryViewerPage> with TickerProviderStateMixin {
  late int _userIdx;
  int _storyIdx = 0;
  late AnimationController _progressCtrl;
  VideoPlayerController? _videoCtrl;
  bool _videoReady  = false;
  bool _videoError  = false;
  bool _paused      = false;
  bool _showViewers = false;
  List<String> _viewers = [];
  List<String> _likers  = [];
  bool _liked     = false;
  int  _likeCount = 0;
  late AnimationController _likeAnim;

  static const _imgDuration = Duration(seconds: 5);

  @override
  void initState() {
    super.initState();
    _userIdx = widget.initialUserIndex;
    _progressCtrl = AnimationController(vsync: this);
    _progressCtrl.addStatusListener((s) { if (s == AnimationStatus.completed) _nextStory(); });
    _likeAnim = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    _loadStory();
  }

  @override
  void dispose() { _progressCtrl.dispose(); _likeAnim.dispose(); _videoCtrl?.dispose(); super.dispose(); }

  Map<String, dynamic> get _currentUser  => widget.users[_userIdx];
  List                  get _stories      => _currentUser['stories'] as List;
  Map                   get _currentStory => _stories[_storyIdx] as Map;
  bool get _isMyStory => _currentUser['username'] == widget.username;

  void _loadStory() {
    _progressCtrl.reset();
    _videoCtrl?.dispose(); _videoCtrl = null; _videoReady = false; _videoError = false;
    _showViewers = false; _viewers = []; _likers = [];
    _liked     = _currentStory['liked'] as bool? ?? false;
    _likeCount = _currentStory['likeCount'] as int? ?? 0;
    _markViewed();
    if (_currentStory['mediaType'] == 'video') {
      final url = '${AppConfig.baseUrl}/${_currentStory['mediaUrl']}';
      _videoCtrl = VideoPlayerController.networkUrl(Uri.parse(url))
        ..initialize().then((_) {
          if (!mounted) return;
          setState(() => _videoReady = true);
          _videoCtrl!.play();
          _progressCtrl.duration = _videoCtrl!.value.duration;
          _progressCtrl.forward();
        }).catchError((_) {
          if (!mounted) return;
          setState(() => _videoError = true);
          _progressCtrl.duration = _imgDuration;
          _progressCtrl.forward();
        });
    } else {
      _progressCtrl.duration = _imgDuration;
      _progressCtrl.forward();
    }
    if (mounted) setState(() {});
  }

  Future<void> _markViewed() async {
    try { await http.post(Uri.parse('${AppConfig.baseUrl}/api/story/view'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'key': widget.sessionKey, 'storyId': _currentStory['id']})); } catch (_) {}
    widget.onViewed();
  }

  Future<void> _toggleLike() async {
    _likeAnim.forward(from: 0);
    setState(() { _liked = !_liked; _likeCount += _liked ? 1 : -1; });
    try { await http.post(Uri.parse('${AppConfig.baseUrl}/api/story/like'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'key': widget.sessionKey, 'storyId': _currentStory['id']})); } catch (_) {}
  }

  Future<void> _fetchViewers() async {
    if (!_isMyStory) return;
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/story/viewers?key=${widget.sessionKey}&storyId=${_currentStory['id']}'));
      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) setState(() { _viewers = List<String>.from(data['viewers']); _likers = List<String>.from(data['likes'] ?? []); _showViewers = true; });
    } catch (_) {}
  }

  Future<void> _deleteStory() async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _C.card, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Hapus Story?', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
      content: const Text('Story akan dihapus permanen.', style: TextStyle(color: Colors.white70, fontFamily: 'Rajdhani')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal', style: TextStyle(color: _C.textSec))),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus', style: TextStyle(color: _C.red, fontWeight: FontWeight.bold))),
      ]));
    if (ok != true) return;
    try {
      await http.delete(Uri.parse('${AppConfig.baseUrl}/api/story/delete'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'key': widget.sessionKey, 'storyId': _currentStory['id']}));
      widget.onViewed();
      if (mounted) Navigator.pop(context);
    } catch (_) {}
  }

  void _nextStory() { if (_storyIdx < _stories.length - 1) { setState(() => _storyIdx++); _loadStory(); } else _nextUser(); }
  void _prevStory() { if (_storyIdx > 0) { setState(() => _storyIdx--); _loadStory(); } else _prevUser(); }
  void _nextUser()  { if (_userIdx < widget.users.length - 1) { setState(() { _userIdx++; _storyIdx = 0; }); _loadStory(); } else Navigator.pop(context); }
  void _prevUser()  { if (_userIdx > 0) { setState(() { _userIdx--; _storyIdx = 0; }); _loadStory(); } }
  void _togglePause() { setState(() => _paused = !_paused); if (_paused) { _progressCtrl.stop(); _videoCtrl?.pause(); } else { _progressCtrl.forward(); _videoCtrl?.play(); } }

  @override
  Widget build(BuildContext context) {
    final isVideo  = _currentStory['mediaType'] == 'video';
    final mediaUrl = '${AppConfig.baseUrl}/${_currentStory['mediaUrl']}';
    final caption  = _currentStory['caption'] as String? ?? '';
    final padding  = MediaQuery.of(context).padding;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onLongPressStart: (_) => _togglePause(),
        onLongPressEnd: (_) { if (_paused) _togglePause(); },
        child: Stack(fit: StackFit.expand, children: [

          // Media
          if (isVideo)
            _videoReady && _videoCtrl != null
              ? FittedBox(fit: BoxFit.cover, child: SizedBox(width: _videoCtrl!.value.size.width, height: _videoCtrl!.value.size.height, child: VideoPlayer(_videoCtrl!)))
              : _videoError
                ? Container(color: _C.card, child: const Center(child: Icon(Icons.broken_image_rounded, color: _C.textSec, size: 64)))
                : const Center(child: CircularProgressIndicator(color: _C.red))
          else
            Image.network(mediaUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: _C.card, child: const Center(child: Icon(Icons.broken_image_rounded, color: _C.textSec, size: 64)))),

          // Gradient
          Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xCC000000), Colors.transparent, Colors.transparent, Color(0xDD000000)], stops: [0.0, 0.25, 0.65, 1.0]))),

          // Tap zones
          Positioned.fill(child: Row(children: [
            Expanded(child: GestureDetector(onTap: _prevStory, child: const ColoredBox(color: Colors.transparent))),
            const Expanded(flex: 2, child: SizedBox()),
            Expanded(child: GestureDetector(onTap: _nextStory, child: const ColoredBox(color: Colors.transparent))),
          ])),

          // Progress bars
          Positioned(top: padding.top + 10, left: 12, right: 12,
            child: Row(children: List.generate(_stories.length, (i) => Expanded(
              child: Container(margin: const EdgeInsets.symmetric(horizontal: 2), height: 3,
                decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
                child: i < _storyIdx
                  ? Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2)))
                  : i == _storyIdx
                    ? AnimatedBuilder(animation: _progressCtrl, builder: (_, __) => FractionallySizedBox(alignment: Alignment.centerLeft, widthFactor: _progressCtrl.value, child: Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2)))))
                    : const SizedBox.shrink()),
            )))),

          // Header
          Positioned(top: padding.top + 22, left: 16, right: 16,
            child: Row(children: [
              CircleAvatar(radius: 20, backgroundColor: _C.border,
                child: Text((_currentUser['username'] as String).isNotEmpty ? (_currentUser['username'] as String)[0].toUpperCase() : '?',
                  style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 16))),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_currentUser['username'] as String, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
                Text(_timeAgo(_currentStory['createdAt'] as int), style: const TextStyle(color: Colors.white60, fontFamily: 'Rajdhani', fontSize: 12)),
              ])),
              if (_isMyStory) IconButton(icon: const Icon(Icons.delete_outline_rounded, color: Colors.white70), onPressed: _deleteStory),
              IconButton(icon: const Icon(Icons.close_rounded, color: Colors.white70), onPressed: () => Navigator.pop(context)),
            ])),

          // Caption
          if (caption.isNotEmpty)
            Positioned(bottom: padding.bottom + 90, left: 20, right: 20,
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(color: Colors.black.withOpacity(0.55), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white12)),
                child: Text(caption, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 15), textAlign: TextAlign.center))),

          // Bottom bar
          Positioned(bottom: padding.bottom + 24, left: 20, right: 20,
            child: Row(children: [
              if (!_isMyStory) GestureDetector(
                onTap: _toggleLike,
                child: ScaleTransition(
                  scale: Tween(begin: 1.0, end: 1.4).chain(CurveTween(curve: Curves.elasticOut)).animate(_likeAnim),
                  child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(30), border: Border.all(color: _liked ? _C.red : Colors.white24)),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(_liked ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: _liked ? _C.red : Colors.white70, size: 22),
                      if (_likeCount > 0) ...[const SizedBox(width: 6), Text('$_likeCount', style: TextStyle(color: _liked ? _C.red : Colors.white70, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14))],
                    ])))),
              const Spacer(),
              if (_isMyStory) GestureDetector(
                onTap: () { _togglePause(); _fetchViewers(); },
                child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.white24)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.remove_red_eye_rounded, color: Colors.white70, size: 20),
                    const SizedBox(width: 6),
                    Text('${_currentStory['viewCount'] ?? _viewers.length}', style: const TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14)),
                  ]))),
            ])),

          // Viewers panel
          if (_showViewers)
            GestureDetector(
              onTap: () { setState(() => _showViewers = false); if (_paused) _togglePause(); },
              child: Container(color: Colors.black54,
                child: Align(alignment: Alignment.bottomCenter,
                  child: GestureDetector(onTap: () {},
                    child: Container(
                      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.55),
                      decoration: const BoxDecoration(color: _C.card, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Container(width: 40, height: 4, margin: const EdgeInsets.only(top: 12), decoration: BoxDecoration(color: _C.textSec, borderRadius: BorderRadius.circular(2))),
                        Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                          child: Row(children: [
                            const Icon(Icons.remove_red_eye_rounded, color: _C.red, size: 18), const SizedBox(width: 8),
                            Text('Dilihat oleh ${_viewers.length} orang', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 16)),
                            const Spacer(),
                            IconButton(icon: const Icon(Icons.close_rounded, color: _C.textSec, size: 20), onPressed: () { setState(() => _showViewers = false); if (_paused) _togglePause(); }),
                          ])),
                        const Divider(color: _C.border, height: 1),
                        Flexible(child: _viewers.isEmpty
                          ? const Padding(padding: EdgeInsets.all(32), child: Text('Belum ada yang nonton', style: TextStyle(color: _C.textSec, fontFamily: 'Rajdhani', fontSize: 14)))
                          : ListView.builder(
                              padding: const EdgeInsets.symmetric(vertical: 8), shrinkWrap: true,
                              itemCount: _viewers.length,
                              itemBuilder: (_, i) {
                                final name = _viewers[i]; final isLiker = _likers.contains(name);
                                return ListTile(
                                  leading: CircleAvatar(backgroundColor: _C.border, child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold))),
                                  title: Text(name, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
                                  trailing: isLiker ? const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.favorite_rounded, color: _C.red, size: 16), SizedBox(width: 4), Text('Suka', style: TextStyle(color: _C.red, fontFamily: 'Rajdhani', fontSize: 12))]) : null);
                              })),
                      ]),
                    ))))),

          // Pause indicator
          if (_paused && !_showViewers)
            Center(child: Container(padding: const EdgeInsets.all(16), decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle), child: const Icon(Icons.pause_rounded, color: Colors.white, size: 40))),
        ]),
      ),
    );
  }

  String _timeAgo(int ms) {
    final d = Duration(milliseconds: DateTime.now().millisecondsSinceEpoch - ms);
    if (d.inMinutes < 1) return 'Baru saja';
    if (d.inMinutes < 60) return '${d.inMinutes} menit lalu';
    if (d.inHours < 24) return '${d.inHours} jam lalu';
    return '${d.inDays} hari lalu';
  }
}
