// tebak_kata_page.dart — Game tebak kata: huruf diacak, menang dapet voucher diskon.
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

const _bg = Color(0xFF0E0A14);
const _panel = Color(0xFF1A1424);
const _card = Color(0xFF201A2D);
const _line = Color(0x1EFFFFFF);
const _text = Color(0xFFF2EFF7);
const _textDim = Color(0xFFABA3BE);
const _accent = Color(0xFFBA68C8);
const _accent2 = Color(0xFFE1BEE7);
const _green = Color(0xFF22C55E);
const _red = Color(0xFFFF5370);
const _gold = Color(0xFFFFC107);

class TebakKataPage extends StatefulWidget {
  final String username;
  const TebakKataPage({super.key, required this.username});

  @override
  State<TebakKataPage> createState() => _TebakKataPageState();
}

class _TebakKataPageState extends State<TebakKataPage> {
  String tab = 'main'; // 'main' | 'riwayat'

  // ── Game state ──
  String? sessionId;
  String scrambled = '';
  int wordLength = 0;
  int playedToday = 0;
  int dailyLimit = 3;
  bool loading = false;
  bool wrongShake = false;
  String errorMsg = '';
  final _guessCtrl = TextEditingController();

  // ── Riwayat state ──
  List<dynamic> history = [];
  bool historyLoading = false;

  @override
  void initState() {
    super.initState();
    _startGame();
  }

  @override
  void dispose() {
    _guessCtrl.dispose();
    super.dispose();
  }

  Future<void> _startGame() async {
    setState(() { loading = true; errorMsg = ''; sessionId = null; _guessCtrl.clear(); });
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/game/tebakkata/start'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.username}),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['success'] != true) {
        setState(() => errorMsg = d['message'] ?? 'Gagal mulai game');
      } else {
        setState(() {
          sessionId = d['sessionId'];
          scrambled = d['scrambled'];
          wordLength = d['length'];
          playedToday = d['playedToday'] ?? 0;
          dailyLimit = d['dailyLimit'] ?? 3;
        });
      }
    } catch (_) {
      setState(() => errorMsg = 'Gagal terhubung ke server');
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _submitGuess() async {
    if (sessionId == null || _guessCtrl.text.trim().isEmpty) return;
    setState(() { loading = true; errorMsg = ''; });
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/game/tebakkata/guess'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'sessionId': sessionId, 'guess': _guessCtrl.text.trim()}),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['success'] != true) {
        setState(() => errorMsg = d['message'] ?? 'Gagal cek jawaban');
      } else if (d['correct'] == true) {
        _showWinDialog(d['word'], d['voucher']);
        setState(() { sessionId = null; });
      } else {
        setState(() => wrongShake = true);
        _guessCtrl.clear();
        Future.delayed(const Duration(milliseconds: 400), () { if (mounted) setState(() => wrongShake = false); });
      }
    } catch (_) {
      setState(() => errorMsg = 'Gagal terhubung ke server');
    }
    if (mounted) setState(() => loading = false);
  }

  void _showWinDialog(String word, Map voucher) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: _gold.withOpacity(0.4))),
        title: Column(children: [
          const Icon(Icons.emoji_events_rounded, color: _gold, size: 44),
          const SizedBox(height: 8),
          const Text('Menang!', style: TextStyle(color: _text, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 20)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Jawabannya: $word', style: const TextStyle(color: _textDim, fontFamily: 'Rajdhani')),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: _gold.withOpacity(0.1), borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _gold.withOpacity(0.4)),
            ),
            child: Column(children: [
              Text('Rp ${voucher['nominal']}', style: const TextStyle(color: _gold, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 22)),
              const SizedBox(height: 6),
              Text(voucher['code'], style: const TextStyle(color: _text, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 2)),
              const SizedBox(height: 4),
              const Text('Berlaku 7 hari', style: TextStyle(color: _textDim, fontSize: 11, fontFamily: 'Rajdhani')),
            ]),
          ),
        ]),
        actions: [
          TextButton(
            onPressed: () { Navigator.pop(ctx); _startGame(); },
            child: const Text('Main Lagi', style: TextStyle(color: _textDim, fontFamily: 'Rajdhani')),
          ),
          TextButton(
            onPressed: () { Navigator.pop(ctx); setState(() => tab = 'riwayat'); _fetchHistory(); },
            child: const Text('Lihat Riwayat', style: TextStyle(color: _accent, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<void> _fetchHistory() async {
    setState(() => historyLoading = true);
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/game/tebakkata/history?username=${widget.username}')).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        setState(() {
          history = d['history'] ?? [];
          playedToday = d['playedToday'] ?? 0;
          dailyLimit = d['dailyLimit'] ?? 3;
        });
      }
    } catch (_) {}
    if (mounted) setState(() => historyLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: Row(children: [
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded, color: _text)),
              const SizedBox(width: 4),
              const Icon(Icons.abc_rounded, color: _accent, size: 22),
              const SizedBox(width: 8),
              const Text('Tebak Kata', style: TextStyle(color: _text, fontSize: 19, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(12), border: Border.all(color: _line)),
              child: Row(children: [
                Expanded(child: _tabBtn('main', 'MAIN', Icons.videogame_asset_rounded)),
                Expanded(child: _tabBtn('riwayat', 'RIWAYAT', Icons.history_rounded)),
              ]),
            ),
          ),
          Expanded(child: tab == 'main' ? _buildGame() : _buildHistory()),
        ]),
      ),
    );
  }

  Widget _tabBtn(String value, String label, IconData icon) {
    final active = tab == value;
    return GestureDetector(
      onTap: () { setState(() => tab = value); if (value == 'riwayat') _fetchHistory(); },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(color: active ? _accent.withOpacity(0.18) : Colors.transparent, borderRadius: BorderRadius.circular(9)),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: active ? _accent : _textDim, size: 15),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(color: active ? _accent : _textDim, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 12)),
        ]),
      ),
    );
  }

  Widget _buildGame() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        const SizedBox(height: 10),
        Text('Main hari ini: $playedToday/$dailyLimit', style: const TextStyle(color: _textDim, fontSize: 12, fontFamily: 'Rajdhani')),
        const SizedBox(height: 24),
        const Text('Susun huruf di bawah ini jadi sebuah kata:', textAlign: TextAlign.center,
          style: TextStyle(color: _textDim, fontSize: 13, fontFamily: 'Rajdhani')),
        const SizedBox(height: 18),
        if (loading && sessionId == null && errorMsg.isEmpty)
          const Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator(color: _accent))
        else if (errorMsg.isNotEmpty && sessionId == null)
          Column(children: [
            Icon(Icons.sentiment_dissatisfied_rounded, color: _textDim, size: 40),
            const SizedBox(height: 10),
            Text(errorMsg, textAlign: TextAlign.center, style: const TextStyle(color: _textDim, fontFamily: 'Rajdhani')),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _startGame,
              style: ElevatedButton.styleFrom(backgroundColor: _accent, foregroundColor: Colors.white),
              child: const Text('Coba Lagi', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
            ),
          ])
        else if (sessionId != null) ...[
          AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            transform: Matrix4.translationValues(wrongShake ? 8 : 0, 0, 0),
            child: Wrap(
              spacing: 8, runSpacing: 8, alignment: WrapAlignment.center,
              children: scrambled.split('').map((ch) => Container(
                width: 40, height: 48,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [_accent2, _accent]),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [BoxShadow(color: _accent.withOpacity(0.35), blurRadius: 10, spreadRadius: -2)],
                ),
                alignment: Alignment.center,
                child: Text(ch, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')),
              )).toList(),
            ),
          ),
          const SizedBox(height: 8),
          Text('$wordLength huruf', style: const TextStyle(color: _textDim, fontSize: 11, fontFamily: 'Rajdhani')),
          const SizedBox(height: 26),
          TextField(
            controller: _guessCtrl,
            textCapitalization: TextCapitalization.characters,
            textAlign: TextAlign.center,
            onSubmitted: (_) => _submitGuess(),
            style: const TextStyle(color: _text, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2, fontFamily: 'Rajdhani'),
            decoration: InputDecoration(
              hintText: 'Jawaban kamu',
              hintStyle: TextStyle(color: _textDim.withOpacity(0.5)),
              filled: true, fillColor: _panel,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _line)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _line)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _accent)),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity, height: 50,
            child: ElevatedButton(
              onPressed: loading ? null : _submitGuess,
              style: ElevatedButton.styleFrom(backgroundColor: _accent, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              child: loading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.4))
                  : const Text('Jawab', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')),
            ),
          ),
          const SizedBox(height: 10),
          TextButton(onPressed: _startGame, child: const Text('Acak Ulang / Lewati', style: TextStyle(color: _textDim, fontFamily: 'Rajdhani'))),
          if (errorMsg.isNotEmpty) Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(errorMsg, style: const TextStyle(color: _red, fontSize: 12.5, fontFamily: 'Rajdhani')),
          ),
        ],
      ]),
    );
  }

  Widget _buildHistory() {
    if (historyLoading && history.isEmpty) {
      return const Center(child: CircularProgressIndicator(color: _accent));
    }
    if (history.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.inbox_rounded, color: _textDim, size: 40),
          const SizedBox(height: 10),
          const Text('Belum ada riwayat menang', style: TextStyle(color: _textDim, fontFamily: 'Rajdhani')),
        ]),
      );
    }
    return RefreshIndicator(
      onRefresh: _fetchHistory,
      color: _accent,
      backgroundColor: _panel,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: history.length,
        itemBuilder: (context, i) {
          final h = history[i];
          final status = h['status'] as String? ?? 'aktif';
          Color statusColor; String statusLabel;
          switch (status) {
            case 'terpakai': statusColor = _textDim; statusLabel = 'TERPAKAI'; break;
            case 'kadaluarsa': statusColor = _red; statusLabel = 'KADALUARSA'; break;
            case 'hilang': statusColor = _red; statusLabel = 'HILANG'; break;
            default: statusColor = _green; statusLabel = 'AKTIF';
          }
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: _line)),
            child: Row(children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(shape: BoxShape.circle, color: _gold.withOpacity(0.14)),
                child: const Icon(Icons.card_giftcard_rounded, color: _gold, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Text(h['voucherCode'] ?? '-', style: const TextStyle(color: _text, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: statusColor.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                    child: Text(statusLabel, style: TextStyle(color: statusColor, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')),
                  ),
                ]),
                const SizedBox(height: 3),
                Text('Rp ${h['nominal']} • kata: ${h['word']}', style: const TextStyle(color: _textDim, fontSize: 11.5, fontFamily: 'Rajdhani')),
              ])),
            ]),
          );
        },
      ),
    );
  }
}
