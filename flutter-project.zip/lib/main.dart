import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';
import 'config.dart';
import 'landing_page.dart';
import 'welcome_page.dart';
import 'login_page.dart';
import 'loader_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'buy_account.dart';
import 'splash.dart';
import 'maintenance_page.dart';
import 'synclave_page.dart';

Future<Map<String, dynamic>?> _fetchMaintenanceStatus() async {
  try {
    final res = await http
        .get(Uri.parse('${AppConfig.baseUrl}/api/maintenance/status'))
        .timeout(const Duration(seconds: 8));
    final d = jsonDecode(res.body);
    final mode = d['mode'] ?? d['data']?['mode'] ?? 'normal';
    if (mode == 'maintenance' || mode == 'update') {
      return {
        'mode': mode,
        'message': d['message'] ?? d['data']?['message'] ?? '',
        'version': d['version'] ?? d['data']?['version'] ?? '',
        'downloadUrl': d['downloadUrl'] ?? d['data']?['downloadUrl'] ?? '',
        'infoUrl': d['infoUrl'] ?? d['data']?['infoUrl'] ?? '',
        'expiredDate': d['expiredDate'] ?? d['data']?['expiredDate'] ?? '',
        'changelog': List<String>.from(d['changelog'] ?? d['data']?['changelog'] ?? []),
      };
    }
  } catch (_) {}
  return null;
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.dark,
    systemNavigationBarColor: Color(0xFF080D14),
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  final themeNotifier = ThemeNotifier();
  await themeNotifier.loadSaved();

  runApp(
    ThemeProvider(
      notifier: themeNotifier,
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeNotifier = ThemeProvider.of(context);
    return AnimatedBuilder(
      animation: themeNotifier,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Dominus Core V1.0',
          theme: themeNotifier.buildTheme(),
          initialRoute: '/',
          onGenerateRoute: (settings) {
            final args = settings.arguments as Map<String, dynamic>?;
            switch (settings.name) {
              case '/':
                return MaterialPageRoute(builder: (_) => const _MaintenanceCheckerPage());
              case '/maintenance':
                final d = args ?? {};
                return MaterialPageRoute(
                  builder: (_) => MaintenancePage(
                    mode: d['mode'] ?? 'maintenance',
                    message: d['message'] ?? '',
                    version: d['version'] ?? '',
                    downloadUrl: d['downloadUrl'] ?? '',
                    infoUrl: d['infoUrl'] ?? '',
                    expiredDate: d['expiredDate'] ?? '',
                    changelog: List<String>.from(d['changelog'] ?? []),
                  ),
                );
              case '/synclave':
                return MaterialPageRoute(builder: (_) => const SynclavePage());
              case '/welcome':
                return MaterialPageRoute(builder: (_) => const WelcomePage());
              case '/landing':
                return MaterialPageRoute(builder: (_) => const LandingPage());
              case '/login':
                return MaterialPageRoute(builder: (_) => const LoginPage());
              case '/splash':
                return MaterialPageRoute(
                  builder: (_) => SplashPage(data: args ?? {}),
                );
              case '/buy_account':
                return MaterialPageRoute(builder: (_) => const BuyAccountPage());
              case '/loader':
                return MaterialPageRoute(
                  builder: (_) => DashboardPage(
                    username: args?['username'] ?? '',
                    password: args?['password'] ?? '',
                    role: args?['role'] ?? 'member',
                    sessionKey: args?['key'] ?? '',
                    expiredDate: args?['expiredDate'] ?? '',
                    listBug: List<Map<String, dynamic>>.from(args?['listBug'] ?? []),
                    listPayload: List<Map<String, dynamic>>.from(args?['listPayload'] ?? []),
                    listDDoS: List<Map<String, dynamic>>.from(args?['listDDoS'] ?? []),
                    news: List<Map<String, dynamic>>.from(args?['news'] ?? []),
                  ),
                );
              case '/attack':
                return MaterialPageRoute(
                  builder: (_) => AttackPage(
                    username: args?['username'] ?? '',
                    password: args?['password'] ?? '',
                    listBug: List<Map<String, dynamic>>.from(args?['listBug'] ?? []),
                    role: args?['role'] ?? '',
                    expiredDate: args?['expiredDate'] ?? '',
                    sessionKey: args?['sessionKey'] ?? '',
                  ),
                );
              case '/seller':
                return MaterialPageRoute(
                  builder: (_) => SellerPage(keyToken: args?['keyToken'] ?? ''),
                );
              case '/admin':
                return MaterialPageRoute(
                  builder: (_) => AdminPage(sessionKey: args?['sessionKey'] ?? ''),
                );
              default:
                return MaterialPageRoute(
                  builder: (_) => const Scaffold(
                    body: Center(
                      child: Text("404 - PANEL NOT FOUND",
                        style: TextStyle(color: Colors.red)),
                    ),
                  ),
                );
            }
          },
        );
      },
    );
  }
}

// ── Halaman tipis: langsung tampil logo + loading indicator,
//    sambil di background cek maintenance. Gak ada blank screen. ──
class _MaintenanceCheckerPage extends StatefulWidget {
  const _MaintenanceCheckerPage();
  @override
  State<_MaintenanceCheckerPage> createState() => _MaintenanceCheckerPageState();
}

class _MaintenanceCheckerPageState extends State<_MaintenanceCheckerPage> {
  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final data = await _fetchMaintenanceStatus();
    if (!mounted) return;
    if (data != null) {
      Navigator.of(context).pushReplacementNamed('/maintenance', arguments: data);
    } else {
      Navigator.of(context).pushReplacementNamed('/welcome');
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: SizedBox(
          width: 28, height: 28,
          child: CircularProgressIndicator(
            color: Color(0xFFFF1744),
            strokeWidth: 2,
          ),
        ),
      ),
    );
  }
}
