import 'dart:typed_data';
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';

// ─── Palette Warna (Konsisten dengan tema utama Anda) ───
class _C {
  static const bg         = Color(0xFF0E1117);
  static const surface    = Color(0xFF161B22);
  static const card       = Color(0xFF1A1F2B);
  static const border     = Color(0xFF2A3040);
  static const cyan       = Color(0xFFFF1744);
  static const text       = Color(0xFFECEFF4);
  static const textSub    = Color(0xFFADB5BD);
  static const textDim    = Color(0xFF6A737D);
}

class IQCPage extends StatefulWidget {
  const IQCPage({super.key});

  @override
  State<IQCPage> createState() => _IQCPageState();
}

class _IQCPageState extends State<IQCPage> {
  final time = TextEditingController();
  final battery = TextEditingController();
  final sim = TextEditingController();
  final message = TextEditingController();

  Uint8List? image;
  bool loading = false;
  bool saving = false;

  Future<void> generate() async {
    if (time.text.isEmpty ||
        battery.text.isEmpty ||
        sim.text.isEmpty ||
        message.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Isi semua data terlebih dahulu"),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    setState(() {
      loading = true;
      image = null;
    });

    // Parameter sesuai dokumentasi API
    // url = background image (kosong = default template)
    // sender = 'me' atau 'other'
    // read = true/false (centang biru)
    // signal = 1-5
    final url =
        "https://api-nanzz.my.id/docs/api/maker/iqc-gambar.php"
        "?text=${Uri.encodeComponent(message.text)}"
        "&carrier=${Uri.encodeComponent(sim.text)}"
        "&battery=${Uri.encodeComponent(battery.text)}"
        "&time=${Uri.encodeComponent(time.text)}"
        "&signal=4"
        "&sender=other"
        "&read=true";

    try {
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 20));
      if (res.statusCode == 200) {
        final contentType = res.headers['content-type'] ?? '';
        if (contentType.contains('image')) {
          // API langsung return gambar
          setState(() => image = res.bodyBytes);
        } else {
          // API return JSON, coba ambil URL gambar dari response
          try {
            final json = jsonDecode(res.body);
            final imgUrl = json['image'] ?? json['url'] ?? json['result'] ?? json['data']?['image'] ?? json['data']?['url'];
            if (imgUrl != null && imgUrl.toString().startsWith('http')) {
              final imgRes = await http.get(Uri.parse(imgUrl.toString())).timeout(const Duration(seconds: 20));
              if (imgRes.statusCode == 200) setState(() => image = imgRes.bodyBytes);
            } else if (json['base64'] != null) {
              final b64 = json['base64'].toString().replaceFirst(RegExp(r'data:image/[^;]+;base64,'), '');
              setState(() => image = base64Decode(b64));
            } else {
              setState(() => loading = false);
            }
          } catch (_) {
            // Bukan JSON, coba treat sebagai raw bytes
            if (res.bodyBytes.isNotEmpty) {
              setState(() => image = res.bodyBytes);
            }
          }
        }
      } else {
        setState(() => loading = false);
      }
    } catch (e) {
      setState(() => loading = false);
    }

    setState(() => loading = false);
  }

  Future<void> shareImage() async {
    if (image == null) return;

    final file = XFile.fromData(
      image!,
      mimeType: "image/png",
      name: "iqc.png",
    );

    await Share.shareXFiles([file], text: "iPhone Quotes");
  }

  Future<void> saveImageDirectly() async {
    if (image == null) return;
    setState(() => saving = true);
    try {
      // Simpan ke folder app dulu (nggak butuh izin storage, aman di Android 11+).
      final dir = await getTemporaryDirectory();
      final path = "${dir.path}/IQC_${DateTime.now().millisecondsSinceEpoch}.png";
      await File(path).writeAsBytes(image!);
      if (mounted) {
        // Munculin share sheet biar user bisa "Save to Files" / simpan ke galeri.
        await Share.shareXFiles([XFile(path)], text: "iPhone Quotes");
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal menyimpan"), backgroundColor: Colors.red));
    }
    setState(() => saving = false);
  }

  Widget inputBox(String label, TextEditingController controller, {int maxLines = 1, String hint = ''}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 3,
              height: 14,
              decoration: BoxDecoration(
                color: _C.cyan,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border),
          ),
          child: TextField(
            controller: controller,
            maxLines: maxLines,
            style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'Rajdhani'),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: _C.textDim, fontSize: 13, fontFamily: 'Rajdhani'),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              border: InputBorder.none,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.textSub, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "IPHONE QUOTES",
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: 'Rajdhani',
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: _C.border.withOpacity(0.5), height: 1),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // panel input form data
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _C.border),
                ),
                child: Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 5,
                          child: Column(
                            children: [
                              inputBox("Waktu", time, hint: "09:41"),
                              const SizedBox(height: 12),
                              inputBox("Baterai (%)", battery, hint: "100"),
                              const SizedBox(height: 12),
                              inputBox("Provider SIM", sim, hint: "Telkomsel"),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          flex: 6,
                          child: inputBox("Kata-kata Quotes", message, maxLines: 8, hint: "Tulis kutipan kerenmu di sini..."),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _C.cyan,
                          disabledBackgroundColor: _C.cyan.withOpacity(0.2),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          elevation: 0,
                        ),
                        onPressed: loading ? null : generate,
                        child: loading
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(color: _C.bg, strokeWidth: 2.5),
                              )
                            : const Text(
                                "BUAT QUOTES",
                                style: TextStyle(
                                  color: _C.bg,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Rajdhani',
                                  letterSpacing: 1.5,
                                  fontSize: 13,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // panel output preview dan aksi simpan / bagikan
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _C.border),
                ),
                child: Column(
                  children: [
                    if (loading)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 32),
                        child: Center(child: CircularProgressIndicator(color: Color(0xFF1DE9B6))),
                      )
                    else if (image != null)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Container(
                          color: _C.card,
                          padding: const EdgeInsets.all(4),
                          child: Image.memory(image!, fit: BoxFit.contain),
                        ),
                      )
                    else
                      Container(
                        height: 120,
                        alignment: Alignment.center,
                        child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.image_outlined, color: Colors.white24, size: 44),
                          SizedBox(height: 8),
                          Text("Hasil quotes muncul di sini", style: TextStyle(color: Colors.white38, fontSize: 13, fontFamily: 'Rajdhani')),
                        ]),
                      ),
                    const SizedBox(height: 16),
                      
                      // Row Aksi Elegan Baru (Simpan Langsung & Bagikan)
                      Row(
                        children: [
                          Expanded(
                            child: SizedBox(
                              height: 44,
                              child: OutlinedButton.icon(
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: _C.cyan,
                                  side: const BorderSide(color: _C.border),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                ),
                                onPressed: saving ? null : saveImageDirectly,
                                icon: saving 
                                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: _C.cyan, strokeWidth: 2))
                                    : const Icon(Icons.download_rounded, size: 18),
                                label: const Text("Simpan", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Rajdhani')),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: SizedBox(
                              height: 44,
                              child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: _C.cyan,
                                  foregroundColor: _C.bg,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                ),
                                onPressed: shareImage,
                                icon: const Icon(Icons.share_rounded, size: 18),
                                label: const Text("Bagikan", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Rajdhani')),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
