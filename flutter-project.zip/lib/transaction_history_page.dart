import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dart:io';
import 'buy_account.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════════
//  TRANSACTION HISTORY PAGE — Premium & Elegant
// ═══════════════════════════════════════════════════════════════

class TransactionHistoryPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  const TransactionHistoryPage({super.key, required this.username, required this.sessionKey});

  @override
  State<TransactionHistoryPage> createState() => _TransactionHistoryPageState();
}

class _TransactionHistoryPageState extends State<TransactionHistoryPage> {
  static const _bg       = Color(0xFF060B14);
  static const _card     = Color(0xFF0D1520);
  static const _border   = Color(0xFF1C2A3A);
  static const _red      = Color(0xFFFF1744);
  static const _green    = Color(0xFF22C55E);
  static const _blue     = Color(0xFF3B82F6);
  static const _amber    = Color(0xFFF59E0B);
  static const _purple   = Color(0xFF8B5CF6);

  List<Map<String, dynamic>> _history = [];
  bool _loading = true;
  String? _selectedId;

  @override
  void initState() {
    super.initState();
    _fetchHistory();
  }


  Future<String> _getDeviceId() async {
    try {
      final info = DeviceInfoPlugin();
      if (Platform.isAndroid) {
        final d = await info.androidInfo;
        return d.id;
      } else if (Platform.isIOS) {
        final d = await info.iosInfo;
        return d.identifierForVendor ?? '';
      }
    } catch (_) {}
    return '';
  }

  Future<void> _fetchHistory() async {
    setState(() => _loading = true);
    try {
      final res = await http.get(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/my-history?username=${widget.username}&deviceId=${Uri.encodeComponent(await _getDeviceId())}'),
        headers: {'x-session-key': widget.sessionKey},
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        setState(() {
          _history = List<Map<String, dynamic>>.from(data['history'] ?? []);
          _loading = false;
        });
      } else {
        setState(() => _loading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'approved': return _green;
      case 'rejected': return _red;
      case 'expired':  return Colors.white38;
      default:         return _amber;
    }
  }

  IconData _statusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'approved': return Icons.check_circle_rounded;
      case 'rejected': return Icons.cancel_rounded;
      case 'expired':  return Icons.timer_off_rounded;
      default:         return Icons.hourglass_top_rounded;
    }
  }

  String _statusLabel(String status) {
    switch (status.toLowerCase()) {
      case 'approved': return 'Berhasil';
      case 'rejected': return 'Ditolak';
      case 'expired':  return 'Kedaluwarsa';
      default:         return 'Menunggu';
    }
  }

  String _fmtRupiah(dynamic v) {
    if (v == null) return '-';
    final n = (v is num) ? v.toInt() : int.tryParse(v.toString()) ?? 0;
    return 'Rp ${n.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}';
  }

  String _fmtDate(String? iso) {
    if (iso == null) return '-';
    try {
      final d = DateTime.parse(iso).toLocal();
      const months = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des'];
      return '${d.day} ${months[d.month - 1]} ${d.year}, ${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';
    } catch (_) { return iso; }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: CustomScrollView(
        slivers: [
          // ── App Bar ─────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 120,
            pinned: true,
            backgroundColor: _bg,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white, size: 18),
              onPressed: () => Navigator.pop(context),
            ),
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 56, bottom: 14),
              title: const Text(
                'RIWAYAT TRANSAKSI',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.w900,
                  fontSize: 16,
                  letterSpacing: 2,
                ),
              ),
              background: Stack(children: [
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF0D1520), Color(0xFF060B14)],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
                Positioned(right: -20, top: -20,
                  child: Container(
                    width: 140, height: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _red.withOpacity(0.05),
                    ),
                  ),
                ),
              ]),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.refresh_rounded, color: Colors.white54, size: 20),
                onPressed: _fetchHistory,
              ),
              const SizedBox(width: 8),
            ],
          ),

          // ── Content ──────────────────────────────────────────
          if (_loading)
            const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator(color: _red, strokeWidth: 2)),
            )
          else if (_history.isEmpty)
            SliverFillRemaining(
              child: Center(child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.receipt_long_rounded, color: Colors.white12, size: 64),
                  const SizedBox(height: 12),
                  const Text('Belum ada transaksi', style: TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 14)),
                ],
              )),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, i) {
                    final trx = _history[i];
                    final isSelected = _selectedId == trx['requestId'];
                    final status = (trx['status'] as String? ?? 'pending').toLowerCase();
                    final isDone = status == 'approved';
                    return _buildTrxCard(trx, isSelected, isDone, status);
                  },
                  childCount: _history.length,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTrxCard(Map trx, bool isSelected, bool isDone, String status) {
    final statusColor = _statusColor(status);
    final id = trx['requestId'] as String? ?? '';

    return GestureDetector(
      onTap: () {
        if (status == 'pending') {
          final themeNotifier = ThemeProvider.of(context);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => Theme(
                data: themeNotifier.buildTheme(),
                child: Scaffold(
                  backgroundColor: _bg,
                  appBar: AppBar(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    leading: IconButton(
                      icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
                      onPressed: () => Navigator.pop(context),
                    ),
                    title: const Text('Selesai',
                      style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 1)),
                  ),
                  body: StepSukses(
                    requestId: id,
                    onHome: () => Navigator.pop(context),
                  ),
                ),
              ),
            ),
          );
        } else {
          setState(() => _selectedId = isSelected ? null : id);
        }
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isSelected ? statusColor.withOpacity(0.4) : _border,
            width: isSelected ? 1.5 : 1,
          ),
          boxShadow: isSelected ? [
            BoxShadow(color: statusColor.withOpacity(0.12), blurRadius: 20, spreadRadius: 0),
          ] : [],
        ),
        child: Column(children: [
          // ── Header card ──────────────────────────────────────
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              // Status icon
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: statusColor.withOpacity(0.1),
                  border: Border.all(color: statusColor.withOpacity(0.3)),
                ),
                child: Icon(_statusIcon(status), color: statusColor, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Baris 1: nama role + badge status (beli biasa) / nama role saja (upgrade)
                Row(children: [
                  Flexible(
                    child: Text(
                      trx['type'] == 'upgrade'
                          ? '${trx['oldRole'] ?? '-'} → ${trx['role'] ?? '-'}'
                          : trx['role'] ?? '-',
                      style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 15),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (trx['type'] != 'upgrade') ...[
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: statusColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: statusColor.withOpacity(0.3)),
                      ),
                      child: Text(_statusLabel(status), style: TextStyle(color: statusColor, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 10)),
                    ),
                  ],
                ]),
                const SizedBox(height: 3),
                // Baris 2: tanggal + badge upgrade & status (upgrade) / tanggal saja (beli biasa)
                Row(children: [
                  Text(
                    _fmtDate(trx['createdAt']),
                    style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11),
                  ),
                  if (trx['type'] == 'upgrade') ...[
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: Colors.orange.withOpacity(0.35)),
                      ),
                      child: const Text('UPGRADE', style: TextStyle(color: Colors.orange, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 10)),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: statusColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: statusColor.withOpacity(0.3)),
                      ),
                      child: Text(_statusLabel(status), style: TextStyle(color: statusColor, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 10)),
                    ),
                  ],
                ]),
              ])),
              Text(
                _fmtRupiah(trx['totalWithFee'] ?? trx['price']),
                style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 14),
              ),
            ]),
          ),

          // ── Expanded: struk premium kalau done ───────────────
          if (isSelected) ...[
            Container(height: 1, color: _border),
            if (isDone)
              _buildStruk(trx)
            else
              _buildStatusDetail(trx, status),
          ],
        ]),
      ),
    );
  }

  // ── STRUK PREMIUM ─────────────────────────────────────────────
  Widget _buildStruk(Map trx) {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        // Header struk
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_green.withOpacity(0.15), _green.withOpacity(0.05)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _green.withOpacity(0.25)),
          ),
          child: Column(children: [
            const Icon(Icons.check_circle_rounded, color: _green, size: 36),
            const SizedBox(height: 8),
            const Text(
              'TRANSAKSI BERHASIL',
              style: TextStyle(color: _green, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2),
            ),
            const SizedBox(height: 2),
            Text(
              'Dominus Core • ${_fmtDate(trx['approvedAt'] ?? trx['createdAt'])}',
              style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11),
            ),
          ]),
        ),
        const SizedBox(height: 16),

        // Garis putus-putus
        _dashedDivider(),
        const SizedBox(height: 16),

        // Detail transaksi
        _strukRow('ID Transaksi', (trx['requestId'] ?? '-').toString().toUpperCase(), copyable: true),
        if (trx['type'] == 'upgrade') ...[
          _strukRow('Tipe', 'UPGRADE ROLE'),
          _strukRow('Role Lama', (trx['oldRole'] ?? '-').toString().toUpperCase()),
          _strukRow('Role Baru', (trx['role'] ?? '-').toString().toUpperCase()),
        ] else
          _strukRow('Paket', trx['role'] ?? '-'),
        _strukRow('Durasi', trx['durationType'] ?? '-'),
        _strukRow('Metode', trx['autoOrder'] == true ? 'QRIS Auto Order' : 'Transfer Manual'),
        _strukRow('Harga', _fmtRupiah(trx['price'])),
        if ((trx['totalWithFee'] ?? 0) != (trx['price'] ?? 0))
          _strukRow('Total + Fee', _fmtRupiah(trx['totalWithFee'])),
        _strukRowIcon('Status', 'Disetujui', Icons.check_circle_rounded, _green),

        const SizedBox(height: 16),
        _dashedDivider(),
        const SizedBox(height: 16),

        // Total
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('TOTAL BAYAR', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 13, letterSpacing: 1)),
          Text(
            _fmtRupiah(trx['totalWithFee'] ?? trx['price']),
            style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 18),
          ),
        ]),
        const SizedBox(height: 16),

        // Tombol salin ID
        GestureDetector(
          onTap: () {
            Clipboard.setData(ClipboardData(text: trx['requestId'] ?? ''));
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('ID Transaksi disalin'), backgroundColor: Color(0xFF0D1520)),
            );
          },
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 11),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _border),
            ),
            child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.copy_rounded, color: Colors.white38, size: 14),
              SizedBox(width: 6),
              Text('Salin ID Transaksi', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _buildStatusDetail(Map trx, String status) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        if (status == 'rejected' && trx['rejectedReason'] != null) ...[
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _red.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _red.withOpacity(0.25)),
            ),
            child: Row(children: [
              const Icon(Icons.info_outline_rounded, color: _red, size: 16),
              const SizedBox(width: 8),
              Expanded(child: Text(
                'Alasan: ${trx['rejectedReason']}',
                style: const TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontSize: 12),
              )),
            ]),
          ),
          const SizedBox(height: 12),
        ],
        _strukRow('ID Request', (trx['requestId'] ?? '-').toString(), copyable: true),
        _strukRow('Paket', trx['role'] ?? '-'),
        _strukRow('Durasi', trx['durationType'] ?? '-'),
        _strukRow('Total', _fmtRupiah(trx['totalWithFee'] ?? trx['price'])),
        _strukRow('Status', _statusLabel(status), color: _statusColor(status)),
      ]),
    );
  }

  Widget _strukRow(String label, String value, {bool copyable = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
        GestureDetector(
          onTap: copyable ? () {
            Clipboard.setData(ClipboardData(text: value));
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('$label disalin'), backgroundColor: const Color(0xFF0D1520)),
            );
          } : null,
          child: Row(children: [
            Text(
              value,
              style: TextStyle(
                color: color ?? Colors.white,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
            if (copyable) ...[
              const SizedBox(width: 4),
              const Icon(Icons.copy_rounded, color: Colors.white24, size: 12),
            ],
          ]),
        ),
      ]),
    );
  }

  Widget _strukRowIcon(String label, String value, IconData icon, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
        Row(children: [
          Icon(icon, color: color, size: 13),
          const SizedBox(width: 4),
          Text(value, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 12)),
        ]),
      ]),
    );
  }

  Widget _dashedDivider() {
    return LayoutBuilder(builder: (context, constraints) {
      const dashW = 6.0, gap = 4.0;
      final count = (constraints.maxWidth / (dashW + gap)).floor();
      return Row(children: List.generate(count, (_) => Container(
        width: dashW, height: 1,
        margin: const EdgeInsets.only(right: gap),
        color: Colors.white12,
      )));
    });
  }
}

// ═══════════════════════════════════════════════════════════════
//  VOUCHER REDEEM BOTTOM SHEET
// ═══════════════════════════════════════════════════════════════

class VoucherRedeemSheet extends StatefulWidget {
  final String username;
  final String sessionKey;
  const VoucherRedeemSheet({super.key, required this.username, required this.sessionKey});

  @override
  State<VoucherRedeemSheet> createState() => _VoucherRedeemSheetState();
}

class _VoucherRedeemSheetState extends State<VoucherRedeemSheet> {
  static const _bg    = Color(0xFF0D1520);
  static const _red   = Color(0xFFFF1744);
  static const _green = Color(0xFF22C55E);
  static const _border = Color(0xFF1C2A3A);

  final _ctrl = TextEditingController();
  bool _loading = false;
  String? _msg;
  bool _success = false;

  Future<void> _redeem() async {
    final code = _ctrl.text.trim();
    if (code.isEmpty) return;
    setState(() { _loading = true; _msg = null; });
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/voucher/redeem'),
        headers: {'Content-Type': 'application/json', 'x-session-key': widget.sessionKey},
        body: jsonEncode({'code': code, 'username': widget.username}),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      setState(() {
        _success = data['success'] == true;
        _msg = data['message'] ?? '-';
        _loading = false;
      });
    } catch (_) {
      setState(() { _loading = false; _msg = 'Gagal terhubung ke server'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 24),
      decoration: const BoxDecoration(
        color: _bg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        // Handle
        Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 20),
        // Icon
        Container(
          width: 56, height: 56,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _red.withOpacity(0.1),
            border: Border.all(color: _red.withOpacity(0.3)),
          ),
          child: const Icon(Icons.local_offer_rounded, color: _red, size: 24),
        ),
        const SizedBox(height: 12),
        const Text('Tukar Voucher', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 4),
        const Text('Masukkan kode voucher kamu', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
        const SizedBox(height: 20),

        // Input
        TextField(
          controller: _ctrl,
          textCapitalization: TextCapitalization.characters,
          style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, letterSpacing: 3, fontSize: 16),
          textAlign: TextAlign.center,
          decoration: InputDecoration(
            hintText: 'KODE-VOUCHER',
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.15), fontFamily: 'Rajdhani', letterSpacing: 3, fontSize: 14),
            filled: true,
            fillColor: Colors.white.withOpacity(0.04),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: _border),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: _border),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: _red, width: 1.5),
            ),
          ),
        ),

        if (_msg != null) ...[
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: (_success ? _green : _red).withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: (_success ? _green : _red).withOpacity(0.3)),
            ),
            child: Row(children: [
              Icon(_success ? Icons.check_circle_rounded : Icons.error_rounded,
                color: _success ? _green : _red, size: 16),
              const SizedBox(width: 8),
              Expanded(child: Text(_msg!, style: TextStyle(
                color: _success ? _green : _red,
                fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 12,
              ))),
            ]),
          ),
        ],

        const SizedBox(height: 16),

        // Button
        GestureDetector(
          onTap: _loading ? null : _redeem,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 13),
            decoration: BoxDecoration(
              gradient: _loading ? null : const LinearGradient(colors: [_red, Color(0xFFB71C1C)]),
              color: _loading ? Colors.white12 : null,
              borderRadius: BorderRadius.circular(14),
              boxShadow: _loading ? [] : [BoxShadow(color: _red.withOpacity(0.35), blurRadius: 16, offset: const Offset(0, 6))],
            ),
            child: Center(child: _loading
              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : const Text('TUKAR SEKARANG', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 2)),
            ),
          ),
        ),
      ]),
    );
  }
}
