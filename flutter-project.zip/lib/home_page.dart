// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'package:flutter/material.dart';
import 'config.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'dart:ui';

class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> with TickerProviderStateMixin {
  final targetController = TextEditingController();

  late AnimationController _buttonController;
  late AnimationController _glowController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;

  late VideoPlayerController _videoController;
  bool _videoInitialized = false;

  // ── State ──────────────────────────────────────────────────
  String selectedBugId = "";
  int _selectedBugIndex = 0;
  String _senderType = 'private'; // default private, global hanya VIP+
  List<Map<String, dynamic>> _privateSenders = [];
  String? _selectedPrivateSender;
  bool _loadingSenders = false;
  bool _isSending = false;
  bool _isSuccess = false;

  static const _bg       = Color(0xFF080D14);
  static const _card     = Color(0xFF0D1520);
  static const _border   = Color(0xFF1A2840);
  static const _cyan     = Color(0xFF00E5FF);
  static const _red      = Color(0xFFFF1744);
  static const _green    = Color(0xFF00E676);

  @override
  void initState() {
    super.initState();
    _buttonController = AnimationController(vsync: this, duration: const Duration(milliseconds: 150));
    _glowController   = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _scaleAnimation   = Tween<double>(begin: 1.0, end: 0.95).animate(CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut));
    _glowAnimation    = Tween<double>(begin: 0.5, end: 1.0).animate(CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));
    _initializeVideoController();
    _setDefaultBug();
    _fetchPrivateSenders();
  }

  void _setDefaultBug() {
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'] ?? '';
    }
  }

  void _initializeVideoController() {
    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _videoInitialized = true);
          _videoController.setLooping(true);
          _videoController.play();
          _videoController.setVolume(0);
        }
      });
  }

  Future<void> _fetchPrivateSenders() async {
    setState(() => _loadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        '${AppConfig.baseUrl}/api/whatsapp/mySender?key=${widget.sessionKey}&type=private'
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final senders = List<Map<String, dynamic>>.from(data['private'] ?? data['senders'] ?? []);
        if (mounted) setState(() { _privateSenders = senders; });
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingSenders = false);
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    if (_isSending) return;
    setState(() => _isSending = true);
    _buttonController.forward().then((_) => _buttonController.reverse());

    final rawInput = targetController.text.trim();
    final target   = formatPhoneNumber(rawInput);
    final key      = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("❌ INVALID NUMBER", "Gunakan nomor internasional (628xxx), bukan 08xxx.");
      setState(() => _isSending = false);
      return;
    }
    if (selectedBugId.isEmpty) {
      _showAlert("❌ PILIH BUG", "Pilih bug terlebih dahulu.");
      setState(() => _isSending = false);
      return;
    }
    if (_senderType == 'private' && (_selectedPrivateSender == null || _selectedPrivateSender!.isEmpty)) {
      _showAlert("❌ PILIH SENDER", "Pilih sender private terlebih dahulu.");
      setState(() => _isSending = false);
      return;
    }

    try {
      String url = '${AppConfig.baseUrl}/api/whatsapp/sendBug?key=$key&target=$target&bug=$selectedBugId&senderType=$_senderType';
      if (_senderType == 'private' && _selectedPrivateSender != null) {
        url += '&senderNumber=$_selectedPrivateSender';
      }
      final res  = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);
      if (data['cooldown'] == true) {
        _showAlert("⏳ COOLDOWN", "Tunggu ${data['wait'] ?? 'beberapa'} detik lagi.");
      } else if (data['valid'] == false) {
        _showAlert("❌ KEY INVALID", "Login ulang.");
      } else {
        setState(() => _isSuccess = true);
        _showSuccessPopup(target);
      }
    } catch (_) {
      _showAlert("❌ ERROR", "Terjadi kesalahan koneksi.");
    } finally {
      if (mounted) setState(() { _isSending = false; if (!_isSuccess) {} });
    }
  }

  void _showSuccessPopup(String target) {
    showDialog(context: context, barrierDismissible: false, builder: (context) => SuccessVideoDialog(
      target: target,
      onDismiss: () { Navigator.of(context).pop(); setState(() => _isSuccess = false); },
    ));
  }

  void _showAlert(String title, String msg) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: _red)),
      title: Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
      content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'Rajdhani')),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK", style: TextStyle(color: _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)))]
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _buildHeader(),
            const SizedBox(height: 16),
            _buildVideoHeader(),
            const SizedBox(height: 20),
            _buildLabel("TARGET DESTINATION"),
            _buildTargetInput(),
            const SizedBox(height: 20),
            _buildLabel("SENDER TYPE"),
            _buildSenderSelector(),
            if (_senderType == 'private') ...[
              const SizedBox(height: 12),
              _buildPrivateSenderPicker(),
            ],
            const SizedBox(height: 20),
            _buildLabel("SELECT BUG"),
            _buildBugSlider(),
            const SizedBox(height: 28),
            _buildAttackButton(),
            const SizedBox(height: 20),
          ]),
        ),
      ),
    );
  }

  // ── HEADER ─────────────────────────────────────────────────
  Widget _buildHeader() {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
          child: Row(children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 38, height: 38,
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
                child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70, size: 16),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ShaderMask(
                shaderCallback: (b) => const LinearGradient(colors: [_red, Color(0xFFFF5722)]).createShader(b),
                child: const Text("BUG NOMOR", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900, fontFamily: "Rajdhani", letterSpacing: 2)),
              ),
              Text("Kirim serangan ke target", style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11, fontFamily: "Rajdhani")),
            ])),
            AnimatedBuilder(
              animation: _glowAnimation,
              builder: (_, __) => Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _red.withValues(alpha: 0.1),
                  border: Border.all(color: _red.withValues(alpha: _glowAnimation.value * 0.7)),
                  boxShadow: [BoxShadow(color: _red.withValues(alpha: 0.2 * _glowAnimation.value), blurRadius: 12)],
                ),
                child: const Icon(FontAwesomeIcons.bomb, color: _red, size: 18),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  // ── VIDEO ───────────────────────────────────────────────────
  Widget _buildVideoHeader() {
    return Container(
      height: 170, width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _red.withValues(alpha: 0.3)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: _videoInitialized
          ? FittedBox(fit: BoxFit.cover, child: SizedBox(width: _videoController.value.size.width, height: _videoController.value.size.height, child: VideoPlayer(_videoController)))
          : const Center(child: CircularProgressIndicator(color: _red, strokeWidth: 2)),
      ),
    );
  }

  // ── LABEL ───────────────────────────────────────────────────
  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Row(children: [
        Container(width: 3, height: 14, decoration: BoxDecoration(color: _cyan, borderRadius: BorderRadius.circular(2))),
        const SizedBox(width: 8),
        Text(text, style: const TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontFamily: 'Rajdhani')),
      ]),
    );
  }

  // ── TARGET INPUT ────────────────────────────────────────────
  Widget _buildTargetInput() {
    return Container(
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border),
        boxShadow: [BoxShadow(color: _cyan.withValues(alpha: 0.05), blurRadius: 10)],
      ),
      child: TextField(
        controller: targetController,
        keyboardType: TextInputType.phone,
        style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 15),
        decoration: InputDecoration(
          hintText: "628xxxxxxxxxx",
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.2), fontFamily: 'Rajdhani'),
          prefixIcon: const Icon(FontAwesomeIcons.crosshairs, color: _red, size: 16),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 15),
        ),
      ),
    );
  }

  // ── SENDER SELECTOR ─────────────────────────────────────────
  Widget _buildSenderSelector() {
    return Row(children: [
      if (['vip', 'owner', 'partner', 'staff', 'high admin', 'dev'].contains(widget.role.toLowerCase())) ...[
        Expanded(child: _senderCard(
          label: 'GLOBAL',
          sub: 'Sender publik',
          icon: Icons.public_rounded,
          color: _cyan,
          selected: _senderType == 'global',
          onTap: () => setState(() { _senderType = 'global'; _selectedPrivateSender = null; }),
        )),
        const SizedBox(width: 12),
      ],
      Expanded(child: _senderCard(
        label: 'PRIVATE',
        sub: 'Session sendiri',
        icon: Icons.person_rounded,
        color: _red,
        selected: _senderType == 'private',
        onTap: () { setState(() => _senderType = 'private'); _fetchPrivateSenders(); },
      )),
    ]);
  }

  Widget _senderCard({required String label, required String sub, required IconData icon, required Color color, required bool selected, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: selected ? color.withValues(alpha: 0.12) : _card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? color : _border, width: selected ? 1.5 : 1),
          boxShadow: selected ? [BoxShadow(color: color.withValues(alpha: 0.2), blurRadius: 12, spreadRadius: 1)] : [],
        ),
        child: Column(children: [
          Icon(icon, color: selected ? color : Colors.white38, size: 26),
          const SizedBox(height: 8),
          Text(label, style: TextStyle(color: selected ? color : Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1)),
          Text(sub, style: TextStyle(color: Colors.white.withOpacity(0.3), fontFamily: 'Rajdhani', fontSize: 10)),
          if (selected) ...[
            const SizedBox(height: 6),
            Container(width: 24, height: 2, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2))),
          ],
        ]),
      ),
    );
  }

  // ── PRIVATE SENDER PICKER ───────────────────────────────────
  Widget _buildPrivateSenderPicker() {
    if (_loadingSenders) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
        child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: _cyan, strokeWidth: 2)),
          SizedBox(width: 10),
          Text("Memuat sender...", style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani')),
        ]),
      );
    }
    if (_privateSenders.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
        child: Row(children: [
          const Icon(Icons.info_outline, color: Colors.white38, size: 16),
          const SizedBox(width: 8),
          const Text("Belum ada sender private aktif.", style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
          const Spacer(),
          GestureDetector(onTap: _fetchPrivateSenders, child: const Icon(Icons.refresh_rounded, color: _cyan, size: 18)),
        ]),
      );
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedPrivateSender,
          dropdownColor: _card,
          isExpanded: true,
          hint: const Text("Pilih nomor sender", style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani')),
          icon: const Icon(Icons.arrow_drop_down_rounded, color: _cyan),
          items: _privateSenders.map((s) {
            final num = s['number'] ?? s['name'] ?? s['sessionName'] ?? '';
            return DropdownMenuItem<String>(
              value: num.toString(),
              child: Row(children: [
                const Icon(Icons.phone_rounded, color: _cyan, size: 14),
                const SizedBox(width: 8),
                Text(num.toString(), style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 13)),
              ]),
            );
          }).toList(),
          onChanged: (v) => setState(() => _selectedPrivateSender = v),
        ),
      ),
    );
  }

  // ── BUG SLIDER ──────────────────────────────────────────────
  Widget _buildBugSlider() {
    if (widget.listBug.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
        child: const Center(child: Text("Tidak ada bug tersedia.", style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani'))),
      );
    }

    final List<Color> bugColors = [
      const Color(0xFFE91E63), const Color(0xFF9C27B0), const Color(0xFF00BCD4),
      const Color(0xFFFF5722), const Color(0xFF4CAF50), const Color(0xFF2196F3),
      const Color(0xFFFF9800), const Color(0xFFE91E63),
    ];

    return SizedBox(
      height: 130,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: widget.listBug.length,
        itemBuilder: (context, index) {
          final bug      = widget.listBug[index];
          final bugId    = bug['bug_id'] ?? '';
          final bugName  = bug['bug_name'] ?? 'Bug';
          final bugTag   = bug['category'] ?? bug['tag'] ?? '';
          final selected = selectedBugId == bugId;
          final color    = bugColors[index % bugColors.length];

          return GestureDetector(
            onTap: () => setState(() { selectedBugId = bugId; _selectedBugIndex = index; }),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 110,
              margin: EdgeInsets.only(left: index == 0 ? 0 : 10, right: index == widget.listBug.length - 1 ? 0 : 0),
              decoration: BoxDecoration(
                color: selected ? color.withValues(alpha: 0.18) : _card,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: selected ? color : _border, width: selected ? 1.8 : 1),
                boxShadow: selected ? [BoxShadow(color: color.withValues(alpha: 0.3), blurRadius: 14, spreadRadius: 1)] : [],
              ),
              child: Stack(children: [
                // Dekorasi lingkaran bg
                Positioned(right: -15, top: -15, child: Container(
                  width: 60, height: 60,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: color.withValues(alpha: selected ? 0.12 : 0.04)),
                )),
                Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    // Icon + checkmark
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: selected ? 0.25 : 0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(FontAwesomeIcons.shieldHalved, color: color, size: 16),
                      ),
                      if (selected)
                        Container(
                          width: 20, height: 20,
                          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                          child: const Icon(Icons.check_rounded, color: Colors.white, size: 13),
                        ),
                    ]),
                    const SizedBox(height: 8),
                    // Nama bug
                    Text(
                      bugName.toString().toUpperCase(),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: selected ? Colors.white : Colors.white70,
                        fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 0.5,
                      ),
                    ),
                    if (bugTag.isNotEmpty)
                      Container(
                        margin: const EdgeInsets.only(top: 4),
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(bugTag.toString(), style: TextStyle(color: color, fontSize: 8, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
                      ),
                  ]),
                ),
              ]),
            ),
          );
        },
      ),
    );
  }

  // ── ATTACK BUTTON ───────────────────────────────────────────
  Widget _buildAttackButton() {
    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, _) => Transform.scale(
        scale: _scaleAnimation.value,
        child: GestureDetector(
          onTap: _isSending ? null : _sendBug,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: double.infinity, height: 58,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: _isSending
                ? const LinearGradient(colors: [Color(0xFF1A1A1A), Color(0xFF2A2A2A)])
                : const LinearGradient(colors: [Color(0xFFFF1744), Color(0xFFFF5722)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              border: Border.all(color: _isSending ? _border : _red.withValues(alpha: 0.5)),
              boxShadow: _isSending ? [] : [BoxShadow(color: _red.withValues(alpha: 0.4), blurRadius: 20, spreadRadius: 1)],
            ),
            child: Center(child: _isSending
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : Row(mainAxisAlignment: MainAxisAlignment.center, children: const [
                  Icon(FontAwesomeIcons.bolt, color: Colors.white, size: 16),
                  SizedBox(width: 10),
                  Text("INITIALIZE ATTACK", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 2, fontFamily: 'Rajdhani', fontSize: 15)),
                ]),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _buttonController.dispose();
    _glowController.dispose();
    _videoController.dispose();
    targetController.dispose();
    super.dispose();
  }
}

// ═══════════════════════════════════════════════════════════════
//  SUCCESS DIALOG
// ═══════════════════════════════════════════════════════════════
class SuccessVideoDialog extends StatefulWidget {
  final String target;
  final VoidCallback onDismiss;
  const SuccessVideoDialog({super.key, required this.target, required this.onDismiss});
  @override
  State<SuccessVideoDialog> createState() => _SuccessVideoDialogState();
}

class _SuccessVideoDialogState extends State<SuccessVideoDialog> {
  late VideoPlayerController _ctrl;
  bool _showInfo = false;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();
    _ctrl = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        setState(() => _videoReady = true);
        _ctrl.play();
        _ctrl.addListener(() {
          if (_ctrl.value.position >= _ctrl.value.duration) {
            if (mounted) setState(() => _showInfo = true);
          }
        });
      });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFF0D1520),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFFFF1744))),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        if (!_showInfo && _videoReady)
          SizedBox(height: 200, child: VideoPlayer(_ctrl))
        else ...[
          const Icon(Icons.check_circle_rounded, color: Color(0xFF00E676), size: 64),
          const SizedBox(height: 10),
          Text("ATTACK SENT!", style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 18)),
          const SizedBox(height: 4),
          Text("→ ${widget.target}", style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 13)),
          const SizedBox(height: 20),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF1744), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 10)),
            onPressed: widget.onDismiss,
            child: const Text("DONE", style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14)),
          ),
        ],
      ]),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }
}
