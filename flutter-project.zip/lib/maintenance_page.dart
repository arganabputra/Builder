import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';
import 'package:url_launcher/url_launcher.dart';
import 'config.dart';

class MaintenancePage extends StatefulWidget {
  final String mode;
  final String message;
  final String version;
  final String downloadUrl;
  final String infoUrl;
  final String expiredDate;
  final List<String> changelog;

  const MaintenancePage({
    super.key,
    required this.mode,
    required this.message,
    this.version = '',
    this.downloadUrl = '',
    this.infoUrl = '',
    this.expiredDate = '',
    this.changelog = const [],
  });

  @override
  State<MaintenancePage> createState() => _MaintenancePageState();
}

class _MaintenancePageState extends State<MaintenancePage>
    with TickerProviderStateMixin {

  static const _red    = Color(0xFFFF1744);
  static const _bg     = Color(0xFF04070D);
  static const _card   = Color(0xFF080E1A);

  late AnimationController _pulseCtrl;
  late AnimationController _fadeCtrl;
  late Animation<double> _pulseAnim;
  late Animation<double> _fadeAnim;

  Timer? _pollTimer;

  double _downloadProgress = 0;
  bool _isDownloading = false;
  bool _downloadDone = false;
  String _downloadPath = '';

  bool get _isUpdate => widget.mode == 'update';

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _fadeCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _pulseAnim = Tween<double>(begin: 0.55, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _fadeAnim  = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
    _startPolling();
  }

  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 10), (_) async {
      try {
        final res = await http
            .get(Uri.parse('${AppConfig.baseUrl}/api/maintenance/status'))
            .timeout(const Duration(seconds: 5));
        if (!mounted) return;
        final data = jsonDecode(res.body);
        final mode = data['data']?['mode'] ?? data['mode'] ?? 'normal';
        if (mode == 'normal') {
          _pollTimer?.cancel();
          Navigator.of(context).pushNamedAndRemoveUntil('/welcome', (r) => false);
        }
      } catch (_) {}
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _pulseCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  Future<void> _downloadApk() async {
    if (widget.downloadUrl.isEmpty) return;
    setState(() { _isDownloading = true; _downloadProgress = 0; _downloadDone = false; });
    try {
      final client = http.Client();
      final request = http.Request('GET', Uri.parse(widget.downloadUrl));
      final response = await client.send(request);
      final total = response.contentLength ?? 0;
      int received = 0;
      final dir = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/dominus_update.apk');
      final sink = file.openWrite();
      await response.stream.listen((chunk) {
        sink.add(chunk);
        received += chunk.length;
        if (total > 0 && mounted) setState(() => _downloadProgress = received / total);
      }).asFuture();
      await sink.flush();
      await sink.close();
      client.close();
      setState(() { _isDownloading = false; _downloadDone = true; _downloadPath = file.path; });
    } catch (e) {
      setState(() => _isDownloading = false);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal download: $e'), backgroundColor: _red),
      );
    }
  }

  Future<void> _installApk() async {
    if (_downloadPath.isEmpty) return;
    await OpenFile.open(_downloadPath);
  }

  Future<void> _openUrl(String url) async {
    if (url.isEmpty) return;
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tidak bisa membuka URL'), backgroundColor: _red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: _bg,
        body: Stack(children: [

          // Dot matrix background — static, premium
          Positioned.fill(child: CustomPaint(painter: _DotPainter())),

          // Ambient glow top-center
          Positioned(
            top: -120, left: 0, right: 0,
            child: AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Container(
                height: 320,
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    colors: [
                      _red.withOpacity(0.13 * _pulseAnim.value),
                      Colors.transparent,
                    ],
                    radius: 0.7,
                  ),
                ),
              ),
            ),
          ),

          // Ambient glow bottom
          Positioned(
            bottom: -100, left: 0, right: 0,
            child: Container(
              height: 260,
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  colors: [_red.withOpacity(0.05), Colors.transparent],
                  radius: 0.8,
                ),
              ),
            ),
          ),

          // Content
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 22),
                child: Column(children: [
                  const SizedBox(height: 40),

                  // ── BANNER — replaces top label + icon circle ──
                  AnimatedBuilder(
                    animation: _pulseAnim,
                    builder: (_, __) => Container(
                      width: double.infinity,
                      height: 180,
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _red.withOpacity(0.25 + 0.15 * _pulseAnim.value), width: 1.2),
                        boxShadow: [
                          BoxShadow(color: _red.withOpacity(0.15 * _pulseAnim.value), blurRadius: 30, spreadRadius: 4),
                        ],
                      ),
                      child: Stack(fit: StackFit.expand, children: [
                        Image.asset(
                          'assets/images/banner.jpg',
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: _card,
                            child: Icon(
                              _isUpdate ? Icons.system_update_rounded : Icons.construction_rounded,
                              color: _red, size: 40,
                            ),
                          ),
                        ),
                        // dark gradient overlay so text below stays readable / banner blends with theme
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Colors.transparent, _bg.withOpacity(0.85)],
                            ),
                          ),
                        ),
                      ]),
                    ),
                  ),

                  const SizedBox(height: 28),

                  // ── TITLE — dengan efek glitch RGB split berkala ──
                  _GlitchText(
                    text: _isUpdate ? 'UPDATE!' : 'MAINTENANCE!',
                    style: const TextStyle(
                      fontFamily: 'Rajdhani', fontSize: 36,
                      fontWeight: FontWeight.w900,
                      color: Colors.white, letterSpacing: 3,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    width: 60, height: 2.5,
                    decoration: BoxDecoration(
                      color: _red,
                      borderRadius: BorderRadius.circular(2),
                      boxShadow: [BoxShadow(color: _red.withOpacity(0.6), blurRadius: 8)],
                    ),
                  ),

                  const SizedBox(height: 28),

                  // ── INFO CARD ──
                  Padding(
                    padding: const EdgeInsets.only(top: 68),
                    child: Stack(clipBehavior: Clip.none, children: [
                      // ── CARD ──
                      _card_(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        _divRow(
                          _isUpdate ? Icons.info_rounded : Icons.warning_amber_rounded,
                          _isUpdate ? 'INFO UPDATE' : 'KETERANGAN',
                        ),
                        const SizedBox(height: 12),
                        Text(
                          widget.message.isNotEmpty
                              ? widget.message
                              : (_isUpdate ? 'Versi baru tersedia. Segera update untuk fitur terbaru.' : 'Sedang dalam perbaikan. Mohon tunggu.'),
                          style: TextStyle(color: Colors.white.withOpacity(0.75), fontFamily: 'Rajdhani', fontSize: 13, height: 1.6),
                        ),
                        if (widget.version.isNotEmpty) ...[
                          const SizedBox(height: 14),
                          _infoRow(Icons.tag_rounded, 'Versi', widget.version),
                        ],
                        if (widget.expiredDate.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          _infoRow(Icons.schedule_rounded, 'Estimasi', widget.expiredDate),
                        ],
                      ])),
                      // ── MASCOT — cuma tangan yang nyentuh top edge card, badan full di atas card ──
                      Positioned(
                        top: -97, right: -4,
                        child: Image.asset(
                          'assets/images/mascot.png',
                          width: 148,
                          errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                        ),
                      ),
                    ]),
                  ),


                  // ── CHANGELOG (update only) ──
                  if (_isUpdate && widget.changelog.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    _card_(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      _divRow(Icons.list_alt_rounded, 'YANG BARU'),
                      const SizedBox(height: 12),
                      ...widget.changelog.map((c) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Container(
                            width: 6, height: 6, margin: const EdgeInsets.only(top: 5, right: 10),
                            decoration: BoxDecoration(shape: BoxShape.circle, color: _red,
                              boxShadow: [BoxShadow(color: _red.withOpacity(0.5), blurRadius: 4)],
                            ),
                          ),
                          Expanded(child: Text(c, style: TextStyle(color: Colors.white.withOpacity(0.75), fontFamily: 'Rajdhani', fontSize: 13, height: 1.5))),
                        ]),
                      )),
                    ])),
                  ],

                  // ── STATUS ROW (maintenance only) ──
                  if (!_isUpdate) ...[
                    const SizedBox(height: 12),
                    _card_(child: Row(children: [
                      AnimatedBuilder(
                        animation: _pulseAnim,
                        builder: (_, __) => Container(
                          width: 8, height: 8,
                          margin: const EdgeInsets.only(right: 12),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _red,
                            boxShadow: [BoxShadow(color: _red.withOpacity(_pulseAnim.value), blurRadius: 8, spreadRadius: 1)],
                          ),
                        ),
                      ),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('Status Server', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11, letterSpacing: 1)),
                        const SizedBox(height: 2),
                        const Text('Sedang dalam perbaikan', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 13)),
                      ])),
                    ])),
                  ],

                  const SizedBox(height: 24),

                  // ── DOWNLOAD BUTTON / PROGRESS ──
                  if (_isUpdate && widget.downloadUrl.isNotEmpty) ...[
                    if (_isDownloading) ...[
                      _card_(child: Column(children: [
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          const Text('Mengunduh APK...', style: TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontSize: 13)),
                          Text('${(_downloadProgress * 100).toStringAsFixed(0)}%',
                            style: const TextStyle(color: _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 14)),
                        ]),
                        const SizedBox(height: 12),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: _downloadProgress,
                            backgroundColor: Colors.white10,
                            valueColor: const AlwaysStoppedAnimation(_red),
                            minHeight: 6,
                          ),
                        ),
                      ])),
                    ] else if (_downloadDone) ...[
                      _actionBtn(
                        icon: Icons.install_mobile_rounded,
                        label: 'INSTALL SEKARANG',
                        color: Colors.green,
                        onTap: _installApk,
                        pulse: _pulseAnim,
                      ),
                    ] else ...[
                      _actionBtn(
                        icon: Icons.download_rounded,
                        label: 'DOWNLOAD UPDATE',
                        color: _red,
                        onTap: _downloadApk,
                        pulse: _pulseAnim,
                      ),
                    ],
                    const SizedBox(height: 12),
                  ],

                  if (widget.infoUrl.isNotEmpty) ...[
                    GestureDetector(
                      onTap: () => _openUrl(widget.infoUrl),
                      child: Container(
                        width: double.infinity, height: 48,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white.withOpacity(0.12)),
                        ),
                        child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.open_in_new_rounded, color: Colors.white38, size: 16),
                          SizedBox(width: 8),
                          Text('Informasi Lengkap', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 13, letterSpacing: 0.8)),
                        ]),
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],

                  const SizedBox(height: 16),

                  // Footer
                  Text(
                    _isUpdate
                      ? 'Update diperlukan untuk melanjutkan.\nSilakan download versi terbaru di atas.'
                      : 'Mohon bersabar, kami sedang memperbaiki\nuntuk pengalaman yang lebih baik.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 11, height: 1.7, fontFamily: 'Rajdhani', letterSpacing: 0.4),
                  ),

                  const SizedBox(height: 32),
                ]),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  // Card wrapper
  Widget _card_({required Widget child}) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: _card,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: Colors.white.withOpacity(0.07)),
      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 4))],
    ),
    child: child,
  );

  // Section divider row
  Widget _divRow(IconData icon, String label) => Row(children: [
    Icon(icon, size: 14, color: _red.withOpacity(0.8)),
    const SizedBox(width: 8),
    Text(label, style: const TextStyle(color: _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 11, letterSpacing: 1.8)),
    const SizedBox(width: 10),
    Expanded(child: Container(height: 1, color: Colors.white.withOpacity(0.06))),
  ]);

  // Info row
  Widget _infoRow(IconData icon, String label, String value) => Row(children: [
    Icon(icon, size: 14, color: _red.withOpacity(0.6)),
    const SizedBox(width: 10),
    SizedBox(width: 64, child: Text(label, style: TextStyle(color: Colors.white.withOpacity(0.38), fontSize: 12, fontFamily: 'Rajdhani'))),
    Text(': ', style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 12)),
    Expanded(child: Text(value, style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 13, fontFamily: 'Rajdhani', fontWeight: FontWeight.w600))),
  ]);

  // Action button
  Widget _actionBtn({required IconData icon, required String label, required Color color, required VoidCallback onTap, required Animation<double> pulse}) {
    return AnimatedBuilder(
      animation: pulse,
      builder: (_, __) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: double.infinity, height: 54,
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.5 + 0.2 * pulse.value), width: 1.2),
            boxShadow: [BoxShadow(color: color.withOpacity(0.2 * pulse.value), blurRadius: 20)],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 10),
            Text(label, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1.5)),
          ]),
        ),
      ),
    );
  }
}

// ── DOT MATRIX BACKGROUND — static, no rotation ──
class _DotPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFFF1744).withOpacity(0.045);
    const spacing = 22.0;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), 1, paint);
      }
    }
  }
  @override
  bool shouldRepaint(_DotPainter old) => false;
}

// ── GLITCH TEXT — efek RGB split / error yang muncul berkala tiap beberapa detik ──
class _GlitchText extends StatefulWidget {
  final String text;
  final TextStyle style;
  const _GlitchText({required this.text, required this.style});

  @override
  State<_GlitchText> createState() => _GlitchTextState();
}

class _GlitchTextState extends State<_GlitchText> {
  Timer? _timer;
  bool _glitching = false;
  final _rand = Random();

  @override
  void initState() {
    super.initState();
    _scheduleGlitch();
  }

  void _scheduleGlitch() {
    // nunggu 3–6 detik random, terus glitch sebentar (~250ms)
    _timer = Timer(Duration(milliseconds: 3000 + _rand.nextInt(3000)), () async {
      if (!mounted) return;
      setState(() => _glitching = true);
      await Future.delayed(const Duration(milliseconds: 260));
      if (!mounted) return;
      setState(() => _glitching = false);
      _scheduleGlitch();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_glitching) {
      return Text(widget.text, style: widget.style);
    }
    // 3 layer: cyan geser kiri, merah geser kanan, putih asli di tengah — efek RGB split
    return Stack(children: [
      Transform.translate(
        offset: const Offset(-3, 0),
        child: Text(widget.text, style: widget.style.copyWith(color: const Color(0xFF00E5FF).withOpacity(0.75))),
      ),
      Transform.translate(
        offset: const Offset(3, 1),
        child: Text(widget.text, style: widget.style.copyWith(color: const Color(0xFFFF1744).withOpacity(0.75))),
      ),
      Text(widget.text, style: widget.style),
    ]);
  }
}

