import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'config.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SellerPage extends StatefulWidget {
  final String keyToken;
  const SellerPage({super.key, required this.keyToken});
  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> with TickerProviderStateMixin {
  // Controllers
  final _newUser  = TextEditingController();
  final _newPass  = TextEditingController();
  final _days     = TextEditingController();
  final _editUser = TextEditingController();
  final _editDays = TextEditingController();

  // State
  bool _loading = false;
  bool _loadingAccounts = false;
  List<Map<String, dynamic>> _accounts = [];
  int _totalAccounts = 0;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  // Theme
  static const _bg    = Color(0xFF05080F);
  static const _card  = Color(0xFF0C1220);
  static const _red   = Color(0xFFFF1744);
  static const _border = Color(0xFF1A2235);

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
    _loadAccounts();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _newUser.dispose(); _newPass.dispose(); _days.dispose();
    _editUser.dispose(); _editDays.dispose();
    super.dispose();
  }

  // ── API ──────────────────────────────────────────────────────────
  Future<void> _loadAccounts() async {
    setState(() => _loadingAccounts = true);
    try {
      final res = await http.get(Uri.parse(
        '${AppConfig.baseUrl}/api/user/listUsers?key=${widget.keyToken}&scope=own'
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true && mounted) {
        setState(() {
          _accounts = List<Map<String, dynamic>>.from(data['users'] ?? []);
          _totalAccounts = _accounts.length;
        });
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingAccounts = false);
  }

  Future<void> _deleteAccount(String username) async {
    try {
      final res = await http.get(Uri.parse(
        '${AppConfig.baseUrl}/api/user/deleteUser?key=${widget.keyToken}&username=$username'
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['success'] == true || data['deleted'] == true) {
        _snack('Akun $username dihapus');
        _loadAccounts();
      } else {
        _snack(data['message'] ?? 'Gagal hapus', isErr: true);
      }
    } catch (_) {
      _snack('Koneksi error', isErr: true);
    }
  }

  void _confirmDelete(String username) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: Colors.red.withOpacity(0.3))),
      title: const Text('Hapus Akun?', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 16)),
      content: Text('Akun "$username" akan dihapus permanen.', style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani'))),
        TextButton(
          onPressed: () { Navigator.pop(context); _deleteAccount(username); },
          child: const Text('Hapus', style: TextStyle(color: Color(0xFFF87171), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700)),
        ),
      ],
    ));
  }

  Future<void> _create() async {
    final u = _newUser.text.trim(), p = _newPass.text.trim(), d = _days.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _snack('Semua field wajib diisi', isErr: true); return;
    }
    setState(() => _loading = true);
    try {
      final res = await http.get(Uri.parse(
        '${AppConfig.baseUrl}/api/user/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d'
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _snack('Akun berhasil dibuat!');
        _newUser.clear(); _newPass.clear(); _days.clear();
        if (mounted) Navigator.pop(context);
      } else {
        _snack(data['message'] ?? 'Gagal membuat akun', isErr: true);
      }
    } catch (e) {
      _snack('Koneksi error', isErr: true);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _edit() async {
    final u = _editUser.text.trim(), d = _editDays.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _snack('Semua field wajib diisi', isErr: true); return;
    }
    setState(() => _loading = true);
    try {
      final res = await http.get(Uri.parse(
        '${AppConfig.baseUrl}/api/user/editDuration?key=${widget.keyToken}&targetUser=$u&addDay=$d'
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _snack('Durasi berhasil diubah!');
        _editUser.clear(); _editDays.clear();
        if (mounted) Navigator.pop(context);
      } else {
        _snack(data['message'] ?? 'Gagal ubah durasi', isErr: true);
      }
    } catch (e) {
      _snack('Koneksi error', isErr: true);
    }
    if (mounted) setState(() => _loading = false);
  }

  void _snack(String msg, {bool isErr = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w600, color: Colors.white)),
      backgroundColor: isErr ? Colors.red.shade900 : const Color(0xFF059669),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 2),
    ));
  }

  // ── UI ───────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Seller Panel',
          style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 18, letterSpacing: 1)),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _red.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _red.withOpacity(0.3)),
            ),
            child: const Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.storefront_rounded, color: _red, size: 13),
              SizedBox(width: 5),
              Text('RESELLER', style: TextStyle(color: _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 10, letterSpacing: 1.2)),
            ]),
          ),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

            // Header info card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_red.withOpacity(0.12), _card],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _red.withOpacity(0.25)),
                boxShadow: [BoxShadow(color: _red.withOpacity(0.08), blurRadius: 20, spreadRadius: -4)],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color: _red.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _red.withOpacity(0.35)),
                    ),
                    child: const Icon(Icons.storefront_rounded, color: _red, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Seller Panel', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 2),
                    Text('Kelola akun member lo di sini', style: TextStyle(color: Colors.white.withOpacity(0.45), fontFamily: 'Rajdhani', fontSize: 11)),
                  ])),
                ]),
                const SizedBox(height: 14),
                Container(height: 1, color: Colors.white.withOpacity(0.06)),
                const SizedBox(height: 14),
                Row(children: [
                  _infoChip(Icons.vpn_key_rounded, 'Key Token'),
                  const SizedBox(width: 8),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: widget.keyToken));
                        _snack('Key Token disalin');
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.04),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.white.withOpacity(0.08)),
                        ),
                        child: Row(children: [
                          Expanded(
                            child: Text(
                              widget.keyToken.length > 20 ? '${widget.keyToken.substring(0, 20)}...' : widget.keyToken,
                              style: const TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontSize: 11),
                            ),
                          ),
                          const Icon(Icons.copy_rounded, color: Colors.white24, size: 13),
                        ]),
                      ),
                    ),
                  ),
                ]),
              ]),
            ),

            const SizedBox(height: 24),

            // Section label
            _sectionLabel('AKSI'),
            const SizedBox(height: 12),

            // Buat akun card
            _actionCard(
              icon: Icons.person_add_rounded,
              title: 'Buat Akun Baru',
              subtitle: 'Tambahkan akun member baru',
              color: _red,
              onTap: _showCreateDialog,
            ),
            const SizedBox(height: 12),

            // Ubah durasi card
            _actionCard(
              icon: Icons.edit_calendar_rounded,
              title: 'Ubah Durasi Akun',
              subtitle: 'Tambah atau perpanjang durasi user',
              color: const Color(0xFF60A5FA),
              onTap: _showEditDialog,
            ),

            const SizedBox(height: 24),

            // Section akun dibuat
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              _sectionLabel('AKUN DIBUAT'),
              Row(children: [
                Text('Total: $_totalAccounts', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 12)),
                const SizedBox(width: 10),
                GestureDetector(
                  onTap: _loadAccounts,
                  child: Icon(Icons.refresh_rounded, color: Colors.white38, size: 16),
                ),
              ]),
            ]),
            const SizedBox(height: 12),

            if (_loadingAccounts)
              const Center(child: Padding(
                padding: EdgeInsets.all(24),
                child: CircularProgressIndicator(color: _red, strokeWidth: 2),
              ))
            else if (_accounts.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white.withOpacity(0.06))),
                child: Column(children: [
                  Icon(Icons.person_off_rounded, color: Colors.white.withOpacity(0.15), size: 36),
                  const SizedBox(height: 8),
                  Text('Belum ada akun dibuat', style: TextStyle(color: Colors.white.withOpacity(0.3), fontFamily: 'Rajdhani', fontSize: 13)),
                ]),
              )
            else
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _accounts.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (_, i) {
                  final acc = _accounts[i];
                  final isExpired = (acc['expiredDate'] ?? '').compareTo(DateTime.now().toIso8601String().split('T')[0]) < 0;
                  return Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: _card,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withOpacity(0.07)),
                    ),
                    child: Row(children: [
                      Container(
                        width: 38, height: 38,
                        decoration: BoxDecoration(
                          color: isExpired ? Colors.red.withOpacity(0.1) : Colors.green.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: isExpired ? Colors.red.withOpacity(0.3) : Colors.green.withOpacity(0.3)),
                        ),
                        child: Icon(Icons.person_rounded, color: isExpired ? Colors.red.withOpacity(0.7) : Colors.green.withOpacity(0.7), size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(acc['username'] ?? '-', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 13)),
                        const SizedBox(height: 2),
                        Text(
                          isExpired ? 'Expired: ${acc['expiredDate']}' : 'Aktif hingga: ${acc['expiredDate']}',
                          style: TextStyle(color: isExpired ? Colors.red.withOpacity(0.7) : Colors.white38, fontFamily: 'Rajdhani', fontSize: 11),
                        ),
                      ])),
                      IconButton(
                        onPressed: () => _confirmDelete(acc['username'] ?? ''),
                        icon: Icon(Icons.delete_outline_rounded, color: Colors.red.withOpacity(0.6), size: 18),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                      ),
                    ]),
                  );
                },
              ),
          ]),
        ),
      ),
    );
  }

  Widget _infoChip(IconData icon, String label) => Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, color: Colors.white38, size: 12),
    const SizedBox(width: 4),
    Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11)),
  ]);

  Widget _sectionLabel(String label) => Row(children: [
    Container(width: 3, height: 14, decoration: BoxDecoration(color: _red, borderRadius: BorderRadius.circular(2))),
    const SizedBox(width: 8),
    Text(label, style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 11, letterSpacing: 2)),
  ]);

  Widget _actionCard({required IconData icon, required String title, required String subtitle, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.07)),
          boxShadow: [const BoxShadow(color: Colors.black38, blurRadius: 8, offset: Offset(0, 2))],
        ),
        child: Row(children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 3),
            Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.4), fontFamily: 'Rajdhani', fontSize: 11)),
          ])),
          Container(
            width: 32, height: 32,
            decoration: BoxDecoration(
              color: color.withOpacity(0.08),
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: color.withOpacity(0.2)),
            ),
            child: Icon(Icons.arrow_forward_ios_rounded, color: color.withOpacity(0.7), size: 13),
          ),
        ]),
      ),
    );
  }

  // ── Dialogs ───────────────────────────────────────────────────────
  void _showCreateDialog() {
    showDialog(context: context, barrierDismissible: false,
      builder: (_) => _dialog(
        title: 'Buat Akun Baru',
        icon: Icons.person_add_rounded,
        fields: [
          _field('Username', _newUser, hint: 'Masukkan username'),
          _field('Password', _newPass, hint: 'Masukkan password'),
          _field('Durasi (hari)', _days, hint: 'Contoh: 30', type: TextInputType.number),
        ],
        onConfirm: _create,
      ),
    );
  }

  void _showEditDialog() {
    showDialog(context: context, barrierDismissible: false,
      builder: (_) => _dialog(
        title: 'Ubah Durasi Akun',
        icon: Icons.edit_calendar_rounded,
        fields: [
          _field('Username', _editUser, hint: 'Masukkan username target'),
          _field('Tambah Durasi (hari)', _editDays, hint: 'Contoh: 30', type: TextInputType.number),
        ],
        onConfirm: _edit,
      ),
    );
  }

  Widget _dialog({required String title, required IconData icon, required List<Widget> fields, required VoidCallback onConfirm}) {
    return Dialog(
      backgroundColor: _card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: _red.withOpacity(0.25)),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(22),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(color: _red.withOpacity(0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: _red.withOpacity(0.3))),
              child: Icon(icon, color: _red, size: 18),
            ),
            const SizedBox(width: 12),
            Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16)),
          ]),
          const SizedBox(height: 20),
          ...fields,
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextButton(
                onPressed: _loading ? null : () => Navigator.pop(context),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10), side: BorderSide(color: Colors.white.withOpacity(0.1))),
                ),
                child: Text('Batal', style: TextStyle(color: Colors.white.withOpacity(0.5), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                onPressed: _loading ? null : onConfirm,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _red,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: _loading
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Text('Konfirmasi', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, letterSpacing: 0.5)),
              ),
            ),
          ]),
        ]),
      ),
    );
  }

  Widget _field(String label, TextEditingController c, {String hint = '', TextInputType type = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(color: Colors.white.withOpacity(0.6), fontFamily: 'Rajdhani', fontWeight: FontWeight.w600, fontSize: 12)),
        const SizedBox(height: 6),
        TextField(
          controller: c,
          keyboardType: type,
          style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 13),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.2), fontFamily: 'Rajdhani', fontSize: 12),
            filled: true, fillColor: _bg,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.white.withOpacity(0.08))),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _red, width: 1.5)),
          ),
        ),
      ]),
    );
  }
}
