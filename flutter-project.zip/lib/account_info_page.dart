// ignore_for_file: use_build_context_synchronously
import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_theme.dart';
import 'change_password_page.dart';

// ─ Warna Dominus ─────────────────────────────────────────────────────────────
const _bg    = Color(0xFF080D14);
const _card  = Color(0xFF0D1520);
const _border= Color(0xFF1C2C3E);

class AccountInfoPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final VoidCallback onLogout;

  const AccountInfoPage({
    Key? key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.onLogout,
  }) : super(key: key);

  @override
  State<AccountInfoPage> createState() => _AccountInfoPageState();
}

class _AccountInfoPageState extends State<AccountInfoPage>
    with SingleTickerProviderStateMixin {
  String? _avatarPath;
  bool _showPass = false;
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _animCtrl.forward();
    _loadAvatar();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadAvatar() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('avatar_${widget.username}');
    if (path != null && File(path).existsSync()) {
      setState(() => _avatarPath = path);
    }
  }

  Future<void> _pickAvatar() async {
    final palette = ThemeProvider.of(context).current;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 36),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          border: Border(top: BorderSide(color: palette.primary.withValues(alpha: 0.3))),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 18),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const Text('Ganti Foto Profil', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1)),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: _sourceBtn(Icons.photo_library_rounded, 'Galeri', ImageSource.gallery, palette.primary)),
            const SizedBox(width: 12),
            Expanded(child: _sourceBtn(Icons.camera_alt_rounded, 'Kamera', ImageSource.camera, palette.primary)),
          ]),
          if (_avatarPath != null) ...[
            const SizedBox(height: 12),
            SizedBox(width: double.infinity,
              child: TextButton.icon(
                onPressed: () async {
                  Navigator.pop(context);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.remove('avatar_${widget.username}');
                  setState(() => _avatarPath = null);
                },
                icon: const Icon(Icons.delete_outline_rounded, color: Colors.red, size: 16),
                label: const Text('Hapus Foto', style: TextStyle(color: Colors.red, fontFamily: 'Rajdhani')),
              ),
            ),
          ],
        ]),
      ),
    );
  }

  Widget _sourceBtn(IconData icon, String label, ImageSource source, Color color) {
    return GestureDetector(
      onTap: () async {
        Navigator.pop(context);
        try {
          final picker = ImagePicker();
          final img = await picker.pickImage(source: source, imageQuality: 80, maxWidth: 400);
          if (img == null) return;
          // Copy ke app documents dir biar ga ilang (cache picker bisa dihapus OS)
          final appDir = await getApplicationDocumentsDirectory();
          final fileName = 'avatar_${widget.username}.jpg';
          final savedFile = await File(img.path).copy('${appDir.path}/$fileName');
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('avatar_${widget.username}', savedFile.path);
          setState(() => _avatarPath = savedFile.path);
        } catch (_) {}
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Column(children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 6),
          Text(label, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 12, fontWeight: FontWeight.bold)),
        ]),
      ),
    );
  }

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'dev':        return const Color(0xFF7C4DFF);
      case 'kingz':
      case 'high admin': return const Color(0xFFFF1744);
      case 'staff':      return const Color(0xFFFF5252);
      case 'partner':    return const Color(0xFFFF9100);
      case 'owner':      return const Color(0xFFFFD600);
      case 'reseller':   return const Color(0xFF00E5FF);
      case 'vip':        return const Color(0xFF69F0AE);
      default:           return Colors.white54;
    }
  }

  IconData _roleIcon(String role) {
    switch (role.toLowerCase()) {
      case 'dev':        return Icons.code_rounded;
      case 'kingz':
      case 'high admin':
      case 'staff':      return Icons.admin_panel_settings_rounded;
      case 'partner':
      case 'owner':      return Icons.workspace_premium_rounded;
      case 'reseller':   return Icons.storefront_rounded;
      case 'vip':        return Icons.star_rounded;
      default:           return Icons.person_rounded;
    }
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$label disalin ✓', style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
      backgroundColor: const Color(0xFF00E676),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 1),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final palette = ThemeProvider.of(context).current;
    final p = palette.primary;
    final roleColor = _roleColor(widget.role);
    final isExpired = widget.expiredDate != '9999-99-99' &&
        DateTime.tryParse(widget.expiredDate)?.isBefore(DateTime.now()) == true;

    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: p, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('ACCOUNT INFO', style: TextStyle(
          color: Colors.white, fontFamily: 'Rajdhani', fontSize: 15,
          fontWeight: FontWeight.bold, letterSpacing: 3,
        )),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, decoration: BoxDecoration(
            gradient: LinearGradient(colors: [Colors.transparent, p, Colors.transparent]),
          )),
        ),
      ),
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 40),
          child: Column(children: [

            // ── Avatar + Name ─────────────────────────────────
            Stack(alignment: Alignment.center, children: [
              // Glow ring
              Container(
                width: 110, height: 110,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    roleColor.withValues(alpha: 0.25),
                    Colors.transparent,
                  ]),
                ),
              ),
              // Avatar
              GestureDetector(
                onTap: _pickAvatar,
                child: Stack(children: [
                  Container(
                    width: 90, height: 90,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _card,
                      border: Border.all(color: roleColor.withValues(alpha: 0.6), width: 2),
                      boxShadow: [BoxShadow(color: roleColor.withValues(alpha: 0.3), blurRadius: 16)],
                    ),
                    child: ClipOval(
                      child: _avatarPath != null
                          ? Image.file(File(_avatarPath!), fit: BoxFit.cover)
                          : Container(
                              color: roleColor.withValues(alpha: 0.12),
                              child: Center(child: Text(
                                widget.username.isNotEmpty ? widget.username[0].toUpperCase() : '?',
                                style: TextStyle(color: roleColor, fontSize: 36, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold),
                              )),
                            ),
                    ),
                  ),
                  // Edit badge
                  Positioned(right: 0, bottom: 0,
                    child: Container(
                      width: 26, height: 26,
                      decoration: BoxDecoration(
                        color: p, shape: BoxShape.circle,
                        border: Border.all(color: _bg, width: 2),
                      ),
                      child: const Icon(Icons.edit_rounded, color: Colors.white, size: 13),
                    ),
                  ),
                ]),
              ),
            ]),
            const SizedBox(height: 14),

            // Username besar
            Text(widget.username, style: const TextStyle(
              color: Colors.white, fontFamily: 'Rajdhani', fontSize: 26,
              fontWeight: FontWeight.bold, letterSpacing: 1,
            )),
            const SizedBox(height: 6),

            // Role badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: roleColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: roleColor.withValues(alpha: 0.4)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(_roleIcon(widget.role), color: roleColor, size: 13),
                const SizedBox(width: 6),
                Text(widget.role.toUpperCase(), style: TextStyle(
                  color: roleColor, fontFamily: 'Rajdhani', fontSize: 11,
                  fontWeight: FontWeight.bold, letterSpacing: 2,
                )),
              ]),
            ),
            const SizedBox(height: 28),

            // ── Info Cards ────────────────────────────────────
            _infoRow(Icons.person_outline_rounded, 'USERNAME', widget.username, p,
                onCopy: () => _copyToClipboard(widget.username, 'Username')),
            const SizedBox(height: 10),
            _infoRow(
              _showPass ? Icons.visibility_off_outlined : Icons.visibility_outlined,
              'PASSWORD',
              _showPass ? widget.password : '••••••••',
              p,
              onTap: () => setState(() => _showPass = !_showPass),
              onCopy: () => _copyToClipboard(widget.password, 'Password'),
            ),
            const SizedBox(height: 10),
            _infoRow(Icons.security_rounded, 'ROLE', widget.role.toUpperCase(), roleColor),
            const SizedBox(height: 10),
            _infoRow(
              Icons.calendar_today_rounded, 'EXPIRED',
              widget.expiredDate == '9999-99-99' ? 'Permanent ∞' : widget.expiredDate,
              isExpired ? Colors.red : _green,
              trailing: isExpired
                  ? Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(8)),
                      child: const Text('EXPIRED', style: TextStyle(color: Colors.red, fontFamily: 'Rajdhani', fontSize: 9, fontWeight: FontWeight.bold)),
                    )
                  : null,
            ),
            const SizedBox(height: 28),

            // ── Actions ───────────────────────────────────────
            _actionBtn(
              icon: Icons.lock_reset_rounded,
              label: 'GANTI PASSWORD',
              color: p,
              onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => ChangePasswordPage(username: widget.username, sessionKey: widget.sessionKey),
              )),
            ),
            const SizedBox(height: 10),
            _actionBtn(
              icon: Icons.logout_rounded,
              label: 'LOGOUT',
              color: Colors.red,
              outlined: true,
              onTap: widget.onLogout,
            ),
          ]),
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value, Color color,
      {VoidCallback? onTap, VoidCallback? onCopy, Widget? trailing}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _border),
        ),
        child: Row(children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 16),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 10, letterSpacing: 2)),
            const SizedBox(height: 2),
            Text(value, style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 14, fontWeight: FontWeight.bold)),
          ])),
          if (trailing != null) trailing
          else if (onCopy != null)
            GestureDetector(
              onTap: onCopy,
              child: const Icon(Icons.copy_rounded, color: Colors.white24, size: 16),
            ),
          if (onTap != null && onCopy == null)
            const Icon(Icons.chevron_right_rounded, color: Colors.white24, size: 18),
        ]),
      ),
    );
  }

  Widget _actionBtn({required IconData icon, required String label, required Color color, required VoidCallback onTap, bool outlined = false}) {
    return SizedBox(
      width: double.infinity, height: 52,
      child: outlined
          ? OutlinedButton.icon(
              onPressed: onTap,
              icon: Icon(icon, size: 18, color: color),
              label: Text(label, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 2)),
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: color.withValues(alpha: 0.4)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
            )
          : ElevatedButton.icon(
              onPressed: onTap,
              icon: Icon(icon, size: 18),
              label: Text(label, style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 2)),
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
            ),
    );
  }
}

// ─ Colors shorthand ──────────────────────────────────────────────────────────
const _green = Color(0xFF00E676);
