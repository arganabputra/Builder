import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'config.dart';

class TelegramGroupPage extends StatefulWidget {
  final String sessionKey;
  const TelegramGroupPage({super.key, required this.sessionKey});

  @override
  State<TelegramGroupPage> createState() => _TelegramGroupPageState();
}

class _TelegramGroupPageState extends State<TelegramGroupPage> {
  bool _loading = true;
  String? _link;
  String? _role;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() { _loading = true; _error = null; });
    try {
      final res = await http.get(Uri.parse(
        '${AppConfig.baseUrl}/api/user/telegramGroup?key=${widget.sessionKey}'
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['link'] != null) {
        setState(() { _link = data['link']; _role = data['role']; _loading = false; });
      } else {
        setState(() { _error = data['message'] ?? 'Gagal ambil link grup.'; _loading = false; });
      }
    } catch (_) {
      setState(() { _error = 'Gagal konek ke server.'; _loading = false; });
    }
  }

  Future<void> _join() async {
    if (_link == null) return;
    final uri = Uri.parse(_link!);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0B),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Join Grup Telegram',
          style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 17)),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _loading
            ? const CircularProgressIndicator(color: Color(0xFF29B6F6))
            : _error != null
              ? Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 48),
                  const SizedBox(height: 14),
                  Text(_error!, textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontSize: 14)),
                  const SizedBox(height: 20),
                  OutlinedButton(
                    onPressed: _fetch,
                    style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.white24)),
                    child: const Text('Coba Lagi', style: TextStyle(fontFamily: 'Rajdhani', color: Colors.white)),
                  ),
                ])
              : Column(mainAxisSize: MainAxisSize.min, children: [
                  Container(
                    width: 90, height: 90,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(colors: [Color(0xFF29B6F6), Color(0xFF0288D1)]),
                      boxShadow: [BoxShadow(color: const Color(0xFF29B6F6).withOpacity(0.4), blurRadius: 30, spreadRadius: 4)],
                    ),
                    child: const Icon(FontAwesomeIcons.telegram, color: Colors.white, size: 40),
                  ),
                  const SizedBox(height: 24),
                  const Text('Grup Telegram Kamu',
                    style: TextStyle(color: Colors.white, fontSize: 20, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF29B6F6).withOpacity(0.12),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF29B6F6).withOpacity(0.4)),
                    ),
                    child: Text('Role: ${(_role ?? '').toUpperCase()}',
                      style: const TextStyle(color: Color(0xFF29B6F6), fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1)),
                  ),
                  const SizedBox(height: 10),
                  const Text('Gabung buat dapet info, promo, dan diskusi bareng sesama role kamu.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 13)),
                  const SizedBox(height: 32),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton.icon(
                      onPressed: _join,
                      icon: const Icon(FontAwesomeIcons.telegram, size: 18),
                      label: const Text('Gabung Sekarang',
                        style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 0.5)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF29B6F6),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ),
                ]),
        ),
      ),
    );
  }
}
