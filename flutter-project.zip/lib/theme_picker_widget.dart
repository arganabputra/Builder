// ============================================================
// THEME PICKER WIDGET
// Pasang widget ini di settings/drawer/profile page
// Contoh: ThemePickerWidget()
// ============================================================
import 'package:flutter/material.dart';
import 'app_theme.dart';

class ThemePickerWidget extends StatelessWidget {
  const ThemePickerWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final themeNotifier = ThemeProvider.of(context);
    final current = themeNotifier.current;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
          child: Row(
            children: [
              Icon(Icons.palette_outlined, color: current.primary, size: 18),
              const SizedBox(width: 8),
              Text(
                'TEMA WARNA',
                style: TextStyle(
                  color: current.primary,
                  fontSize: 13,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
        ),

        // Grid warna
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 5,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1,
          ),
          itemCount: appColorPalettes.length,
          itemBuilder: (context, i) {
            final palette = appColorPalettes[i];
            final isSelected = palette.id == current.id;

            return GestureDetector(
              onTap: () => themeNotifier.setTheme(palette),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOut,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [palette.gradient1, palette.primary],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(
                    color: isSelected ? Colors.white : Colors.transparent,
                    width: 2.5,
                  ),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: palette.primary.withValues(alpha: 0.7),
                            blurRadius: 12,
                            spreadRadius: 2,
                          ),
                        ]
                      : [],
                ),
                child: isSelected
                    ? const Icon(Icons.check, color: Colors.white, size: 18)
                    : null,
              ),
            );
          },
        ),

        const SizedBox(height: 10),

        // Label warna aktif
        Center(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 200),
            child: Text(
              current.name,
              key: ValueKey(current.id),
              style: TextStyle(
                color: current.primary,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1.5,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ── Bottom Sheet helper — panggil ini dari mana aja ──────────
void showThemePicker(BuildContext context) {
  final themeNotifier = ThemeProvider.of(context);
  final current = themeNotifier.current;

  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (_) => ThemeProvider(
      notifier: themeNotifier,
      child: Container(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 36),
        decoration: BoxDecoration(
          color: const Color(0xFF0D0D0D),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(
            top: BorderSide(
              color: current.primary.withValues(alpha: 0.3),
              width: 1,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: current.primary.withValues(alpha: 0.15),
              blurRadius: 30,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle bar
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2),
              ),
            ),

            // Title
            Text(
              'PILIH TEMA WARNA',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                letterSpacing: 3,
                shadows: [
                  Shadow(
                    color: current.primary,
                    blurRadius: 15,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Warna diingat otomatis',
              style: TextStyle(
                color: Colors.white38,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 24),

            // Picker
            const ThemePickerWidget(),

            const SizedBox(height: 20),

            // Tombol tutup
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(
                      color: current.primary.withValues(alpha: 0.3),
                    ),
                  ),
                ),
                child: const Text(
                  'TUTUP',
                  style: TextStyle(
                    color: Colors.white70,
                    fontFamily: 'Orbitron',
                    fontSize: 12,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
