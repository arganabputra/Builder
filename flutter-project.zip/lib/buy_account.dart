// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'config.dart';
import 'developer_settings.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'transaction_history_page.dart';

// ═══════════════════════════════════════════════════════════════
//  KONSTANTA
// ═══════════════════════════════════════════════════════════════

// ── Helper ambil device ID ────────────────────────────────────
Future<String> _getDeviceId() async {
  try {
    final info = DeviceInfoPlugin();
    if (defaultTargetPlatform == TargetPlatform.android) {
      return (await info.androidInfo).id;
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      return (await info.iosInfo).identifierForVendor ?? 'unknown';
    }
  } catch (_) {}
  return 'unknown';
}

// QRIS admin - ganti dengan base64 gambar QRIS kamu
// Atau pakai URL gambar: gunakan Image.network
const String _qrisImageUrl = 'https://files.catbox.moe/49tzrj.jpg';

// ═══════════════════════════════════════════════════════════════
//  MODEL
// ═══════════════════════════════════════════════════════════════
class AccountPlan {
  final String role;
  final String title;
  final String badge;
  final int monthlyPrice;
  final int permanentPrice;
  final IconData icon;
  final List<Color> gradient;
  final List<String> features;

  const AccountPlan({
    required this.role,
    required this.title,
    required this.badge,
    required this.monthlyPrice,
    required this.permanentPrice,
    required this.icon,
    required this.gradient,
    required this.features,
  });
}

const List<AccountPlan> kPlans = [
  AccountPlan(
    role: 'member',
    title: 'Member Account',
    badge: 'BASIC',
    monthlyPrice: 5000,
    permanentPrice: 10000,
    icon: Icons.person_outline_rounded,
    gradient: [Color(0xFF0EA5E9), Color(0xFF0284C7)],
    features: ['Akses semua bug tools', 'Support chat', 'Update rutin'],
  ),
  AccountPlan(
    role: 'reseller',
    title: 'Reseller Account',
    badge: 'RESELLER',
    monthlyPrice: 10000,
    permanentPrice: 20000,
    icon: Icons.group_outlined,
    gradient: [Color(0xFF3B82F6), Color(0xFF1D4ED8)],
    features: ['Semua fitur Member', 'Bisa buat akun member', 'Panel reseller', 'Komisi penjualan'],
  ),
  AccountPlan(
    role: 'vip',
    title: 'VIP Account',
    badge: 'VIP',
    monthlyPrice: 20000,
    permanentPrice: 35000,
    icon: Icons.star_outline_rounded,
    gradient: [Color(0xFFD97706), Color(0xFFB45309)],
    features: ['Semua fitur Reseller', 'Priority support', 'Akses fitur VIP eksklusif', 'Early access update'],
  ),
  AccountPlan(
    role: 'owner',
    title: 'Owner Account',
    badge: 'OWNER',
    monthlyPrice: 40000,
    permanentPrice: 80000,
    icon: Icons.shield_outlined,
    gradient: [Color(0xFF8B5CF6), Color(0xFF6D28D9)],
    features: ['Semua fitur VIP', 'Akses panel owner', 'Manage konten app', 'Badge owner eksklusif'],
  ),
  AccountPlan(
    role: 'partner',
    title: 'Partner Account',
    badge: 'PARTNER',
    monthlyPrice: 55000,
    permanentPrice: 120000,
    icon: Icons.workspace_premium_outlined,
    gradient: [Color(0xFFEC4899), Color(0xFFBE185D)],
    features: ['Semua fitur Owner', 'Akses panel partner', 'Kontrol penuh konten', 'Badge partner eksklusif'],
  ),
  AccountPlan(
    role: 'staff',
    title: 'Staff Account',
    badge: 'STAFF',
    monthlyPrice: 70000,
    permanentPrice: 150000,
    icon: Icons.admin_panel_settings_outlined,
    gradient: [Color(0xFF10B981), Color(0xFF059669)],
    features: ['Semua fitur Partner', 'Manage semua user', 'Approve/reject request', 'Akses panel staff penuh'],
  ),
  AccountPlan(
    role: 'kingz',
    title: 'Kingz Account',
    badge: 'KINGZ',
    monthlyPrice: 85000,
    permanentPrice: 200000,
    icon: Icons.security_outlined,
    gradient: [Color(0xFFEF4444), Color(0xFFB91C1C)],
    features: ['Akses tertinggi', 'Full control semua fitur', 'Manage admin & owner', 'Badge eksklusif Kingz', 'Priority support 24/7'],
  ),
];

// ═══════════════════════════════════════════════════════════════
//  MAIN PAGE
// ═══════════════════════════════════════════════════════════════
class BuyAccountPage extends StatefulWidget {
  const BuyAccountPage({super.key});

  @override
  State<BuyAccountPage> createState() => _BuyAccountPageState();
}

class _BuyAccountPageState extends State<BuyAccountPage>
    with SingleTickerProviderStateMixin {
  // Step: 0=pilih plan, 1=isi data, 2=bayar, 3=sukses
  int _step = 0;
  AccountPlan? _selectedPlan;
  String _durationType = 'monthly'; // monthly | permanent
  String _requestId = ''; // dari step 1, diteruskan ke step 2
  String? _qrisImageUrl;
  bool _autoOrder = false;
  int? _qrisFee;
  int? _totalWithFee;
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  // Banner data — status = server API hidup/mati (health check /ping)
  bool _systemOnline = false;
  String _buyMode = 'app';
  String _telegramOwner = '@ytimlou';
  Map<String, dynamic> _discounts = {};
  int _totalUser = 0;
  int _cpu = 0, _ram = 0;
  int _approved = 0, _pending = 0, _rejected = 0;

  // Typing animation banner "Welcome to, Dominus Core"
  String _typedBannerText = '';
  bool _bannerTypingDone = false;
  bool _cursorVisible = true;
  Timer? _cursorTimer;
  Timer? _statusTimer;

  // Colors
  static const _bg = Color(0xFF080D14);
  static const _card = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);
  static const _cyan = Color(0xFFFF1744);

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 350));
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeInOut);
    _animCtrl.forward();
    _fetchBannerData();
    _fetchDiscounts();
    _fetchBuySettings();
    _startBannerTyping();
    _statusTimer = Timer.periodic(const Duration(seconds: 20), (_) => _checkSystemStatus());
  }

  Future<void> _fetchBuySettings() async {
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/buy-settings'))
          .timeout(const Duration(seconds: 6));
      final d = jsonDecode(res.body);
      if (mounted && d['success'] == true) {
        setState(() {
          _buyMode = d['mode'] ?? 'app';
          _telegramOwner = d['telegramUsername'] ?? '@ytimlou';
        });
      }
    } catch (_) {}
  }

  Future<void> _fetchDiscounts() async {
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/requestkey/discount'))
          .timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      if (mounted && d['success'] == true) {
        setState(() => _discounts = Map<String, dynamic>.from(d['discounts'] ?? {}));
      }
    } catch (_) {}
  }

  Future<void> _fetchBannerData() async {
    try {
      final resp = await http
          .get(Uri.parse('${AppConfig.baseUrl}/api/requestkey/banner-stats'))
          .timeout(const Duration(seconds: 8));
      final stats = jsonDecode(resp.body);
      if (mounted && stats['success'] == true) {
        setState(() {
          _totalUser = stats['totalUser'] ?? 0;
          _approved  = stats['approved']  ?? 0;
          _pending   = stats['pending']   ?? 0;
          _rejected  = stats['rejected']  ?? 0;
        });
      }
    } catch (_) {}
    try {
      final resp = await http
          .get(Uri.parse('${AppConfig.baseUrl}/api/server/stats'))
          .timeout(const Duration(seconds: 8));
      final d = jsonDecode(resp.body);
      if (mounted && d['success'] == true) {
        setState(() { _cpu = d['cpu'] ?? 0; _ram = d['ram'] ?? 0; });
      }
    } catch (_) {}
    _checkSystemStatus();
  }

  Future<void> _checkSystemStatus() async {
    bool alive = false;
    try {
      final resp = await http
          .get(Uri.parse('${AppConfig.baseUrl}/ping'))
          .timeout(const Duration(seconds: 5));
      alive = resp.statusCode == 200;
    } catch (_) {
      alive = false;
    }
    if (mounted) setState(() => _systemOnline = alive);
  }

  void _startBannerTyping() {
    const fullText = 'Welcome to, Dominus Core';
    _typedBannerText = '';
    _bannerTypingDone = false;
    _cursorTimer?.cancel();
    _cursorTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      if (!mounted) return;
      setState(() => _cursorVisible = !_cursorVisible);
    });
    int i = 0;
    Future.doWhile(() async {
      await Future.delayed(const Duration(milliseconds: 60));
      if (!mounted) return false;
      setState(() {
        if (i < fullText.length) {
          _typedBannerText = fullText.substring(0, i + 1);
          i++;
        } else {
          _bannerTypingDone = true;
        }
      });
      return i < fullText.length;
    });
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _cursorTimer?.cancel();
    _statusTimer?.cancel();
    super.dispose();
  }

  void _goStep(int step) {
    _animCtrl.reset();
    setState(() => _step = step);
    _animCtrl.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          statusBarBrightness: Brightness.dark,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _cyan),
          onPressed: () {
            if (_step == 0) {
              Navigator.pop(context);
            } else {
              _goStep(_step - 1);
            }
          },
        ),
        title: Row(children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: _cyan.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _cyan.withValues(alpha: 0.4)),
            ),
            child: const Icon(Icons.shopping_cart_outlined, color: _cyan, size: 18),
          ),
          const SizedBox(width: 10),
          Text(
            _step == 0
                ? 'Buy Account'
                : _step == 1
                    ? 'Data Akun'
                    : _step == 2
                        ? 'Pembayaran'
                        : 'Selesai',
            style: const TextStyle(
                color: Colors.white,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.bold,
                fontSize: 18,
                letterSpacing: 1),
          ),
        ]),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: _buildStepIndicator(),
        ),
        actions: [

          // Riwayat transaksi button
          IconButton(
            icon: const Icon(Icons.receipt_long_rounded, color: Colors.white54, size: 20),
            tooltip: 'Riwayat Transaksi',
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              final username = prefs.getString('username') ?? '';
              final sessionKey = prefs.getString('sessionKey') ?? '';
              if (!mounted) return;
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => TransactionHistoryPage(username: username, sessionKey: sessionKey),
              ));
            },
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnim,
        child: _step == 0
            ? _StepPilihPlan(
                plans: kPlans,
                selectedPlan: _selectedPlan,
                durationType: _durationType,
                onDurationChange: (v) => setState(() => _durationType = v),
                onSelectPlan: (plan) {
                  setState(() => _selectedPlan = plan);
                  _goStep(1);
                },
                bannerWidget: _buildBanner(),
                discounts: _discounts,
              )
            : _step == 1
                ? _StepIsiData(
                    plan: _selectedPlan!,
                    durationType: _durationType,
                    discount: (_discounts[_selectedPlan!.role] ?? 0) as int,
                    onNext: () => _goStep(2),
                    onBack: () => _goStep(0),
                    onRequestCreated: (id, {qrisImageUrl, autoOrder = false, fee, totalWithFee}) {
                      setState(() {
                        _requestId = id;
                        _qrisImageUrl = qrisImageUrl;
                        _autoOrder = autoOrder;
                        _qrisFee = fee;
                        _totalWithFee = totalWithFee;
                      });
                    },
                  )
                : _step == 2
                    ? _StepBayar(
                        plan: _selectedPlan!,
                        durationType: _durationType,
                        requestId: _requestId,
                        qrisImageUrl: _qrisImageUrl,
                        autoOrder: _autoOrder,
                        qrisFee: _qrisFee,
                        totalWithFee: _totalWithFee,
                        discount: (_discounts[_selectedPlan!.role] ?? 0) as int,
                        onDone: () => _goStep(3),
                      )
                    : StepSukses(onHome: () => Navigator.pop(context), requestId: _requestId),
      ),
    );
  }

  Widget _buildStepIndicator() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      child: Row(children: List.generate(4, (i) {
        final active = i == _step;
        final done = i < _step;
        return Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 2),
            height: 3,
            decoration: BoxDecoration(
              color: done
                  ? _cyan
                  : active
                      ? _cyan.withValues(alpha: 0.6)
                      : _border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        );
      })),
    );
  }

  Widget _buildBanner() {
    return Column(children: [
      Container(
      margin: const EdgeInsets.fromLTRB(0, 12, 0, 4),
      height: 175,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _cyan.withValues(alpha: 0.35)),
        image: const DecorationImage(
          image: AssetImage('assets/images/daniel.jpg'),
          fit: BoxFit.cover,
        ),
        boxShadow: [
          BoxShadow(color: _cyan.withValues(alpha: 0.15), blurRadius: 18, spreadRadius: 1),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(17),
        child: Stack(children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withValues(alpha: 0.55),
                  Colors.black.withValues(alpha: 0.25),
                  Colors.black.withValues(alpha: 0.75),
                ],
                stops: const [0.0, 0.45, 1.0],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Row(children: [
                  Expanded(child: _bannerStatChip(
                    icon: _systemOnline ? Icons.bolt_rounded : Icons.power_off_rounded,
                    label: _systemOnline ? 'Online' : 'Offline',
                    color: _systemOnline ? const Color(0xFF3DD68C) : Colors.redAccent,
                  )),
                  const SizedBox(width: 6),
                  Expanded(child: _bannerStatChip(
                    icon: Icons.people_alt_rounded,
                    label: '$_totalUser User',
                    color: _cyan,
                  )),
                  const SizedBox(width: 6),
                  Expanded(child: _bannerStatChip(
                    icon: Icons.local_fire_department_rounded,
                    label: 'Gacor',
                    color: Colors.deepOrangeAccent,
                  )),
                  const SizedBox(width: 6),
                  Expanded(child: _bannerStatChip(
                    icon: Icons.verified_rounded,
                    label: 'Stabil',
                    color: Colors.cyanAccent,
                  )),
                ]),
              ],
            ),
          ),
        ]),
      ),
    ),
    const SizedBox(height: 8),
    ]);
  }

  Widget _buildServerInfoRow() {
    final statusColor = _systemOnline ? const Color(0xFF00E676) : Colors.redAccent;
    final orderTotal = (_approved + _pending + _rejected) == 0 ? 1 : (_approved + _pending + _rejected);
    final maxUser = _totalUser == 0 ? 1 : _totalUser;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1520),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: statusColor.withValues(alpha: 0.3)),
        boxShadow: [BoxShadow(color: statusColor.withValues(alpha: 0.07), blurRadius: 12)],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // ── Header ──────────────────────────────────────
        Row(children: [
          Container(
            width: 8, height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle, color: statusColor,
              boxShadow: [BoxShadow(color: statusColor.withValues(alpha: 0.7), blurRadius: 6, spreadRadius: 1)],
            ),
          ),
          const SizedBox(width: 8),
          Text('SERVER INFO', style: TextStyle(color: statusColor, fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 2)),
          const Spacer(),
          Text(_systemOnline ? 'RUNNING' : 'OFFLINE', style: TextStyle(
            color: statusColor, fontFamily: 'Rajdhani', fontSize: 9,
            fontWeight: FontWeight.bold, letterSpacing: 2,
          )),
        ]),

        const SizedBox(height: 10),
        Container(height: 1, color: Colors.white.withValues(alpha: 0.05)),
        const SizedBox(height: 10),

        // ── Server stats ─────────────────────────────────
        _statProgressRow('CPU',  Icons.memory_rounded,          _cpu / 100,        '$_cpu%',        const Color(0xFFFF1744)),
        const SizedBox(height: 7),
        _statProgressRow('RAM',  Icons.developer_board_rounded, _ram / 100,        '$_ram%',        const Color(0xFF00E5FF)),
        const SizedBox(height: 7),
        _statProgressRow('USER', Icons.people_alt_rounded,      _totalUser / (maxUser * 2).toDouble(), '$_totalUser',   const Color(0xFF7C4DFF)),

        const SizedBox(height: 10),
        Container(height: 1, color: Colors.white.withValues(alpha: 0.05)),
        const SizedBox(height: 10),

        // ── Order stats ──────────────────────────────────
        _statProgressRow('DONE', Icons.check_circle_rounded, _approved / orderTotal, '$_approved (${(_approved/orderTotal*100).round()}%)', const Color(0xFF00E676)),
        const SizedBox(height: 7),
        _statProgressRow('WAIT', Icons.pending_rounded,      _pending  / orderTotal, '$_pending (${(_pending/orderTotal*100).round()}%)',   const Color(0xFFFF9100)),
        const SizedBox(height: 7),
        _statProgressRow('FAIL', Icons.cancel_rounded,       _rejected / orderTotal, '$_rejected (${(_rejected/orderTotal*100).round()}%)', const Color(0xFFFF1744)),
      ]),
    );
  }

  Widget _statProgressRow(String label, IconData icon, double value, String valStr, Color color) =>
    Row(children: [
      Icon(icon, color: color, size: 11),
      const SizedBox(width: 6),
      SizedBox(width: 36, child: Text(label, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1))),
      Expanded(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: value.clamp(0.0, 1.0),
            backgroundColor: Colors.white.withValues(alpha: 0.06),
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 5,
          ),
        ),
      ),
      const SizedBox(width: 8),
      SizedBox(
        width: 60,
        child: Text(valStr, style: TextStyle(color: color, fontFamily: 'Rajdhani', fontSize: 10, fontWeight: FontWeight.bold), textAlign: TextAlign.right),
      ),
    ]);

  Widget _bannerStatChip({required IconData icon, required String label, required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.45),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.5)),
      ),
      child: Row(mainAxisSize: MainAxisSize.max, mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: color, size: 13),
        const SizedBox(width: 5),
        Text(label, style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w600, fontSize: 11)),
      ]),
    );
  }
}

class _ServerInfoItem {
  final IconData icon;
  final String label;
  final Color color;
  const _ServerInfoItem(this.icon, this.label, this.color);
}

// ═══════════════════════════════════════════════════════════════
//  STEP 0 — PILIH PLAN
// ═══════════════════════════════════════════════════════════════
class _StepPilihPlan extends StatelessWidget {
  final List<AccountPlan> plans;
  final AccountPlan? selectedPlan;
  final String durationType;
  final ValueChanged<String> onDurationChange;
  final ValueChanged<AccountPlan> onSelectPlan;
  final Widget? bannerWidget;
  final Map<String, dynamic> discounts;

  const _StepPilihPlan({
    required this.plans,
    required this.selectedPlan,
    required this.durationType,
    required this.onDurationChange,
    required this.onSelectPlan,
    this.bannerWidget,
    this.discounts = const {},
  });

  static const _bg = Color(0xFF080D14);
  static const _card = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);
  static const _cyan = Color(0xFFFF1744);

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      children: [
        // Banner ikut scroll
        if (bannerWidget != null) ...[
          const SizedBox(height: 12),
          bannerWidget!,
          const SizedBox(height: 12),
        ],
        // Duration toggle
        Container(
          margin: const EdgeInsets.only(bottom: 20),
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _border),
          ),
          child: Row(children: [
            _DurTab(
              label: 'MONTHLY', icon: Icons.calendar_month_rounded,
              active: durationType == 'monthly',
              onTap: () => onDurationChange('monthly'),
            ),
            _DurTab(
              label: '∞  PERMANENT',
              active: durationType == 'permanent',
              onTap: () => onDurationChange('permanent'),
            ),
          ]),
        ),


        // Plan cards
        ...plans.map((plan) => _PlanCard(
              plan: plan,
              durationType: durationType,
              onTap: () => onSelectPlan(plan),
              discount: (discounts[plan.role] ?? 0) as int,
            )),

        const SizedBox(height: 12),
        // System Status Card — di bawah role terakhir
        const _SystemStatusCard(),
        const SizedBox(height: 20),
        // Info
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _cyan.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _cyan.withValues(alpha: 0.2)),
          ),
          child: Row(children: [
            Icon(Icons.info_outline_rounded, color: _cyan.withValues(alpha: 0.7), size: 18),
            const SizedBox(width: 10),
            const Expanded(
              child: Text(
                'Pembayaran via QRIS / GoPay. Konfirmasi oleh admin dalam waktu singkat.',
                style: TextStyle(
                    color: Colors.white54, fontSize: 12, fontFamily: 'Rajdhani'),
              ),
            ),
          ]),
        ),

        const SizedBox(height: 16),

        // Tombol Upgrade Role
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const UpgradeRolePage()),
          ),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF1744), Color(0xFFD50000)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(color: Color(0xFFFF1744).withValues(alpha: 0.4), blurRadius: 12, offset: Offset(0, 4))],
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.upgrade_rounded, color: Colors.white, size: 20),
              const SizedBox(width: 8),
              const Text(
                'Upgrade Role Akun',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  letterSpacing: 1,
                ),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 10),

        // Tombol Get Free
        _GetFreeButton(),
        const SizedBox(height: 10),

        // Tombol Donasi
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const DonasiPage()),
          ),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFFB300), Color(0xFFFF6F00)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(color: Color(0xFFFFB300).withValues(alpha: 0.35), blurRadius: 12, offset: Offset(0, 4))],
            ),
            child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.favorite_rounded, color: Colors.white, size: 20),
              SizedBox(width: 8),
              Text('Donasi', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 1)),
            ]),
          ),
        ),
      ],
    );
  }
}

class _DurTab extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  final IconData? icon;
  static const _cyan = Color(0xFFFF1744);
  static const _card = Color(0xFF0D1520);

  const _DurTab({required this.label, required this.active, required this.onTap, this.icon});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? _cyan.withValues(alpha: 0.18) : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            border: active ? Border.all(color: _cyan.withValues(alpha: 0.5)) : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 14, color: active ? _cyan : Colors.white38),
                const SizedBox(width: 6),
              ],
              Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: active ? _cyan : Colors.white38,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final AccountPlan plan;
  final String durationType;
  final VoidCallback onTap;
  final int discount; // 0 = no discount

  const _PlanCard(
      {required this.plan, required this.durationType, required this.onTap, this.discount = 0});

  static const _card = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);

  String _fmtRp(int v) => 'Rp ${v.toString().replaceAllMapped(RegExp(r"(\d)(?=(\d{3})+(?!\d))"), (m) => "${m[1]}.")}';

  @override
  Widget build(BuildContext context) {
    final price = durationType == 'monthly'
        ? plan.monthlyPrice
        : plan.permanentPrice;
    final hasDiscount = discount > 0;
    final discountedPrice = hasDiscount ? (price * (100 - discount) / 100).round() : price;
    final priceStr = _fmtRp(discountedPrice);
    final origStr = _fmtRp(price);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _border, width: 1.2),
        ),
        child: Stack(children: [
          // Background icon
          Positioned(
            right: 12,
            top: 12,
            child: Icon(plan.icon, size: 70, color: Colors.white.withOpacity(0.04)),
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Header
              Row(children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: plan.gradient),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Icon(plan.icon, color: Colors.white, size: 22),
                ),
                const SizedBox(width: 12),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(plan.title,
                      style: TextStyle(
                          color: plan.gradient[0],
                          fontFamily: 'Rajdhani',
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                          letterSpacing: 0.5)),
                  const SizedBox(height: 3),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: plan.gradient[0].withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: plan.gradient[0].withValues(alpha: 0.3)),
                    ),
                    child: Text(plan.badge,
                        style: TextStyle(
                            color: plan.gradient[0],
                            fontSize: 9,
                            fontFamily: 'Rajdhani',
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5)),
                  ),
                ]),
              ]),
              const SizedBox(height: 14),
              // Price
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.black26,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white.withOpacity(0.06)),
                ),
                child: Row(children: [
                  Icon(
                      durationType == 'monthly'
                          ? Icons.calendar_month_outlined
                          : Icons.all_inclusive_rounded,
                      color: plan.gradient[0],
                      size: 18),
                  const SizedBox(width: 8),
                  if (hasDiscount) ...[
                    Text(origStr, style: const TextStyle(color: Colors.white30, fontFamily: 'Rajdhani', fontSize: 14, decoration: TextDecoration.lineThrough, decorationColor: Colors.white30)),
                    const SizedBox(width: 8),
                  ],
                  Text(priceStr, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 20)),
                  const SizedBox(width: 4),
                  Text(durationType == 'monthly' ? '/ Bulan' : '/ Permanent', style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
                  if (hasDiscount) ...[
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                      decoration: BoxDecoration(color: const Color(0xFFFF9100).withValues(alpha: 0.15), borderRadius: BorderRadius.circular(8), border: Border.all(color: const Color(0xFFFF9100).withValues(alpha: 0.5))),
                      child: Text('-$discount%', style: const TextStyle(color: Color(0xFFFF9100), fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ]),
              ),
              const SizedBox(height: 12),
              // Features
              ...plan.features.map((f) => Padding(
                    padding: const EdgeInsets.only(bottom: 5),
                    child: Row(children: [
                      Icon(Icons.check_circle_outline_rounded,
                          color: plan.gradient[0], size: 14),
                      const SizedBox(width: 6),
                      Text(f,
                          style: const TextStyle(
                              color: Colors.white60,
                              fontSize: 12,
                              fontFamily: 'Rajdhani')),
                    ]),
                  )),
              const SizedBox(height: 14),
              // Button
              GestureDetector(
                onTap: onTap,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: plan.gradient),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                          color: plan.gradient[0].withValues(alpha: 0.3),
                          blurRadius: 12,
                          spreadRadius: 1)
                    ],
                  ),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Icon(Icons.send_rounded, color: Colors.white, size: 16),
                    const SizedBox(width: 8),
                    const Text('Beli Sekarang',
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Rajdhani',
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            letterSpacing: 1)),
                  ]),
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  STEP 1 — ISI DATA AKUN
// ═══════════════════════════════════════════════════════════════
class _StepIsiData extends StatefulWidget {
  final AccountPlan plan;
  final String durationType;
  final int discount;
  final VoidCallback onNext;
  final VoidCallback onBack;
  final void Function(String requestId, {String? qrisImageUrl, bool autoOrder, int? fee, int? totalWithFee}) onRequestCreated;

  const _StepIsiData({
    required this.plan,
    required this.durationType,
    required this.onNext,
    required this.onBack,
    required this.onRequestCreated,
    this.discount = 0,
  });

  @override
  State<_StepIsiData> createState() => _StepIsiDataState();
}

class _StepIsiDataState extends State<_StepIsiData> {
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _tgCtrl       = TextEditingController();
  final _notesCtrl    = TextEditingController();
  final _voucherCtrl  = TextEditingController();
  bool _loading      = false;
  bool _showPass     = false;
  bool _voucherLoading = false;
  String? _requestId;
  int  _voucherDiscount = 0;   // nominal diskon dari voucher
  String? _voucherCode;        // kode yang berhasil diapply
  String? _voucherError;

  static const _cyan = Color(0xFFFF1744);
  static const _card = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);

  Future<void> _submit() async {
    final u = _usernameCtrl.text.trim();
    final p = _passwordCtrl.text.trim();
    if (u.isEmpty || p.isEmpty) {
      _snack('Username dan password wajib diisi!', isErr: true);
      return;
    }
    if (u.length < 4) {
      _snack('Username minimal 4 karakter!', isErr: true);
      return;
    }
    if (p.length < 6) {
      _snack('Password minimal 6 karakter!', isErr: true);
      return;
    }

    setState(() => _loading = true);
    try {
      final resp = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/submit'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': u,
          'password': p,
          'role': widget.plan.role,
          'durationType': widget.durationType,
          'discount': widget.discount,
          'telegramUsername': _tgCtrl.text.trim(),
          'notes': _notesCtrl.text.trim(),
          'deviceId': await _getDeviceId(),
          'requesterUsername': (await SharedPreferences.getInstance()).getString('username') ?? '',
        }),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(resp.body);
      if (data['isBlocked'] == true) {
        _snack(data['message'] ?? 'Kamu diblokir admin.', isErr: true);
      } else if (data['success'] == true) {
        _requestId = data['requestId'];
        widget.onRequestCreated(
          _requestId!,
          qrisImageUrl: data['qrisImageUrl'] as String?,
          autoOrder: data['autoOrder'] == true,
          fee: (data['fee'] as num?)?.toInt(),
          totalWithFee: (data['totalWithFee'] as num?)?.toInt(),
        );
        widget.onNext();
      } else {
        _snack(data['message'] ?? 'Gagal mengirim request.', isErr: true);
      }
    } catch (e) {
      _snack('Error: ${e.toString()}', isErr: true);
    }
    setState(() => _loading = false);
  }

  void _snack(String msg, {bool isErr = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(fontFamily: 'Rajdhani', color: Colors.white)),
      backgroundColor: isErr ? Colors.red.shade900 : const Color(0xFF059669),
    ));
  }

  Future<void> _applyVoucher(int basePrice) async {
    final code = _voucherCtrl.text.trim().toUpperCase();
    if (code.isEmpty) return;
    setState(() { _voucherLoading = true; _voucherError = null; });
    try {
      final prefs = await SharedPreferences.getInstance();
      final sKey = prefs.getString('sessionKey') ?? '';
      var uname = prefs.getString('username') ?? '';
      if (uname.isEmpty) uname = 'guest-${await _getDeviceId()}';
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/voucher/redeem'),
        headers: {'Content-Type': 'application/json', 'x-session-key': sKey},
        body: jsonEncode({'code': code, 'username': uname}),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        final nominal = (data['nominal'] ?? data['voucher']?['nominal'] ?? 0) as int;
        setState(() { _voucherCode = code; _voucherDiscount = nominal; _voucherError = null; });
        _snack('Voucher berhasil! Hemat Rp $nominal', isErr: false);
      } else {
        setState(() { _voucherError = data['message'] ?? 'Voucher tidak valid'; _voucherCode = null; _voucherDiscount = 0; });
      }
    } catch (_) {
      setState(() => _voucherError = 'Gagal terhubung ke server');
    }
    setState(() => _voucherLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    final price = widget.durationType == 'monthly'
        ? widget.plan.monthlyPrice
        : widget.plan.permanentPrice;
    final hasDisc = widget.discount > 0;
    final discountedPrice = hasDisc ? (price * (100 - widget.discount) / 100).round() : price;
    final finalPrice = (discountedPrice - _voucherDiscount).clamp(0, discountedPrice);
    String fmtP(int v) { final s = v.toString(); final r = RegExp(r'(\d)(?=(\d{3})+(?!\d))'); return 'Rp ' + s.replaceAllMapped(r, (m) => m[1]! + '.'); }
    final priceStr = fmtP(finalPrice);
    final origStr  = fmtP(price);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Summary card
        Container(
          padding: const EdgeInsets.all(16),
          margin: const EdgeInsets.only(bottom: 20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: widget.plan.gradient
                    .map((c) => c.withValues(alpha: 0.15))
                    .toList()),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: widget.plan.gradient[0].withValues(alpha: 0.3)),
          ),
          child: Row(children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: widget.plan.gradient),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(widget.plan.icon, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.plan.title,
                  style: TextStyle(
                      color: widget.plan.gradient[0],
                      fontFamily: 'Rajdhani',
                      fontWeight: FontWeight.bold,
                      fontSize: 16)),
              Text(
                  '$priceStr • ${widget.durationType == 'monthly' ? '1 Bulan' : 'Permanent'}',
                  style: const TextStyle(
                      color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 12)),
            ]),
          ]),
        ),

        // Form
        _buildField('Username', _usernameCtrl, Icons.person_outline_rounded,
            hint: 'min. 4 karakter'),
        const SizedBox(height: 12),
        _buildField('Password', _passwordCtrl, Icons.lock_outline_rounded,
            hint: 'min. 6 karakter',
            obscure: !_showPass,
            suffix: IconButton(
              icon: Icon(
                  _showPass ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: Colors.white38,
                  size: 18),
              onPressed: () => setState(() => _showPass = !_showPass),
            )),
        const SizedBox(height: 12),
        _buildField('Username Telegram (opsional)', _tgCtrl, Icons.telegram,
            hint: '@username (untuk konfirmasi admin)'),
        const SizedBox(height: 12),
        _buildField('Catatan (opsional)', _notesCtrl, Icons.notes_rounded,
            hint: 'Misal: transferan atas nama Budi'),
        const SizedBox(height: 16),

        // Voucher (opsional)
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 3, height: 13, color: const Color(0xFFFFB300), margin: const EdgeInsets.only(right: 8)),
            const Text('KODE VOUCHER', style: TextStyle(color: Color(0xFFFFB300), fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
            const SizedBox(width: 6),
            const Text('(opsional)', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 10)),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF080D14),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _voucherCode != null
                      ? const Color(0xFF22C55E).withValues(alpha: 0.6)
                      : _voucherError != null
                          ? const Color(0xFFFF1744).withValues(alpha: 0.5)
                          : const Color(0xFFFFB300).withValues(alpha: 0.3)),
                ),
                child: TextField(
                  controller: _voucherCtrl,
                  enabled: _voucherCode == null,
                  style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 14, letterSpacing: 1),
                  textCapitalization: TextCapitalization.characters,
                  decoration: InputDecoration(
                    hintText: 'Masukkan kode voucher...',
                    hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 13),
                    prefixIcon: Icon(Icons.local_offer_rounded,
                      color: _voucherCode != null ? const Color(0xFF22C55E) : const Color(0xFFFFB300), size: 18),
                    suffixIcon: _voucherCode != null
                        ? IconButton(
                            icon: const Icon(Icons.close_rounded, color: Colors.white38, size: 16),
                            onPressed: () => setState(() { _voucherCode = null; _voucherDiscount = 0; _voucherCtrl.clear(); }),
                          )
                        : null,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            if (_voucherCode == null)
              GestureDetector(
                onTap: _voucherLoading ? null : () => _applyVoucher(finalPrice),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFFFFB300), Color(0xFFFF8C00)]),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [BoxShadow(color: const Color(0xFFFFB300).withValues(alpha: 0.35), blurRadius: 10)],
                  ),
                  child: _voucherLoading
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : const Text('PAKAI', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1)),
                ),
              ),
          ]),
          if (_voucherError != null) ...[
            const SizedBox(height: 6),
            Row(children: [
              const Icon(Icons.error_outline_rounded, color: Color(0xFFFF1744), size: 14),
              const SizedBox(width: 6),
              Text(_voucherError!, style: const TextStyle(color: Color(0xFFFF1744), fontFamily: 'Rajdhani', fontSize: 12)),
            ]),
          ],
          if (_voucherCode != null) ...[
            const SizedBox(height: 6),
            Row(children: [
              const Icon(Icons.check_circle_rounded, color: Color(0xFF22C55E), size: 14),
              const SizedBox(width: 6),
              Text('Hemat Rp $_voucherDiscount!', style: const TextStyle(color: Color(0xFF22C55E), fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 12)),
            ]),
          ],
        ]),
        const SizedBox(height: 24),

        // Submit button
        GestureDetector(
          onTap: _loading ? null : _submit,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: widget.plan.gradient),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                    color: widget.plan.gradient[0].withValues(alpha: 0.35),
                    blurRadius: 14,
                    spreadRadius: 1)
              ],
            ),
            child: Center(
              child: _loading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2))
                  : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.arrow_forward_rounded,
                            color: Colors.white, size: 18),
                        SizedBox(width: 8),
                        Text('Lanjut ke Pembayaran',
                            style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'Rajdhani',
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                                letterSpacing: 1)),
                      ],
                    ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildField(
    String label,
    TextEditingController ctrl,
    IconData icon, {
    String hint = '',
    bool obscure = false,
    Widget? suffix,
  }) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label,
          style: const TextStyle(
              color: Colors.white60,
              fontFamily: 'Rajdhani',
              fontSize: 12,
              letterSpacing: 0.5)),
      const SizedBox(height: 5),
      Container(
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _border),
        ),
        child: TextField(
          controller: ctrl,
          obscureText: obscure,
          style: const TextStyle(
              color: Colors.white, fontFamily: 'Rajdhani', fontSize: 14),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: Colors.white24, fontSize: 13),
            prefixIcon: Icon(icon, color: _cyan.withValues(alpha: 0.5), size: 18),
            suffixIcon: suffix,
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          ),
        ),
      ),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════
//  STEP 2 — BAYAR (QRIS + UPLOAD BUKTI)
// ═══════════════════════════════════════════════════════════════
class _StepBayar extends StatefulWidget {
  final AccountPlan plan;
  final String durationType;
  final String requestId;
  final VoidCallback? onDone;
  final void Function(String id)? onSuccess;
  final bool isUpgrade;
  final String? upgradeUsername;
  final String? qrisImageUrl;
  final bool autoOrder;
  final int? qrisFee;
  final int? totalWithFee;
  final int discount;
  final void Function(String id, {String? qrisImageUrl, bool autoOrder, int? fee, int? totalWithFee})? onRequestIdAssigned;

  const _StepBayar({
    required this.plan,
    required this.durationType,
    required this.requestId,
    this.onDone,
    this.onSuccess,
    this.isUpgrade = false,
    this.upgradeUsername,
    this.qrisImageUrl,
    this.autoOrder = false,
    this.qrisFee,
    this.totalWithFee,
    this.discount = 0,
    this.onRequestIdAssigned,
  });

  @override
  State<_StepBayar> createState() => _StepBayarState();
}

class _StepBayarState extends State<_StepBayar> {
  // Tab: 0=Info, 1=Upload bukti
  int _tab = 0;
  Uint8List? _buktiBytes;
  String _buktiName = '';
  bool _loading = false;

  // QRIS dinamis (kalau Auto Order ON) — diisi dari response API
  String? _liveQrisImageUrl;
  bool _liveAutoOrder = false;
  int? _liveFee;
  int? _liveTotalWithFee;
  String? _earlyRequestId; // requestId hasil submit-upgrade otomatis

  String get _effectiveRequestId =>
      widget.requestId.trim().isNotEmpty ? widget.requestId.trim() : (_earlyRequestId ?? '');

  static const _cyan = Color(0xFFFF1744);
  static const _card = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);

  @override
  void initState() {
    super.initState();
    _liveQrisImageUrl = widget.qrisImageUrl;
    _liveAutoOrder = widget.autoOrder;
    _liveFee = widget.qrisFee;
    _liveTotalWithFee = widget.totalWithFee;

    // Untuk upgrade: requestId belum dibuat di step sebelumnya.
    // Hanya buat lebih awal kalau Auto Order ON, biar QRIS dinamis
    // bisa langsung tampil. Kalau OFF, biarkan flow lama (request
    // baru dibuat saat user klik "Kirim Bukti") agar tidak ada
    // request "hantu" tiap kali halaman ini dibuka.
    if (widget.isUpgrade && widget.requestId.trim().isEmpty) {
      _checkAutoOrderThenCreate();
    }
  }

  Future<void> _checkAutoOrderThenCreate() async {
    // Langsung create request tanpa cek status dulu — lebih cepat
    // API sendiri yang akan return autoOrder true/false
    await _createUpgradeRequestEarly();
  }

  Future<void> _createUpgradeRequestEarly() async {
    try {
      final resp = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/submit-upgrade'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.upgradeUsername,
          'newRole': widget.plan.role,
          'durationType': widget.durationType,
          'deviceId': await _getDeviceId(),
        }),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(resp.body);
      if (data['success'] == true) {
        final newReqId = data['requestId'] ?? '';
        final qrisUrl = data['qrisImageUrl'] as String?;
        final autoOrder = data['autoOrder'] == true;
        final fee = (data['fee'] as num?)?.toInt();
        final totalWithFee = (data['totalWithFee'] as num?)?.toInt();

        if (newReqId.isNotEmpty) {
          _earlyRequestId = newReqId;
          if (mounted) {
            setState(() {
              _liveQrisImageUrl = qrisUrl;
              _liveAutoOrder = autoOrder;
              _liveFee = fee;
              _liveTotalWithFee = totalWithFee;
            });
          }
          widget.onRequestIdAssigned?.call(newReqId, qrisImageUrl: qrisUrl, autoOrder: autoOrder, fee: fee, totalWithFee: totalWithFee);
        }
      }
    } catch (_) {
      // Diamkan — fallback ke QRIS statis & flow upload bukti manual
      // akan tetap men-submit ulang saat user klik "Kirim Bukti".
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
        source: ImageSource.gallery, imageQuality: 90, maxWidth: 1920, maxHeight: 1920);
    if (picked != null) {
      final bytes = await picked.readAsBytes();
      setState(() {
        _buktiBytes = bytes;
        _buktiName = picked.name;
      });
    }
  }

  Future<void> _uploadBukti() async {
    final reqId = _effectiveRequestId;

    // Kalau upgrade dan belum ada requestId → submit upgrade dulu
    if (widget.isUpgrade && reqId.isEmpty) {
      setState(() => _loading = true);
      try {
        final resp = await http.post(
          Uri.parse('${AppConfig.baseUrl}/api/requestkey/submit-upgrade'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'username': widget.upgradeUsername,
            'newRole': widget.plan.role,
            'durationType': widget.durationType,
            'deviceId': await _getDeviceId(),
          }),
        ).timeout(const Duration(seconds: 15));
        final data = jsonDecode(resp.body);
        if (data['isBlocked'] == true) {
          _snack(data['message'] ?? 'Kamu diblokir admin.', isErr: true);
          setState(() => _loading = false);
          return;
        }
        if (data['success'] != true) {
          _snack(data['message'] ?? 'Gagal submit upgrade.', isErr: true);
          setState(() => _loading = false);
          return;
        }

        // Dapat requestId → langsung upload bukti
        final newReqId = data['requestId'] ?? '';
        if (newReqId.isEmpty) {
          _snack('Request ID tidak ditemukan dari server.', isErr: true);
          setState(() => _loading = false);
          return;
        }
        if (_buktiBytes == null) {
          // Submit berhasil tapi bukti belum dipilih, simpan requestId dulu
          _snack('Request dikirim! Sekarang pilih foto bukti transfer.', isErr: false);
          if (widget.onSuccess != null) widget.onSuccess!(newReqId);
          setState(() => _loading = false);
          return;
        }

        // Upload bukti langsung dengan requestId baru
        try {
          // Kompresi jika gambar masih terlalu besar (> 300KB)
          Uint8List imgBytes = _buktiBytes!;
          if (imgBytes.lengthInBytes > 300 * 1024) {
            final picker2 = ImagePicker();
            final tmp = await picker2.pickImage(
              source: ImageSource.gallery, imageQuality: 90, maxWidth: 1920, maxHeight: 1920);
            if (tmp != null) imgBytes = await tmp.readAsBytes();
          }
          final base64Str = base64Encode(imgBytes);
          final buktiResp = await http.post(
            Uri.parse('${AppConfig.baseUrl}/api/requestkey/bukti'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'requestId': newReqId, 'buktiBase64': base64Str}),
          ).timeout(const Duration(seconds: 90));
          final buktiRespData = jsonDecode(buktiResp.body);
          if (buktiRespData['success'] == true) {
            if (widget.onSuccess != null) widget.onSuccess!(newReqId);
          } else {
            _snack(buktiRespData['message'] ?? 'Gagal upload bukti.', isErr: true);
          }
        } catch (_) {
          _snack('Gagal upload bukti ke server.', isErr: true);
        }
        setState(() => _loading = false);
        return;
      } catch (e) {
        _snack('Gagal terhubung ke server.', isErr: true);
        setState(() => _loading = false);
        return;
      }
    }

    if (reqId.isEmpty) {
      _snack('Request ID tidak ditemukan!', isErr: true);
      return;
    }
    if (_buktiBytes == null) {
      _snack('Pilih foto bukti transfer dulu!', isErr: true);
      return;
    }

    setState(() => _loading = true);
    try {
      // Kirim langsung, sudah dikompresi saat pick
      final base64Str = base64Encode(_buktiBytes!);
      final resp = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/bukti'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'requestId': reqId, 'buktiBase64': base64Str}),
      ).timeout(const Duration(seconds: 90));

      final data = jsonDecode(resp.body);
      if (data['success'] == true) {
        final id = data['requestId'] ?? widget.requestId;
        if (widget.onSuccess != null) {
          widget.onSuccess!(id);
        } else {
          widget.onDone?.call();
        }
      } else {
        _snack(data['message'] ?? 'Gagal upload bukti.', isErr: true);
      }
    } catch (e) {
      _snack('Error: ${e.toString()}', isErr: true);
    }
    setState(() => _loading = false);
  }

  void _snack(String msg, {bool isErr = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani')),
      backgroundColor: isErr ? Colors.red.shade900 : const Color(0xFF059669),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final price = widget.durationType == 'monthly'
        ? widget.plan.monthlyPrice
        : widget.plan.permanentPrice;
    final hasDisc = widget.discount > 0;
    final finalPrice = hasDisc ? (price * (100 - widget.discount) / 100).round() : price;
    String fmtRp(int v) =>
        'Rp ${v.toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}';
    final priceStr = fmtRp(finalPrice);
    final origStr  = fmtRp(price);
    return Column(children: [
      // Tab bar
      Container(
        color: const Color(0xFF080D14),
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          _TabBtn(
              label: 'QRIS Bayar', icon: Icons.qr_code_rounded,
              active: _tab == 0,
              onTap: () => setState(() => _tab = 0)),
          const SizedBox(width: 8),
          _TabBtn(
              label: 'Kirim Bukti', icon: Icons.camera_alt_rounded,
              active: _tab == 1,
              onTap: () => setState(() => _tab = 1)),
        ]),
      ),

      Expanded(
        child: _tab == 0 ? _buildQrisTab(priceStr, fmtRp, hasDisc, origStr) : _buildUploadBuktiTab(priceStr),
      ),
    ]);
  }

  // ── Tab 0: QRIS ─────────────────────────────────────────────────
  Widget _buildQrisTab(String priceStr, String Function(int) fmtRp, bool hasDisc, String origStr) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      // Nominal info
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _border),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(Icons.receipt_long_outlined, color: _cyan, size: 18),
            const SizedBox(width: 8),
            const Text('Detail Pembayaran',
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.bold,
                    fontSize: 15)),
          ]),
          const SizedBox(height: 12),
          _rowDetail('Paket', widget.plan.title),
          _rowDetail('Durasi',
              widget.durationType == 'monthly' ? '1 Bulan' : 'Permanent'),
          const Divider(color: Color(0xFF1A2840), height: 20),
          if (_liveAutoOrder && _liveFee != null && _liveFee! > 0) ...[
            if (hasDisc) _rowDetail('Harga Asli', origStr, strike: true),
            if (hasDisc) _rowDetail('Diskon', '-${widget.discount}%', color: const Color(0xFFFF9100)),
            _rowDetail('Harga Produk', priceStr),
            _rowDetail('Fee QRIS', '+ ${fmtRp(_liveFee!)}'),
            const Divider(color: Color(0xFF1A2840), height: 20),
          ],
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Total Bayar',
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.bold,
                    fontSize: 15)),
            Text(
              (_liveAutoOrder && _liveTotalWithFee != null)
                  ? fmtRp(_liveTotalWithFee!)
                  : priceStr,
              style: TextStyle(
                  color: _cyan,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.bold,
                  fontSize: 17),
            ),
          ]),
          if (_liveAutoOrder && _liveFee != null && _liveFee! > 0)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                '*Sudah termasuk fee QRIS otomatis ${fmtRp(_liveFee!)} (ditanggung pembeli). Bayar sesuai nominal di atas, bukan harga produk.',
                style: const TextStyle(
                    color: Colors.white54,
                    fontFamily: 'Rajdhani',
                    fontSize: 11,
                    height: 1.4),
              ),
            ),
        ]),
      ),

      const SizedBox(height: 16),

      // QRIS image
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _border),
        ),
        child: Column(children: [
          Row(children: [
            Icon(Icons.qr_code_scanner_rounded, color: _cyan, size: 18),
            const SizedBox(width: 8),
            const Text('QRIS Admin',
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.bold,
                    fontSize: 15)),
          ]),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: _liveAutoOrder && (_liveQrisImageUrl == null || _liveQrisImageUrl!.isEmpty)
                ? Container(
                    height: 200,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _border),
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      CircularProgressIndicator(color: _cyan, strokeWidth: 2),
                      const SizedBox(height: 12),
                      const Text('Memuat QRIS Auto Order...',
                          style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 12)),
                    ]),
                  )
                : Image.network(
                    _liveAutoOrder ? (_liveQrisImageUrl ?? '') : (_liveQrisImageUrl ?? _qrisImageUrl),
                    width: double.infinity,
                    fit: BoxFit.contain,
                    loadingBuilder: (ctx, child, progress) {
                      if (progress == null) return child;
                      return Container(
                        height: 200,
                        alignment: Alignment.center,
                        child: CircularProgressIndicator(
                            color: _cyan, strokeWidth: 2),
                      );
                    },
                    errorBuilder: (_, __, ___) => Container(
                      width: double.infinity,
                      height: 200,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _border),
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.qr_code_2_rounded, color: _cyan.withValues(alpha: 0.4), size: 60),
                        const SizedBox(height: 8),
                        const Text('QRIS tidak tersedia\nHubungi admin',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
                      ]),
                    ),
                  ),
          ),
          const SizedBox(height: 12),
          if (_liveAutoOrder)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: _cyan.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _cyan.withValues(alpha: 0.4)),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.bolt_rounded, color: _cyan, size: 15),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                    'Auto Order Aktif — akun otomatis aktif setelah QRIS dibayar (maks. 15 menit), tanpa perlu upload bukti.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: _cyan,
                        fontFamily: 'Rajdhani',
                        fontSize: 12,
                        height: 1.4),
                  ),
                ),
              ]),
            ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF059669).withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFF059669).withValues(alpha: 0.3)),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.info_outline_rounded, color: Color(0xFF059669), size: 15),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  _liveAutoOrder
                      ? 'Scan QRIS lalu bayar sesuai nominal. Akun akan aktif otomatis setelah pembayaran terverifikasi.'
                      : 'Scan QRIS lalu bayar sesuai nominal. Setelah bayar, pindah ke tab "Kirim Bukti".',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: Color(0xFF059669),
                      fontFamily: 'Rajdhani',
                      fontSize: 12,
                      height: 1.4),
                ),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          // Tombol lanjut ke tab upload (disembunyikan saat Auto Order ON)
          if (!_liveAutoOrder)
            GestureDetector(
              onTap: () => setState(() => _tab = 1),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 13),
                decoration: BoxDecoration(
                  color: _cyan.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _cyan.withValues(alpha: 0.4)),
                ),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Text('Sudah Bayar? Kirim Bukti →',
                      style: TextStyle(
                          color: _cyan,
                          fontFamily: 'Rajdhani',
                          fontWeight: FontWeight.bold,
                          fontSize: 14)),
                ]),
              ),
            )
          else
            GestureDetector(
              onTap: widget.onDone ?? () => widget.onSuccess?.call(_effectiveRequestId),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 13),
                decoration: BoxDecoration(
                  color: const Color(0xFF059669).withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF059669).withValues(alpha: 0.4)),
                ),
                child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('Sudah Bayar / Cek Status →',
                      style: TextStyle(
                          color: Color(0xFF059669),
                          fontFamily: 'Rajdhani',
                          fontWeight: FontWeight.bold,
                          fontSize: 14)),
                ]),
              ),
            ),
        ]),
      ),
    ]);
  }

  // ── Tab 1: Upload Bukti ──────────────────────────────────────────
  Widget _buildUploadBuktiTab(String priceStr) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      // Info harga ringkas
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _border),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(Icons.receipt_long_outlined, color: _cyan, size: 18),
            const SizedBox(width: 8),
            const Text('Detail Pembayaran',
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.bold,
                    fontSize: 15)),
          ]),
          const SizedBox(height: 12),
          _rowDetail('Paket', widget.plan.title),
          _rowDetail('Durasi',
              widget.durationType == 'monthly' ? '1 Bulan' : 'Permanent'),
          _rowDetail('Total', priceStr),
        ]),
      ),

      const SizedBox(height: 16),

      // Upload bukti
      const Text('Foto Bukti Transfer',
          style: TextStyle(
              color: Colors.white60, fontFamily: 'Rajdhani', fontSize: 12)),
      const SizedBox(height: 8),
      GestureDetector(
        onTap: _pickImage,
        child: Container(
          width: double.infinity,
          height: 180,
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: _buktiBytes != null ? _cyan.withValues(alpha: 0.6) : _border,
                width: _buktiBytes != null ? 1.5 : 1),
          ),
          child: _buktiBytes != null
              ? Stack(children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(13),
                    child: Image.memory(_buktiBytes!,
                        width: double.infinity,
                        height: double.infinity,
                        fit: BoxFit.cover),
                  ),
                  // Ganti foto button
                  Positioned(
                    top: 8, right: 8,
                    child: GestureDetector(
                      onTap: _pickImage,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.65),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _cyan.withValues(alpha: 0.5)),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.max, mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.edit_rounded, color: _cyan, size: 12),
                          const SizedBox(width: 4),
                          const Text('Ganti',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Rajdhani',
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold)),
                        ]),
                      ),
                    ),
                  ),
                  // Nama file
                  Positioned(
                    bottom: 8, left: 8, right: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.65),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(children: [
                        Icon(Icons.image_rounded, color: _cyan, size: 13),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(_buktiName,
                              style: const TextStyle(
                                  color: Colors.white70,
                                  fontFamily: 'Rajdhani',
                                  fontSize: 11),
                              overflow: TextOverflow.ellipsis),
                        ),
                        Icon(Icons.check_circle_rounded, color: const Color(0xFF059669), size: 14),
                      ]),
                    ),
                  ),
                ])
              : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    width: 56, height: 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _cyan.withValues(alpha: 0.1),
                      border: Border.all(color: _cyan.withValues(alpha: 0.3)),
                    ),
                    child: Icon(Icons.add_photo_alternate_outlined,
                        color: _cyan.withValues(alpha: 0.7), size: 26),
                  ),
                  const SizedBox(height: 10),
                  const Text('Tap untuk pilih foto bukti transfer',
                      style: TextStyle(
                          color: Colors.white54,
                          fontFamily: 'Rajdhani',
                          fontSize: 13)),
                  const SizedBox(height: 4),
                  const Text('Format: JPG / PNG',
                      style: TextStyle(
                          color: Colors.white24,
                          fontFamily: 'Rajdhani',
                          fontSize: 11)),
                ]),
        ),
      ),

      const SizedBox(height: 20),

      // Tombol kirim
      GestureDetector(
        onTap: _loading ? null : _uploadBukti,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 15),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: widget.plan.gradient),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                  color: widget.plan.gradient[0].withValues(alpha: 0.35),
                  blurRadius: 12)
            ],
          ),
          child: Center(
            child: _loading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2))
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.send_rounded, color: Colors.white, size: 17),
                      SizedBox(width: 8),
                      Text('Kirim Bukti ke Admin',
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Rajdhani',
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              letterSpacing: 1)),
                    ],
                  ),
          ),
        ),
      ),

      const SizedBox(height: 12),
      const Text(
        '* Setelah bukti dikirim, admin akan memproses dan mengaktifkan akun kamu.',
        style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11),
        textAlign: TextAlign.center,
      ),
    ]);
  }

  Widget _rowDetail(String label, String value, {bool strike = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label,
            style: const TextStyle(
                color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13)),
        Text(value,
            style: TextStyle(
                color: color ?? Colors.white,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.bold,
                fontSize: 13,
                decoration: strike ? TextDecoration.lineThrough : null,
                decorationColor: Colors.white38)),
      ]),
    );
  }
}

class _TabBtn extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  final IconData? icon;
  static const _cyan = Color(0xFFFF1744);
  static const _card = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);

  const _TabBtn({required this.label, required this.active, required this.onTap, this.icon});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? _cyan.withValues(alpha: 0.18) : _card,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
                color: active ? _cyan.withValues(alpha: 0.5) : _border),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 15, color: active ? _cyan : Colors.white38),
                const SizedBox(width: 6),
              ],
              Text(label,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: active ? _cyan : Colors.white38,
                      fontFamily: 'Rajdhani',
                      fontWeight: FontWeight.bold,
                      fontSize: 13)),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  STEP 3 — SUKSES
// ═══════════════════════════════════════════════════════════════
class StepSukses extends StatefulWidget {
  final VoidCallback onHome;
  final String requestId;
  const StepSukses({required this.onHome, required this.requestId});

  @override
  State<StepSukses> createState() => _StepSuksesState();
}

class _StepSuksesState extends State<StepSukses>
    with SingleTickerProviderStateMixin {
  String _status = 'pending';
  String _prevStatus = 'pending';
  bool _loadingStatus = false;
  Timer? _timer;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  bool _showRankUp = false;

  // Support chat
  final List<Map<String, dynamic>> _chatMessages = [];
  final TextEditingController _chatCtrl = TextEditingController();
  bool _sendingChat = false;
  bool _sendingImage = false;
  bool _chatExpanded = false;
  int _unreadCount = 0;
  int _lastReadCount = 0;
  bool _isBlocked = false;
  bool _isClosed = false;
  String _closedReason = '';
  String _blockReason = '';
  String _deviceId = 'unknown';
  final ScrollController _chatScroll = ScrollController();
  Timer? _chatTimer;
  bool _adminOnline = false;
  Timer? _adminStatusTimer;

    static const _cyan = Color(0xFFFF1744);
  static const _card = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _checkStatus();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _checkStatus());
    _loadChatHistory();
    _chatTimer = Timer.periodic(const Duration(seconds: 5), (_) => _loadChatHistory());
    _fetchDeviceId();
    _fetchAdminStatus();
    _adminStatusTimer = Timer.periodic(const Duration(seconds: 15), (_) => _fetchAdminStatus());
  }

  Future<void> _fetchAdminStatus() async {
    try {
      final resp = await http
          .get(Uri.parse('${AppConfig.baseUrl}/api/support/admin-status'))
          .timeout(const Duration(seconds: 8));
      final data = jsonDecode(resp.body);
      if (data['success'] == true && mounted) {
        setState(() => _adminOnline = data['online'] == true);
      }
    } catch (_) {}
  }

  Future<void> _fetchDeviceId() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      if (defaultTargetPlatform == TargetPlatform.android) {
        final androidInfo = await deviceInfo.androidInfo;
        setState(() => _deviceId = androidInfo.id);
      } else if (defaultTargetPlatform == TargetPlatform.iOS) {
        final iosInfo = await deviceInfo.iosInfo;
        setState(() => _deviceId = iosInfo.identifierForVendor ?? 'unknown');
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _timer?.cancel();
    _chatTimer?.cancel();
    _adminStatusTimer?.cancel();
    _pulseCtrl.dispose();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    super.dispose();
  }

  Future<void> _loadChatHistory() async {
    final reqId = widget.requestId.trim();
    if (reqId.isEmpty) return;
    try {
      final uri = Uri.parse('${AppConfig.baseUrl}/api/support/history?requestId=$reqId&deviceId=$_deviceId');
      final resp = await http.get(uri).timeout(const Duration(seconds: 10));
      final data = jsonDecode(resp.body);
      if (data['success'] == true && mounted) {
        final msgs = List<Map<String, dynamic>>.from(data['messages']);
        final adminMsgs = msgs.where((m) => m['from'] == 'admin').length;
        setState(() {
          _chatMessages..clear()..addAll(msgs);
          _isBlocked = data['isBlocked'] ?? false;
          _isClosed  = data['isClosed']  ?? false;
          _closedReason = data['closedReason'] ?? '';
          _blockReason = data['blockReason'] ?? '';
          if (!_chatExpanded) {
            _unreadCount = adminMsgs - _lastReadCount;
            if (_unreadCount < 0) _unreadCount = 0;
          }
        });
        Future.delayed(const Duration(milliseconds: 100), () {
          if (_chatScroll.hasClients) {
            _chatScroll.animateTo(_chatScroll.position.maxScrollExtent,
                duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
          }
        });
      }
    } catch (_) {}
  }

  Future<void> _sendChatMsg() async {
    final text = _chatCtrl.text.trim();
    if (text.isEmpty) return;
    if (_isClosed) {
      _snack('Chat sudah ditutup oleh admin.', isErr: true);
      return;
    }
    setState(() => _sendingChat = true);
    try {
      final resp = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/support/send'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'requestId': widget.requestId, 'username': 'User', 'message': text, 'deviceId': _deviceId}),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(resp.body);
      if (data['success'] == true) {
        _chatCtrl.clear();
        await _loadChatHistory();
      }
    } catch (_) {}
    if (mounted) setState(() => _sendingChat = false);
  }

  Future<void> _closeChat(String reason) async {
    try {
      await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/support/close'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'reason': reason}),
      );
      setState(() { _isClosed = true; _closedReason = reason; });
      _snack('Chat support ditutup');
    } catch (_) {
      _snack('Gagal menutup chat', isErr: true);
    }
  }

  Future<void> _openChat() async {
    try {
      await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/support/open'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({}),
      );
      setState(() { _isClosed = false; _closedReason = ''; });
      _snack('Chat support dibuka kembali');
    } catch (_) {
      _snack('Gagal membuka chat', isErr: true);
    }
  }

  Future<void> _sendChatImage() async {
    final picker = ImagePicker();
    final picked = await showModalBottomSheet<XFile?>(
      context: context,
      backgroundColor: const Color(0xFF0D1520),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 16),
          const Text('Kirim Media', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: GestureDetector(
              onTap: () async {
                final f = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
                Navigator.pop(context, f);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(color: _cyan.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(14), border: Border.all(color: _cyan.withValues(alpha: 0.3))),
                child: const Column(children: [
                  Icon(Icons.photo_library_rounded, color: _cyan, size: 28),
                  SizedBox(height: 6),
                  Text('Galeri', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
                ]),
              ),
            )),
            const SizedBox(width: 12),
            Expanded(child: GestureDetector(
              onTap: () async {
                final f = await picker.pickImage(source: ImageSource.camera, imageQuality: 70);
                Navigator.pop(context, f);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(color: _cyan.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(14), border: Border.all(color: _cyan.withValues(alpha: 0.3))),
                child: const Column(children: [
                  Icon(Icons.camera_alt_rounded, color: _cyan, size: 28),
                  SizedBox(height: 6),
                  Text('Kamera', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
                ]),
              ),
            )),
            const SizedBox(width: 12),
            Expanded(child: GestureDetector(
              onTap: () async {
                final f = await picker.pickVideo(source: ImageSource.gallery);
                Navigator.pop(context, f);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(color: Colors.purple.withOpacity(0.1), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.purple.withOpacity(0.3))),
                child: const Column(children: [
                  Icon(Icons.videocam_rounded, color: Colors.purple, size: 28),
                  SizedBox(height: 6),
                  Text('Video', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
                ]),
              ),
            )),
          ]),
          const SizedBox(height: 16),
        ]),
      ),
    );

    if (picked == null) return;
    setState(() => _sendingImage = true);

    try {
      final bytes = await picked.readAsBytes();
      final base64Data = base64Encode(bytes);
      final isVideo = picked.path.endsWith('.mp4') || picked.path.endsWith('.mov') || picked.path.endsWith('.avi');

      final resp = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/support/send-media'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'requestId': widget.requestId,
          'username': 'User',
          'mediaBase64': base64Data,
          'mediaType': isVideo ? 'video' : 'image',
          'fileName': picked.name,
          'deviceId': _deviceId,
        }),
      ).timeout(const Duration(seconds: 60));

      final data = jsonDecode(resp.body);
      if (data['success'] == true) await _loadChatHistory();
    } catch (_) {}

    if (mounted) setState(() => _sendingImage = false);
  }

  void _openImageFull(BuildContext context, String imageUrl, Uint8List? imageBytes) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.download_rounded, color: Colors.white),
              onPressed: () {},
            ),
          ],
        ),
        body: Center(
          child: InteractiveViewer(
            panEnabled: true,
            minScale: 0.5,
            maxScale: 5,
            child: imageBytes != null
                ? Image.memory(imageBytes, fit: BoxFit.contain)
                : Image.network(imageUrl, fit: BoxFit.contain,
                    loadingBuilder: (_, child, progress) =>
                        progress == null ? child : const CircularProgressIndicator(color: _cyan)),
          ),
        ),
      ),
    ));
  }

  Future<void> _checkStatus() async {
    final reqId = widget.requestId.trim();
    if (reqId.isEmpty) return;
    setState(() => _loadingStatus = true);
    try {
      final uri = Uri.parse('${AppConfig.baseUrl}/api/requestkey/status?requestId=$reqId');
      final resp = await http.get(uri).timeout(const Duration(seconds: 15));
      final data = jsonDecode(resp.body);
      if (data['success'] == true) {
        setState(() {
          final newStatus = data['status'] ?? 'pending';
          final reqType = data['type'] ?? 'request';
          // Hanya tampil rank-up animation kalau tipe 'upgrade', bukan 'request' (akun baru)
          if (_prevStatus != 'approved' && newStatus == 'approved' && reqType == 'upgrade') {
            _showRankUp = true;
          }
          _prevStatus = newStatus;
          _status = newStatus;
        });
      }
    } catch (_) {}
    setState(() => _loadingStatus = false);
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTextStyle(
      style: const TextStyle(decoration: TextDecoration.none, decorationColor: Colors.transparent),
      child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        const SizedBox(height: 20),

        // Status display - approved = animasi naik pangkat epic!
        if (_status == 'approved' && _showRankUp) ...[
          // Confetti particles
          SizedBox(
            height: 8,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(7, (i) => Container(
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: 6, height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: [
                    const Color(0xFFFF1744),
                    const Color(0xFFFFD700),
                    const Color(0xFF00E676),
                    const Color(0xFF7C4DFF),
                    const Color(0xFF00E5FF),
                    const Color(0xFFFF6D00),
                    const Color(0xFFFF4081),
                  ][i],
                ),
              )),
            ),
          ),
          const SizedBox(height: 16),

          // Icon naik pangkat - animasi pulse
          ScaleTransition(
            scale: _pulseAnim,
            child: Container(
              width: 120, height: 120,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [Color(0xFFFFD700), Color(0xFFFF6D00)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(color: const Color(0xFFFFD700).withValues(alpha: 0.6), blurRadius: 30, spreadRadius: 5),
                  BoxShadow(color: const Color(0xFFFF6D00).withValues(alpha: 0.3), blurRadius: 50, spreadRadius: 10),
                ],
              ),
              child: const Icon(Icons.military_tech_rounded, color: Colors.white, size: 64),
            ),
          ),
          const SizedBox(height: 20),

          // Teks NAIK PANGKAT atau AKUN BERHASIL DIBUAT
          ShaderMask(
            shaderCallback: (b) => const LinearGradient(
              colors: [Color(0xFFFFD700), Color(0xFFFF6D00), Color(0xFFFFD700)],
            ).createShader(b),
            child: Text(
              _showRankUp ? 'NAIK PANGKAT!' : 'AKUN BERHASIL DIBUAT!',
              style: const TextStyle(
                color: Colors.white,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w900,
                fontSize: 28,
                letterSpacing: 2,
              ),
            ),
          ),
          const SizedBox(height: 8),

          const Text(
            'Selamat! Role kamu berhasil di-upgrade oleh admin!',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white70,
              fontFamily: 'Rajdhani',
              fontSize: 15,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Nikmati fitur baru kamu',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFFFFD700),
              fontFamily: 'Rajdhani',
              fontSize: 13,
              fontWeight: FontWeight.bold,
            ),
          ),
        ] else ...[
          // Status icon normal (pending/rejected)
          Container(
            width: 100, height: 100,
            decoration: BoxDecoration(
              color: _statusColor().withValues(alpha: 0.12),
              shape: BoxShape.circle,
              border: Border.all(color: _statusColor().withValues(alpha: 0.4), width: 2.5),
            ),
            child: Icon(_statusIcon(), color: _statusColor(), size: 52),
          ),
          const SizedBox(height: 20),
          Text(_statusTitle(),
              style: const TextStyle(
                  color: Colors.white, fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.bold, fontSize: 26)),
          const SizedBox(height: 8),
          Text(_statusDesc(),
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: Colors.white54, fontFamily: 'Rajdhani',
                  fontSize: 14, height: 1.5)),
        ],

        const SizedBox(height: 28),

        // Info card
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _border),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.info_outline_rounded, color: _cyan, size: 16),
              const SizedBox(width: 8),
              const Text('Info Request',
                  style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Rajdhani',
                      fontWeight: FontWeight.bold,
                      fontSize: 15)),
            ]),
            const SizedBox(height: 14),

            const SizedBox(height: 8),
            _infoRow(Icons.access_time_rounded, 'Status',
                _status == 'pending'
                    ? 'Menunggu konfirmasi admin'
                    : _status == 'approved'
                        ? 'Disetujui'
                        : 'Ditolak'),
            const SizedBox(height: 8),
            _infoRow(Icons.support_agent_rounded, 'Proses',
                'Admin akan mengaktifkan akun dalam waktu singkat'),
          ]),
        ),

        const SizedBox(height: 16),

        // Status timeline
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _border),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('PROGRES',
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    letterSpacing: 1.5)),
            const SizedBox(height: 16),
            _timelineItem(
              icon: Icons.person_outline_rounded,
              title: 'Request Dibuat',
              subtitle: 'Data akun berhasil dikirim',
              done: true,
              color: const Color(0xFF059669),
            ),
            _timelineLine(done: true),
            _timelineItem(
              icon: Icons.qr_code_scanner_rounded,
              title: 'Bukti Transfer Dikirim',
              subtitle: 'Menunggu verifikasi admin',
              done: true,
              color: _cyan,
            ),
            _timelineLine(done: _status != 'pending'),
            _timelineItem(
              icon: _status == 'approved'
                  ? Icons.check_circle_outline_rounded
                  : _status == 'rejected'
                      ? Icons.cancel_outlined
                      : Icons.hourglass_empty_rounded,
              title: _status == 'approved'
                  ? (_showRankUp ? 'Role Di-upgrade!' : 'Akun Berhasil Dibuat!')
                  : _status == 'rejected'
                      ? 'Request Ditolak'
                      : 'Konfirmasi Admin',
              subtitle: _status == 'approved'
                  ? (_showRankUp ? 'Selamat naik pangkat!' : 'Selamat! Akun kamu siap digunakan')
                  : _status == 'rejected'
                      ? 'Hubungi admin untuk info lebih lanjut'
                      : 'Sedang diproses oleh admin...',
              done: _status != 'pending',
              color: _statusColor(),
            ),
          ]),
        ),

        const SizedBox(height: 16),

        // ── Chat Admin Mini ──────────────────────────────────
        GestureDetector(
          onTap: () {
            setState(() {
              _chatExpanded = !_chatExpanded;
              if (_chatExpanded) {
                // Clear badge saat dibuka
                _lastReadCount = _chatMessages.where((m) => m['from'] == 'admin').length;
                _unreadCount = 0;
              }
            });
          },
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _chatExpanded ? _cyan.withValues(alpha: 0.5) : _unreadCount > 0 ? _cyan.withValues(alpha: 0.6) : _border),
              boxShadow: _unreadCount > 0 ? [BoxShadow(color: _cyan.withValues(alpha: 0.15), blurRadius: 12)] : null,
            ),
            child: Row(children: [
              Stack(clipBehavior: Clip.none, children: [
                CircleAvatar(radius: 16, backgroundColor: _cyan.withValues(alpha: 0.15), child: const Icon(Icons.support_agent_rounded, color: _cyan, size: 16)),
                if (_unreadCount > 0)
                  Positioned(
                    top: -4, right: -4,
                    child: Container(
                      width: 18, height: 18,
                      decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                      child: Center(
                        child: Text(
                          _unreadCount > 9 ? '9+' : '$_unreadCount',
                          style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
              ]),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Text('Admin', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13)),
                  if (_unreadCount > 0) ...[
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(10)),
                      child: Text('$_unreadCount pesan baru', style: const TextStyle(color: Colors.white, fontSize: 9, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
                    ),
                  ],
                ]),
                Text(
                  _isClosed
                      ? 'Chat ditutup'
                      : _chatMessages.isEmpty
                          ? 'Ketuk untuk chat admin'
                          : _chatMessages.last['from'] == 'admin'
                              ? '${_chatMessages.last['message'] ?? ''}'
                              : _chatMessages.last['message'] ?? '',
                  style: TextStyle(
                    color: _unreadCount > 0 ? _cyan.withValues(alpha: 0.8) : Colors.white54,
                    fontFamily: 'Rajdhani',
                    fontSize: 11,
                    fontWeight: _unreadCount > 0 ? FontWeight.bold : FontWeight.normal,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ])),
              if (_isClosed) ...[
                const Icon(Icons.lock_rounded, color: Colors.white38, size: 16),
                const SizedBox(width: 6),
              ],
              Icon(_chatExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, color: Colors.white38, size: 18),
            ]),
          ),
        ),
        if (_chatExpanded) ...[
          const SizedBox(height: 6),
          Container(
            height: 340,
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _cyan.withValues(alpha: 0.3)),
              boxShadow: [BoxShadow(color: _cyan.withValues(alpha: 0.06), blurRadius: 16, spreadRadius: 1)],
            ),
            child: Column(children: [
              // Header chat
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: _cyan.withValues(alpha: 0.08),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(17)),
                  border: Border(bottom: BorderSide(color: _border)),
                ),
                child: Row(children: [
                  CircleAvatar(radius: 16, backgroundColor: _cyan.withValues(alpha: 0.15), child: const Icon(Icons.support_agent_rounded, color: _cyan, size: 16)),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Admin Support', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14)),
                    Row(children: [
                      Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: _adminOnline ? const Color(0xFF3DD68C) : Colors.white24)),
                      const SizedBox(width: 5),
                      Text(_adminOnline ? 'Online' : 'Offline', style: TextStyle(color: _adminOnline ? const Color(0xFF3DD68C) : Colors.white38, fontFamily: 'Rajdhani', fontSize: 10)),
                    ]),
                  ])),
                  const Text('Dominus Core', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 10)),
                ]),
              ),
              // Pesan
              Expanded(child: _chatMessages.isEmpty
                  ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.chat_bubble_outline_rounded, color: Colors.white.withOpacity(0.1), size: 40),
                      const SizedBox(height: 8),
                      const Text('Belum ada pesan\nKetik untuk mulai chat', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
                    ]))
                  : ListView.builder(
                      controller: _chatScroll,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      itemCount: _chatMessages.length,
                      itemBuilder: (_, i) {
                        final msg = _chatMessages[i];
                        final isUser = msg['from'] == 'user';
                        final isImage = msg['type'] == 'image';
                        final isVideo = msg['type'] == 'video';
                        final isSystem = msg['from'] == 'system';
                        final isBlockedMsg = msg['type'] == 'blocked';
                        final isUnblockedMsg = msg['type'] == 'unblocked';
                        final rawMediaUrl = msg['mediaUrl'] ?? '';
                        final mediaUrl = rawMediaUrl.isNotEmpty && rawMediaUrl.startsWith('/')
                            ? '${AppConfig.baseUrl}$rawMediaUrl'
                            : rawMediaUrl;

                        // System message: blokir/unblokir
                        if (isSystem) {
                          final sColor = isBlockedMsg ? const Color(0xFFFF3B5C) : const Color(0xFF00E676);
                          return Container(
                            margin: const EdgeInsets.symmetric(vertical: 10),
                            child: Center(
                              child: Container(
                                constraints: const BoxConstraints(maxWidth: 280),
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [sColor.withValues(alpha: 0.16), const Color(0xFF0B0F17).withValues(alpha: 0.9)],
                                  ),
                                  borderRadius: BorderRadius.circular(18),
                                  border: Border.all(color: sColor.withValues(alpha: 0.4), width: 1.2),
                                  boxShadow: [
                                    BoxShadow(color: sColor.withValues(alpha: 0.25), blurRadius: 24, spreadRadius: -6),
                                    const BoxShadow(color: Colors.black, blurRadius: 10, offset: Offset(0, 4)),
                                  ],
                                ),
                                child: Column(mainAxisSize: MainAxisSize.min, children: [
                                  Container(
                                    width: 52, height: 52,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: RadialGradient(colors: [sColor.withValues(alpha: 0.32), sColor.withValues(alpha: 0.04)]),
                                      border: Border.all(color: sColor.withValues(alpha: 0.6), width: 1.4),
                                      boxShadow: [BoxShadow(color: sColor.withValues(alpha: 0.4), blurRadius: 14, spreadRadius: 1)],
                                    ),
                                    child: Icon(
                                      isBlockedMsg ? Icons.block_rounded : Icons.lock_open_rounded,
                                      color: sColor,
                                      size: 24,
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: sColor.withValues(alpha: 0.14),
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(color: sColor.withValues(alpha: 0.35), width: 0.8),
                                    ),
                                    child: Text(
                                      isBlockedMsg ? 'CHAT DIBLOKIR' : 'CHAT DIBUKA',
                                      style: TextStyle(color: sColor, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 10, letterSpacing: 1.6),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Text(
                                    isBlockedMsg ? 'Chat Diblokir Admin' : 'Chat Dibuka Kembali',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Rajdhani',
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15,
                                      letterSpacing: 0.3,
                                    ),
                                  ),
                                  if (msg['message'] != null && msg['message'].toString().isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Container(height: 1, width: 40, color: sColor.withValues(alpha: 0.25)),
                                    const SizedBox(height: 8),
                                    Text(
                                      msg['message'],
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.white.withValues(alpha: 0.6),
                                        fontFamily: 'Rajdhani',
                                        fontSize: 12,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ]),
                              ),
                            ),
                          );
                        }

                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              if (!isUser) ...[
                                CircleAvatar(radius: 12, backgroundColor: _cyan.withValues(alpha: 0.15), child: const Icon(Icons.support_agent_rounded, color: _cyan, size: 12)),
                                const SizedBox(width: 6),
                              ],
                              Flexible(
                                child: GestureDetector(
                                  onTap: (isImage && mediaUrl.isNotEmpty)
                                      ? () => _openImageFull(context, mediaUrl.startsWith('http') ? mediaUrl : '${AppConfig.baseUrl}$mediaUrl', null)
                                      : null,
                                  child: Container(
                                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.65),
                                    decoration: BoxDecoration(
                                      color: isUser ? _cyan.withValues(alpha: 0.18) : Colors.white.withOpacity(0.07),
                                      borderRadius: BorderRadius.only(
                                        topLeft: const Radius.circular(14),
                                        topRight: const Radius.circular(14),
                                        bottomLeft: Radius.circular(isUser ? 14 : 2),
                                        bottomRight: Radius.circular(isUser ? 2 : 14),
                                      ),
                                      border: Border.all(color: isUser ? _cyan.withValues(alpha: 0.3) : _border),
                                    ),
                                    child: isImage && mediaUrl.isNotEmpty
                                        ? Stack(children: [
                                            ClipRRect(
                                              borderRadius: BorderRadius.only(
                                                topLeft: const Radius.circular(13),
                                                topRight: const Radius.circular(13),
                                                bottomLeft: Radius.circular(isUser ? 13 : 1),
                                                bottomRight: Radius.circular(isUser ? 1 : 13),
                                              ),
                                              child: Image.network(
                                                mediaUrl,
                                                width: 200, height: 200,
                                                fit: BoxFit.cover,
                                                loadingBuilder: (_, child, progress) => progress == null
                                                    ? child
                                                    : Container(width: 200, height: 200, color: _border, child: const Center(child: CircularProgressIndicator(color: _cyan, strokeWidth: 2))),
                                                errorBuilder: (_, __, ___) => Container(
                                                  width: 200, height: 100,
                                                  color: _border,
                                                  child: const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                                    Icon(Icons.image_rounded, color: Colors.white38, size: 32),
                                                    SizedBox(height: 4),
                                                    Text('Foto dari Admin', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11)),
                                                  ])),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              bottom: 6, right: 6,
                                              child: Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), borderRadius: BorderRadius.circular(6)),
                                                child: Row(mainAxisSize: MainAxisSize.max, mainAxisAlignment: MainAxisAlignment.center, children: [
                                                  const Icon(Icons.zoom_in_rounded, color: Colors.white70, size: 10),
                                                  const SizedBox(width: 3),
                                                  Text(msg['time'] ?? '', style: const TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontSize: 9)),
                                                ]),
                                              ),
                                            ),
                                          ])
                                        : isVideo && mediaUrl.isNotEmpty
                                            ? Container(
                                                width: 200, height: 120,
                                                decoration: BoxDecoration(
                                                  color: Colors.black,
                                                  borderRadius: BorderRadius.only(
                                                    topLeft: const Radius.circular(13),
                                                    topRight: const Radius.circular(13),
                                                    bottomLeft: Radius.circular(isUser ? 13 : 1),
                                                    bottomRight: Radius.circular(isUser ? 1 : 13),
                                                  ),
                                                ),
                                                child: Stack(alignment: Alignment.center, children: [
                                                  const Icon(Icons.play_circle_fill_rounded, color: Colors.white70, size: 50),
                                                  Positioned(bottom: 6, right: 6,
                                                    child: Container(
                                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                      decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), borderRadius: BorderRadius.circular(6)),
                                                      child: Row(mainAxisSize: MainAxisSize.max, mainAxisAlignment: MainAxisAlignment.center, children: [
                                                        const Icon(Icons.videocam_rounded, color: Colors.white70, size: 10),
                                                        const SizedBox(width: 3),
                                                        Text(msg['time'] ?? '', style: const TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontSize: 9)),
                                                      ]),
                                                    ),
                                                  ),
                                                ]),
                                              )
                                            : Padding(
                                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                                  Text(msg['message'] ?? '', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 13, height: 1.4)),
                                                  const SizedBox(height: 2),
                                                  Text(msg['time'] ?? '', style: TextStyle(color: Colors.white.withOpacity(0.35), fontFamily: 'Rajdhani', fontSize: 9)),
                                                ]),
                                              ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    )),
              // Input bar / Blocked / Closed UI
              if (_isBlocked)
                const SizedBox.shrink()
              else if (_isClosed)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.03),
                    border: Border(top: BorderSide(color: _border)),
                  ),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Icon(Icons.lock_rounded, color: Colors.white38, size: 14),
                    const SizedBox(width: 6),
                    const Text('Chat ditutup oleh admin',
                      style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12)),
                  ]),
                )
              else
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(border: Border(top: BorderSide(color: _border))),
                child: Row(children: [
                  // Tombol foto/video
                  GestureDetector(
                    onTap: _sendingImage ? null : _sendChatImage,
                    child: Container(
                      width: 38, height: 38,
                      decoration: BoxDecoration(
                        color: _sendingImage ? _border : _cyan.withValues(alpha: 0.12),
                        shape: BoxShape.circle,
                        border: Border.all(color: _cyan.withValues(alpha: 0.3)),
                      ),
                      child: _sendingImage
                          ? const Padding(padding: EdgeInsets.all(10), child: CircularProgressIndicator(color: _cyan, strokeWidth: 2))
                          : const Icon(Icons.attach_file_rounded, color: _cyan, size: 18),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF080D14),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: _border),
                    ),
                    child: TextField(
                      controller: _chatCtrl,
                      maxLines: 4,
                      minLines: 1,
                      style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 13),
                      decoration: const InputDecoration(
                        hintText: 'Ketik pesan ke admin...',
                        hintStyle: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 10),
                      ),
                      onSubmitted: (_) => _sendChatMsg(),
                    ),
                  )),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: _sendingChat ? null : _sendChatMsg,
                    child: Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xFFFF1744), Color(0xFFFF4081)]),
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: const Color(0xFFFF1744).withValues(alpha: 0.3), blurRadius: 8)],
                      ),
                      child: _sendingChat
                          ? const Padding(padding: EdgeInsets.all(10), child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                          : const Icon(Icons.send_rounded, color: Colors.white, size: 18),
                    ),
                  ),
                ]),
              ),
            ]),
          ),
        ],

        const SizedBox(height: 12),

        // Cek status button
        GestureDetector(
          onTap: _loadingStatus ? null : _checkStatus,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 13),
            decoration: BoxDecoration(
              color: _cyan.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _cyan.withValues(alpha: 0.4)),
            ),
            child: Center(
              child: _loadingStatus
                  ? const SizedBox(
                      width: 18, height: 18,
                      child: CircularProgressIndicator(color: _cyan, strokeWidth: 2))
                  : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.refresh_rounded, color: _cyan, size: 17),
                      const SizedBox(width: 8),
                      const Text('Cek Status Request',
                          style: TextStyle(
                              color: _cyan,
                              fontFamily: 'Rajdhani',
                              fontWeight: FontWeight.bold,
                              fontSize: 14)),
                    ]),
            ),
          ),
        ),

        const SizedBox(height: 12),

        // Kembali ke home
        GestureDetector(
          onTap: widget.onHome,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 13),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Color(0xFFFF1744), Color(0xFF0070A0)]),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                    color: _cyan.withValues(alpha: 0.25),
                    blurRadius: 12,
                    spreadRadius: 1),
              ],
            ),
            child: const Center(
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.home_rounded, color: Colors.white, size: 18),
                SizedBox(width: 8),
                Text('Kembali ke Home',
                    style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        letterSpacing: 1)),
              ]),
            ),
          ),
        ),
      ]),
    ), // SingleChildScrollView
    ); // DefaultTextStyle
  }

  Color _statusColor() {
    if (_status == 'approved') return const Color(0xFF059669);
    if (_status == 'rejected') return Colors.red.shade400;
    return _cyan;
  }

  IconData _statusIcon() {
    if (_status == 'approved') return Icons.check_circle_outline_rounded;
    if (_status == 'rejected') return Icons.cancel_outlined;
    return Icons.hourglass_empty_rounded;
  }

  String _statusTitle() {
    if (_status == 'approved') return _showRankUp ? 'Naik Pangkat!' : 'Akun Berhasil Dibuat!';
    if (_status == 'rejected') return 'Request Ditolak';
    return 'Bukti Terkirim!';
  }

  String _statusDesc() {
    if (_status == 'approved') return _showRankUp ? 'Role kamu berhasil di-upgrade!\nSelamat menikmati fitur baru.' : 'Akun kamu siap digunakan!\nSelamat bergabung dengan Dominus.';
    if (_status == 'rejected') return 'Request kamu ditolak admin.\nHubungi admin untuk informasi lebih lanjut.';
    return 'Admin sedang memverifikasi pembayaran kamu.\nAkun akan diaktifkan setelah konfirmasi.';
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: _cyan.withValues(alpha: 0.6), size: 15),
      const SizedBox(width: 8),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label,
              style: const TextStyle(
                  color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11)),
          Text(value,
              style: const TextStyle(
                  color: Colors.white, fontFamily: 'Rajdhani', fontSize: 13)),
        ]),
      ),
    ]);
  }

  Widget _timelineItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool done,
    required Color color,
  }) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: done ? color.withValues(alpha: 0.15) : _border.withValues(alpha: 0.3),
          border: Border.all(
              color: done ? color.withValues(alpha: 0.5) : _border, width: 1.5),
        ),
        child: Icon(icon, color: done ? color : Colors.white24, size: 17),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style: TextStyle(
                  color: done ? Colors.white : Colors.white38,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.bold,
                  fontSize: 13)),
          Text(subtitle,
              style: const TextStyle(
                  color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11, height: 1.4)),
        ]),
      ),
    ]);
  }

  Widget _timelineLine({required bool done}) {
    return Padding(
      padding: const EdgeInsets.only(left: 17, top: 3, bottom: 3),
      child: Container(
        width: 2, height: 24,
        color: done ? _cyan.withValues(alpha: 0.4) : _border,
      ),
    );
  }

  void _snack(String msg, {bool isErr = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(fontFamily: 'Rajdhani', color: Colors.white)),
      backgroundColor: isErr ? Colors.red.shade900 : const Color(0xFF059669),
    ));
  }
}


// ═══════════════════════════════════════════════════════════════════════════════
//  UPGRADE ROLE PAGE
// ═══════════════════════════════════════════════════════════════════════════════


// Role order untuk validasi upgrade
const List<String> _roleOrder = ['member', 'reseller', 'vip', 'owner', 'partner', 'staff', 'kingz'];

class UpgradeRolePage extends StatefulWidget {
  const UpgradeRolePage({super.key});

  @override
  State<UpgradeRolePage> createState() => _UpgradeRolePageState();
}

class _UpgradeRolePageState extends State<UpgradeRolePage> {
  // Steps: 0=cari user, 1=pilih role, 2=bayar, 3=status
  int _step = 0;
  Map<String, dynamic>? _foundUser;
  AccountPlan? _selectedPlan;
  String _durationType = 'monthly';
  String _requestId = '';

  static const _bg = Color(0xFF080D14);
  static const _card = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);
  static const _cyan = Color(0xFFFF1744);

  void _goStep(int s) => setState(() => _step = s);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          statusBarBrightness: Brightness.dark,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _cyan, size: 18),
          onPressed: () {
            if (_step > 0) _goStep(_step - 1);
            else Navigator.pop(context);
          },
        ),
        title: Text(
          _step == 0 ? 'CARI USER' : _step == 1 ? 'PILIH UPGRADE' : _step == 2 ? 'PEMBAYARAN' : 'STATUS',
          style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 1.5),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_rounded, color: Color(0xFFFF1744), size: 22),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => DeveloperSettingsPage(
                    currentBaseUrl: AppConfig.baseUrl,
                    onBaseUrlChanged: (newUrl) async {
                      await AppConfig.setBaseUrl(newUrl);
                    },
                  ),
                ),
              );
            },
          ),
          const SizedBox(width: 8),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(5),
          child: Container(height: 1, color: _border),
        ),
      ),
      body: _step == 0
          ? _UpgradeSearchUser(onFound: (user) { setState(() { _foundUser = user; _goStep(1); }); })
          : _step == 1
              ? _UpgradePickRole(
                  user: _foundUser!,
                  onConfirm: (plan, dur) { setState(() { _selectedPlan = plan; _durationType = dur; _goStep(2); }); },
                )
              : _step == 2
                  ? _StepBayar(
                      plan: _selectedPlan!,
                      durationType: _durationType,
                      requestId: _requestId,
                      onSuccess: (id) { setState(() { _requestId = id; _goStep(3); }); },
                      onRequestIdAssigned: (id, {qrisImageUrl, autoOrder = false, fee, totalWithFee}) {
                        setState(() => _requestId = id);
                      },
                      isUpgrade: true,
                      upgradeUsername: _foundUser!['username'],
                    )
                  : StepSukses(onHome: () => Navigator.pop(context), requestId: _requestId),
    );
  }
}

// ─── Step 0: Cari User ────────────────────────────────────────────────────────
class _UpgradeSearchUser extends StatefulWidget {
  final ValueChanged<Map<String, dynamic>> onFound;
  const _UpgradeSearchUser({required this.onFound});

  @override
  State<_UpgradeSearchUser> createState() => _UpgradeSearchUserState();
}

class _UpgradeSearchUserState extends State<_UpgradeSearchUser> {
  final _ctrl = TextEditingController();
  bool _loading = false;
  String? _error;
  Map<String, dynamic>? _result;
  List<String> _allUsers = [];
  List<String> _filteredUsers = [];
  bool _showDropdown = false;

  static const _bg = Color(0xFF080D14);
  static const _card = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);
  static const _cyan = Color(0xFFFF1744);

  @override
  void initState() {
    super.initState();
    _loadAllUsers();
    _ctrl.addListener(() {
      final q = _ctrl.text.trim().toLowerCase();
      setState(() {
        _filteredUsers = q.isEmpty
            ? _allUsers
            : _allUsers.where((u) => u.toLowerCase().contains(q)).toList();
        _showDropdown = _filteredUsers.isNotEmpty;
      });
    });
  }

  Future<void> _loadAllUsers() async {
    try {
      final resp = await http.get(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/list-users'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(resp.body);
      if (data['success'] == true && data['users'] != null) {
        final list = (data['users'] as List)
            .map((u) => (u['username'] ?? '').toString())
            .where((u) => u.isNotEmpty)
            .toList();
        list.sort();
        if (mounted) setState(() {
          _allUsers = list;
          _filteredUsers = list; // Show all users immediately
        });
      }
    } catch (_) {}
  }

  void _selectUser(String username) {
    _ctrl.text = username;
    setState(() { _showDropdown = false; });
    // Don't clear _filteredUsers - keep list visible for browsing
    _search();
  }

  Future<void> _search() async {
    final usn = _ctrl.text.trim();
    if (usn.isEmpty) return;
    setState(() { _loading = true; _error = null; _result = null; });
    try {
      final resp = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/find-user'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': usn}),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(resp.body);
      if (data['success'] == true) {
        setState(() => _result = data['user']);
      } else {
        setState(() => _error = data['message'] ?? 'User tidak ditemukan.');
      }
    } catch (_) {
      setState(() => _error = 'Gagal terhubung ke server.');
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      // Search field — SELALU nempel di atas, gak ikut scroll
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        child: Container(
          decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
          child: Row(children: [
            const SizedBox(width: 14),
            const Icon(Icons.person_search_rounded, color: _cyan, size: 20),
            const SizedBox(width: 10),
            Expanded(child: TextField(
              controller: _ctrl,
              style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 14),
              decoration: const InputDecoration(
                hintText: 'Masukkan username...',
                hintStyle: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 14),
              ),
              onSubmitted: (_) => _search(),
            )),
            GestureDetector(
              onTap: _loading ? null : _search,
              child: Container(
                margin: const EdgeInsets.all(6),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [_cyan, Color(0xFF0070A0)]),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: _loading
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('Cari', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
              ),
            ),
          ]),
        ),
      ),

      // Sisanya (header + list / error / result) — scroll sendiri di area yang tersisa,
      // gak akan ketimpuk search field atau appbar.
      Expanded(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // Users list - tampilkan semua user saat pertama kali
        if (_filteredUsers.isNotEmpty && _result == null) ...[
          Text('${_filteredUsers.length} USER TERDAFTAR', style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 11, letterSpacing: 2)),
          const SizedBox(height: 10),
          ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _filteredUsers.length,
              itemBuilder: (_, i) {
                final usn = _filteredUsers[i];
                return GestureDetector(
                  onTap: () => _selectUser(usn),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _border),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _cyan.withValues(alpha: 0.12),
                            border: Border.all(color: _cyan.withValues(alpha: 0.3)),
                          ),
                          child: Center(
                            child: Text(
                              usn[0].toUpperCase(),
                              style: const TextStyle(color: _cyan, fontSize: 14, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            usn,
                            style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600, fontFamily: 'Rajdhani'),
                          ),
                        ),
                        const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white38, size: 14),
                      ],
                    ),
                  ),
                );
              },
          ),
          const SizedBox(height: 16),
        ],

        // Error
        if (_error != null)
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.red.withOpacity(0.08), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.red.withOpacity(0.3))),
            child: Row(children: [
              const Icon(Icons.error_outline_rounded, color: Colors.red, size: 18),
              const SizedBox(width: 10),
              Text(_error!, style: const TextStyle(color: Colors.red, fontFamily: 'Rajdhani', fontSize: 13)),
            ]),
          ),

        // Result card
        if (_result != null) ...[
          const Text('USER DITEMUKAN', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 11, letterSpacing: 2)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _cyan.withValues(alpha: 0.3), width: 1.5),
              boxShadow: [BoxShadow(color: _cyan.withValues(alpha: 0.08), blurRadius: 20)],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Avatar + usn
              Row(children: [
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: _cyan.withValues(alpha: 0.12), border: Border.all(color: _cyan.withValues(alpha: 0.4), width: 1.5)),
                  child: Center(child: Text(_result!['username'][0].toUpperCase(), style: const TextStyle(color: _cyan, fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani'))),
                ),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(_result!['username'], style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900, fontFamily: 'Rajdhani')),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(color: _cyan.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20), border: Border.all(color: _cyan.withValues(alpha: 0.3))),
                    child: Text(_result!['role'].toString().toUpperCase(), style: const TextStyle(color: _cyan, fontSize: 11, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, letterSpacing: 1)),
                  ),
                ])),
              ]),
              const SizedBox(height: 14),
              Divider(color: _border, height: 1),
              const SizedBox(height: 14),
              Row(children: [
                Icon(Icons.calendar_month_rounded, color: Colors.white38, size: 15),
                const SizedBox(width: 8),
                const Text('Expired: ', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13)),
                Text(_result!['expiredDate'] ?? '-', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13)),
              ]),
              const SizedBox(height: 16),
              // Tombol
              Row(children: [
                Expanded(child: GestureDetector(
                  onTap: () => setState(() => _result = null),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.close_rounded, color: Colors.white54, size: 18),
                      SizedBox(width: 6),
                      Text('Keluar', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
                    ]),
                  ),
                )),
                const SizedBox(width: 12),
                Expanded(child: GestureDetector(
                  onTap: () => widget.onFound(_result!),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [_cyan, Color(0xFF0070A0)]),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: _cyan.withValues(alpha: 0.3), blurRadius: 10)],
                    ),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.check_rounded, color: Colors.white, size: 18),
                      SizedBox(width: 6),
                      Text('Pilih', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
                    ]),
                  ),
                )),
              ]),
            ]),
          ),
        ],
          ]),
        ),
      ),
    ]);
  }
}

// ─── Step 1: Pilih Role Upgrade ───────────────────────────────────────────────
class _UpgradePickRole extends StatefulWidget {
  final Map<String, dynamic> user;
  final Function(AccountPlan, String) onConfirm;
  const _UpgradePickRole({required this.user, required this.onConfirm});

  @override
  State<_UpgradePickRole> createState() => _UpgradePickRoleState();
}

class _UpgradePickRoleState extends State<_UpgradePickRole> {
  AccountPlan? _selected;
  String _durType = 'monthly';

  static const _bg = Color(0xFF080D14);
  static const _card = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);
  static const _cyan = Color(0xFFFF1744);

  // Filter plan yang lebih tinggi dari role sekarang
  List<AccountPlan> get _availablePlans {
    final currentRole = widget.user['role'].toString().toLowerCase();
    final currentIdx = _roleOrder.indexOf(currentRole);
    return kPlans.where((p) => _roleOrder.indexOf(p.role) > currentIdx).toList();
  }

  // Cek apakah role lama user itu permanent atau monthly dari expiredDate
  bool get _isCurrentPermanent {
    final exp = widget.user['expiredDate'];
    return exp == null || exp == 'permanent' || exp.toString().toLowerCase() == 'permanent';
  }

  int get _currentPrice {
    final currentRole = widget.user['role'].toString().toLowerCase();
    final currentPlan = kPlans.firstWhere((p) => p.role == currentRole, orElse: () => kPlans.first);
    // Potongan mengikuti durasi role lama user, bukan durasi yang dipilih sekarang
    return _isCurrentPermanent ? currentPlan.permanentPrice : currentPlan.monthlyPrice;
  }

  int get _selectedPrice => _selected == null ? 0 : (_durType == 'monthly' ? _selected!.monthlyPrice : _selected!.permanentPrice);
  int get _totalPrice => (_selectedPrice - _currentPrice).clamp(0, 999999999);

  String _fmt(int p) {
    if (p >= 1000) return 'Rp ${(p / 1000).toStringAsFixed(0)}.000';
    return 'Rp $p';
  }

  @override
  Widget build(BuildContext context) {
    final plans = _availablePlans;
    return Column(children: [
      Expanded(child: ListView(padding: const EdgeInsets.all(16), children: [
        // Info user
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
          child: Row(children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(shape: BoxShape.circle, color: _cyan.withValues(alpha: 0.12), border: Border.all(color: _cyan.withValues(alpha: 0.3))),
              child: Center(child: Text(widget.user['username'][0].toUpperCase(), style: const TextStyle(color: _cyan, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani', fontSize: 18))),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.user['username'], style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
              Text('Role saat ini: ${widget.user['role'].toString().toUpperCase()}', style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 12)),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: _cyan.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(20), border: Border.all(color: _cyan.withValues(alpha: 0.3))),
              child: Text(widget.user['role'].toString().toUpperCase(), style: const TextStyle(color: _cyan, fontSize: 10, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
            ),
          ]),
        ),
        const SizedBox(height: 16),

        // Duration toggle
        Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
          child: Row(children: [
            _DurTab(label: 'MONTHLY', icon: Icons.calendar_month_rounded, active: _durType == 'monthly', onTap: () => setState(() => _durType = 'monthly')),
            _DurTab(label: '∞  PERMANENT', active: _durType == 'permanent', onTap: () => setState(() => _durType = 'permanent')),
          ]),
        ),
        const SizedBox(height: 16),

        const Text('PILIH ROLE UPGRADE', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 11, letterSpacing: 2)),
        const SizedBox(height: 10),

        // Role cards
        ...plans.map((plan) {
          final isSelected = _selected?.role == plan.role;
          final price = _durType == 'monthly' ? plan.monthlyPrice : plan.permanentPrice;
          final gradient = plan.gradient;
          return GestureDetector(
            onTap: () => setState(() => _selected = plan),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: isSelected ? gradient[0].withValues(alpha: 0.12) : _card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: isSelected ? gradient[0].withValues(alpha: 0.6) : _border, width: isSelected ? 1.5 : 1),
                boxShadow: isSelected ? [BoxShadow(color: gradient[0].withValues(alpha: 0.15), blurRadius: 12)] : null,
              ),
              child: Row(children: [
                Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: gradient[0].withValues(alpha: 0.15), border: Border.all(color: gradient[0].withValues(alpha: 0.3))),
                  child: Icon(plan.icon, color: gradient[0], size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(plan.title, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14)),
                  Text(plan.badge, style: TextStyle(color: gradient[0], fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.bold)),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  ShaderMask(
                    shaderCallback: (b) => LinearGradient(colors: gradient).createShader(b),
                    child: Text(_fmt(price), style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 14)),
                  ),
                  if (isSelected)
                    Container(
                      margin: const EdgeInsets.only(top: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: gradient[0].withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                      child: Row(mainAxisSize: MainAxisSize.max, mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.check_circle_rounded, color: gradient[0], size: 11),
                        const SizedBox(width: 3),
                        Text('Dipilih', style: TextStyle(color: gradient[0], fontSize: 9, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
                      ]),
                    ),
                ]),
              ]),
            ),
          );
        }),

        // Ringkasan harga
        if (_selected != null) ...[
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('RINGKASAN HARGA', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1.5)),
              const SizedBox(height: 12),
              _priceRow('Harga role baru', _fmt(_selectedPrice), Colors.white),
              const SizedBox(height: 6),
              _priceRow(
                'Potongan role lama (${_isCurrentPermanent ? "Permanent" : "Monthly"})',
                '- ${_fmt(_currentPrice)}',
                Colors.red.shade400,
              ),
              Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Divider(color: _border, height: 1)),
              _priceRow('Total Bayar', _fmt(_totalPrice), _cyan, isBold: true, isLarge: true),
            ]),
          ),
        ],
        const SizedBox(height: 80),
      ])),

      // Tombol konfirmasi
      Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
        decoration: BoxDecoration(color: _bg, border: Border(top: BorderSide(color: _border, width: 1))),
        child: GestureDetector(
          onTap: _selected == null ? null : () => widget.onConfirm(_selected!, _durType),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 52,
            decoration: BoxDecoration(
              gradient: _selected != null ? LinearGradient(colors: _selected!.gradient) : null,
              color: _selected == null ? _card : null,
              borderRadius: BorderRadius.circular(16),
              boxShadow: _selected != null ? [BoxShadow(color: _selected!.gradient[0].withValues(alpha: 0.3), blurRadius: 16)] : null,
            ),
            child: Center(child: Text(
              _selected == null ? 'PILIH ROLE DULU' : 'LANJUT BAYAR  ${_fmt(_totalPrice)}',
              style: TextStyle(
                color: _selected == null ? Colors.white38 : Colors.white,
                fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1,
              ),
            )),
          ),
        ),
      ),
    ]);
  }

  Widget _priceRow(String label, String value, Color valueColor, {bool isBold = false, bool isLarge = false}) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 13)),
      Text(value, style: TextStyle(color: valueColor, fontFamily: 'Rajdhani', fontWeight: isBold ? FontWeight.w900 : FontWeight.normal, fontSize: isLarge ? 16 : 13)),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════
//  DONASI PAGE
// ═══════════════════════════════════════════════════════════════
class DonasiPage extends StatefulWidget {
  const DonasiPage({super.key});
  @override
  State<DonasiPage> createState() => _DonasiPageState();
}

class _DonasiPageState extends State<DonasiPage> with TickerProviderStateMixin {
  static const _bg     = Color(0xFF080D14);
  static const _card   = Color(0xFF0D1520);
  static const _border = Color(0xFF1A2840);

  // Step: 0=pilih nominal, 1=qris, 2=thanks
  int _step = 0;
  int? _selectedNominal;
  final _namaCtrl   = TextEditingController();
  final _customCtrl = TextEditingController();

  // QRIS state
  String? _donasiId;
  String? _qrisImageUrl;
  int?    _qrisFee;
  int?    _qrisTotal;
  bool    _loadingQris = false;
  String? _qrisError;
  Timer?  _pollTimer;

  // Thanks animation
  late AnimationController _heartCtrl;
  late Animation<double>   _heartAnim;

  final List<Map<String, dynamic>> _nominals = [
    {'label': 'Rp 5.000',   'value': 5000,   'icon': Icons.coffee_rounded,        'color': Color(0xFFFFB300)},
    {'label': 'Rp 10.000',  'value': 10000,  'icon': Icons.local_pizza_rounded,   'color': Color(0xFFFF7043)},
    {'label': 'Rp 25.000',  'value': 25000,  'icon': Icons.star_rounded,          'color': Color(0xFF66BB6A)},
    {'label': 'Rp 50.000',  'value': 50000,  'icon': Icons.emoji_events_rounded,  'color': Color(0xFF42A5F5)},
    {'label': 'Rp 100.000', 'value': 100000, 'icon': Icons.rocket_launch_rounded, 'color': Color(0xFFAB47BC)},
    {'label': 'Custom',     'value': -1,     'icon': Icons.edit_rounded,          'color': Color(0xFFFF1744)},
  ];

  @override
  void initState() {
    super.initState();
    _heartCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _heartAnim = CurvedAnimation(parent: _heartCtrl, curve: Curves.elasticOut);
  }

  @override
  void dispose() {
    _heartCtrl.dispose();
    _namaCtrl.dispose();
    _customCtrl.dispose();
    _pollTimer?.cancel();
    super.dispose();
  }

  String _fmt(int v) {
    if (v >= 1000000) return 'Rp ${(v / 1000000).toStringAsFixed(v % 1000000 == 0 ? 0 : 1)}jt';
    if (v >= 1000)    return 'Rp ${(v / 1000).toStringAsFixed(0)}.000';
    return 'Rp $v';
  }

  int get _nominal {
    if (_selectedNominal == -1) return int.tryParse(_customCtrl.text.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
    return _selectedNominal ?? 0;
  }

  Future<void> _buatQris() async {
    if (_nominal <= 0) return;
    setState(() { _loadingQris = true; _qrisError = null; });
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/requestkey/donasi/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'nominal': _nominal, 'nama': _namaCtrl.text.trim().isEmpty ? 'Anonim' : _namaCtrl.text.trim()}),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        setState(() {
          _donasiId    = data['donasiId'];
          _qrisImageUrl = data['qrisImageUrl'];
          _qrisFee     = data['fee'];
          _qrisTotal   = data['total'];
          _step        = 1;
          _loadingQris = false;
        });
        _startPolling();
      } else {
        setState(() { _qrisError = data['message'] ?? 'Gagal membuat QRIS.'; _loadingQris = false; });
      }
    } catch (_) {
      setState(() { _qrisError = 'Gagal terhubung ke server.'; _loadingQris = false; });
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 8), (_) async {
      try {
        final res  = await http.get(Uri.parse('${AppConfig.baseUrl}/api/requestkey/donasi/status?donasiId=$_donasiId'));
        final data = jsonDecode(res.body);
        if (data['status'] == 'paid') {
          _pollTimer?.cancel();
          setState(() => _step = 2);
          _heartCtrl.forward(from: 0);
        } else if (data['status'] == 'expired') {
          _pollTimer?.cancel();
          if (mounted) setState(() { _step = 0; _qrisError = 'QRIS expired, silakan coba lagi.'; });
        }
      } catch (_) {}
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Color(0xFFFF1744), size: 18),
          onPressed: () {
            if (_step == 1) { setState(() => _step = 0); _pollTimer?.cancel(); }
            else Navigator.pop(context);
          },
        ),
        title: Text(
          _step == 0 ? 'DONASI' : _step == 1 ? 'PEMBAYARAN' : 'TERIMA KASIH',
          style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 2),
        ),
        centerTitle: true,
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: _border)),
      ),
      body: _step == 0 ? _buildForm() : _step == 1 ? _buildQris() : _buildThanks(),
    );
  }

  // ── Step 0: Pilih Nominal ──────────────────────────────────────
  Widget _buildForm() {
    return ListView(padding: const EdgeInsets.all(16), children: [
      // Header
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFFFFB300), Color(0xFFFF6F00)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [BoxShadow(color: const Color(0xFFFFB300).withValues(alpha: 0.3), blurRadius: 20, offset: const Offset(0, 6))],
        ),
        child: const Column(children: [
          Icon(Icons.favorite_rounded, color: Colors.white, size: 40),
          SizedBox(height: 10),
          Text('Dukung Dominus', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 20, letterSpacing: 1)),
          SizedBox(height: 6),
          Text('Donasimu membantu kami terus berkembang\ndan menghadirkan fitur-fitur keren!', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontSize: 13)),
        ]),
      ),
      const SizedBox(height: 20),

      // Nama (opsional)
      Container(
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
        child: TextField(
          controller: _namaCtrl,
          style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 14),
          decoration: const InputDecoration(
            hintText: 'Nama kamu (opsional)...',
            hintStyle: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani'),
            prefixIcon: Icon(Icons.person_rounded, color: Colors.white38, size: 18),
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
      ),
      const SizedBox(height: 16),

      const Text('PILIH NOMINAL', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 11, letterSpacing: 2)),
      const SizedBox(height: 10),

      // Grid nominal
      GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.4,
        children: _nominals.map((n) {
          final isSelected = _selectedNominal == n['value'];
          final color = n['color'] as Color;
          return GestureDetector(
            onTap: () => setState(() => _selectedNominal = n['value'] as int),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              decoration: BoxDecoration(
                color: isSelected ? color.withValues(alpha: 0.15) : _card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: isSelected ? color : _border, width: isSelected ? 1.5 : 1),
                boxShadow: isSelected ? [BoxShadow(color: color.withValues(alpha: 0.25), blurRadius: 10)] : null,
              ),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(n['icon'] as IconData, color: isSelected ? color : Colors.white38, size: 22),
                const SizedBox(height: 6),
                Text(n['label'] as String, style: TextStyle(color: isSelected ? Colors.white : Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 12)),
              ]),
            ),
          );
        }).toList(),
      ),

      // Custom input
      if (_selectedNominal == -1) ...[
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFFF1744).withValues(alpha: 0.5))),
          child: TextField(
            controller: _customCtrl,
            keyboardType: TextInputType.number,
            style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontSize: 16, fontWeight: FontWeight.bold),
            decoration: const InputDecoration(
              hintText: 'Masukkan nominal...',
              hintStyle: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani'),
              prefixText: 'Rp  ',
              prefixStyle: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
          ),
        ),
      ],

      if (_qrisError != null) ...[
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.red.withValues(alpha: 0.3))),
          child: Text(_qrisError!, style: const TextStyle(color: Colors.redAccent, fontFamily: 'Rajdhani', fontSize: 13)),
        ),
      ],

      const SizedBox(height: 24),
      if (_selectedNominal != null)
        GestureDetector(
          onTap: _loadingQris ? null : _buatQris,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFFFFB300), Color(0xFFFF6F00)], begin: Alignment.centerLeft, end: Alignment.centerRight),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: const Color(0xFFFFB300).withValues(alpha: 0.4), blurRadius: 15, offset: const Offset(0, 5))],
            ),
            child: _loadingQris
              ? const Center(child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)))
              : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.qr_code_rounded, color: Colors.white, size: 20),
                  const SizedBox(width: 8),
                  Text('Donasi ${_fmt(_nominal)}  →  Generate QRIS', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 0.5)),
                ]),
          ),
        ),
    ]);
  }

  // ── Step 1: Tampil QRIS ────────────────────────────────────────
  Widget _buildQris() {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(18), border: Border.all(color: _border)),
        child: Column(children: [
          const Text('SCAN QRIS UNTUK DONASI', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1.5)),
          const SizedBox(height: 4),
          Text('Berlaku 15 menit • Polling otomatis', style: TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 11)),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(
              _qrisImageUrl ?? '',
              height: 260,
              fit: BoxFit.contain,
              loadingBuilder: (_, child, prog) => prog == null ? child
                  : const SizedBox(height: 260, child: Center(child: CircularProgressIndicator(color: Color(0xFFFFB300), strokeWidth: 2))),
              errorBuilder: (_, __, ___) => const SizedBox(height: 260, child: Center(child: Icon(Icons.qr_code_2_rounded, color: Colors.white24, size: 80))),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(color: const Color(0xFFFFB300).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFFFFB300).withValues(alpha: 0.3))),
            child: Column(children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('Nominal Donasi', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 13)),
                Text(_fmt(_nominal), style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 13)),
              ]),
              if (_qrisFee != null && _qrisFee! > 0) ...[
                const SizedBox(height: 4),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Biaya Admin', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 13)),
                  Text(_fmt(_qrisFee!), style: const TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 13)),
                ]),
                const Divider(color: Colors.white12, height: 16),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Total Bayar', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14)),
                  Text(_fmt(_qrisTotal ?? _nominal), style: const TextStyle(color: Color(0xFFFFB300), fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 16)),
                ]),
              ],
            ]),
          ),
          const SizedBox(height: 16),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Color(0xFFFFB300), strokeWidth: 2)),
            const SizedBox(width: 10),
            const Text('Menunggu pembayaran...', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 13)),
          ]),
        ]),
      ),
    ]);
  }

  // ── Step 2: Terima Kasih ───────────────────────────────────────
  Widget _buildThanks() {
    return Container(
      color: _bg,
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 32),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            // ── Thin outlined icon, no fill ──────────────────────
            ScaleTransition(
              scale: _heartAnim,
              child: Container(
                width: 76, height: 76,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFFFF1744).withValues(alpha: 0.5), width: 1),
                ),
                child: const Icon(Icons.favorite_rounded, color: Color(0xFFFF1744), size: 28),
              ),
            ),
            const SizedBox(height: 40),

            const Text('Terima Kasih',
                style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w600, fontSize: 26, letterSpacing: 0.5)),
            const SizedBox(height: 14),
            Text('Donasimu sebesar ${_fmt(_nominal)} telah kami terima.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 14, height: 1.6)),

            const SizedBox(height: 36),
            Container(width: 32, height: 1, color: Colors.white12),
            const SizedBox(height: 36),

            if (_donasiId != null) ...[
              Text(_donasiId!,
                  style: const TextStyle(color: Colors.white24, fontFamily: 'Rajdhani', fontSize: 12, letterSpacing: 1)),
              const SizedBox(height: 40),
            ],

            // ── CTA — minimal outlined ─────────────────────────────
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 15),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.white24, width: 1),
                ),
                child: const Text('Kembali',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70, fontFamily: 'Rajdhani', fontWeight: FontWeight.w500, fontSize: 15, letterSpacing: 0.5)),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  SYSTEM STATUS CARD
// ═══════════════════════════════════════════════════════════════
class _SystemStatusCard extends StatefulWidget {
  const _SystemStatusCard();
  @override
  State<_SystemStatusCard> createState() => _SystemStatusCardState();
}

class _SystemStatusCardState extends State<_SystemStatusCard> with TickerProviderStateMixin {
  late AnimationController _barCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double> _barAnim;
  late Animation<double> _pulse;

  bool _online  = false;
  int _cpu      = 0;
  int _memory   = 0;
  int _disk     = 0;
  int _perf     = 0;
  int _totalUser = 0;

  @override
  void initState() {
    super.initState();
    _barCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _barAnim = CurvedAnimation(parent: _barCtrl, curve: Curves.easeOutCubic);

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.5, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _fetchStats();
  }

  Future<void> _fetchStats() async {
    try {
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/api/server/stats'))
          .timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      if (mounted) {
        setState(() {
          _online = d['success'] == true;
          _cpu    = (d['cpu']  ?? 0) as int;
          _memory = (d['ram']  ?? 0) as int;
          _disk   = (d['disk'] ?? 0) as int;
          _perf   = (((_cpu + _memory) / 2)).round();
        });
        _barCtrl.forward(from: 0);
      }
    } catch (_) {}

    try {
      final ures = await http.get(Uri.parse('${AppConfig.baseUrl}/api/requestkey/banner-stats'))
          .timeout(const Duration(seconds: 8));
      final ud = jsonDecode(ures.body);
      if (mounted && ud['success'] == true) {
        setState(() => _totalUser = (ud['totalUser'] ?? 0) as int);
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _barCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _online ? const Color(0xFF00E676) : const Color(0xFFFF3B5C);

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFF1744).withValues(alpha: 0.5), width: 1.5),
        boxShadow: [
          BoxShadow(color: const Color(0xFFFF1744).withValues(alpha: 0.12), blurRadius: 22, spreadRadius: -2),
          const BoxShadow(color: Colors.black, blurRadius: 12, offset: Offset(0, 6)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(11),
        child: Stack(children: [
          // Background banner photo
          Positioned.fill(
            child: Image.asset(
              'assets/images/card.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: const Color(0xFF0B111C)),
            ),
          ),
          // Dark overlay so text stays readable
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFF060A12).withValues(alpha: 0.55),
                    const Color(0xFF060A12).withValues(alpha: 0.88),
                  ],
                ),
              ),
            ),
          ),
          // Content
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

              // System Performance — hero bar
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('System Performance', style: TextStyle(color: Colors.white54, fontFamily: 'Rajdhani', fontSize: 13, fontWeight: FontWeight.w600)),
                Text('$_perf%', style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15)),
              ]),
              const SizedBox(height: 8),
              AnimatedBuilder(
                animation: _barAnim,
                builder: (_, __) => _buildBar(_perf / 100 * _barAnim.value, const Color(0xFF60A5FA), height: 7),
              ),

              const SizedBox(height: 20),

              // Metrics row — icon + label + % + bar, each column
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _metricItem('CPU', Icons.memory_rounded, _cpu, const Color(0xFF34D399), _barAnim),
                const SizedBox(width: 16),
                _metricItem('RAM', Icons.developer_board_rounded, _memory, const Color(0xFFA78BFA), _barAnim),
                const SizedBox(width: 16),
                _metricItem('Disk', Icons.storage_rounded, _disk, const Color(0xFF60A5FA), _barAnim),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _buildBar(double value, Color color, {double height = 6}) {
    return Stack(children: [
      Container(height: height, decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(3))),
      FractionallySizedBox(
        widthFactor: value.clamp(0.0, 1.0),
        child: Container(
          height: height,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [color.withValues(alpha: 0.6), color]),
            borderRadius: BorderRadius.circular(3),
            boxShadow: [BoxShadow(color: color.withValues(alpha: 0.5), blurRadius: 7)],
          ),
        ),
      ),
    ]);
  }

  Widget _metricItem(String label, IconData icon, int val, Color color, Animation<double> anim) {
    return Expanded(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 18, height: 18,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              color: color.withValues(alpha: 0.16),
            ),
            child: Icon(icon, color: color, size: 11),
          ),
          const SizedBox(width: 6),
          Expanded(child: Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 12, fontWeight: FontWeight.w600), overflow: TextOverflow.ellipsis)),
        ]),
        const SizedBox(height: 8),
        Text('$val%', style: TextStyle(color: color, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 6),
        AnimatedBuilder(
          animation: anim,
          builder: (_, __) => _buildBar(val / 100 * anim.value, color, height: 5),
        ),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  GET FREE BUTTON
// ═══════════════════════════════════════════════════════════════
class _GetFreeButton extends StatefulWidget {
  const _GetFreeButton();
  @override
  State<_GetFreeButton> createState() => _GetFreeButtonState();
}

class _GetFreeButtonState extends State<_GetFreeButton> {
  bool _loading = false;

  Future<void> _createFree() async {
    setState(() => _loading = true);
    try {
      final res = await http.post(
        Uri.parse('${AppConfig.baseUrl}/api/user/create-free'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (!mounted) return;
      if (data['success'] == true) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => _FreeAccountDialog(
            username: data['username'],
            password: data['password'],
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(data['message'] ?? 'Gagal membuat akun free.', style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold)),
          backgroundColor: const Color(0xFFFF1744),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ));
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Gagal terhubung ke server.', style: TextStyle(fontFamily: 'Rajdhani')),
        backgroundColor: Color(0xFFFF1744),
        behavior: SnackBarBehavior.floating,
      ));
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _loading ? null : _createFree,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF22C55E), Color(0xFF16A34A)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: const Color(0xFF22C55E).withValues(alpha: 0.4), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: _loading
            ? const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)))
            : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.redeem_rounded, color: Colors.white, size: 20),
                SizedBox(width: 8),
                Text('Get Free Account', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 1)),
              ]),
      ),
    );
  }
}

class _FreeAccountDialog extends StatelessWidget {
  final String username;
  final String password;
  const _FreeAccountDialog({required this.username, required this.password});

  static const _green  = Color(0xFF22C55E);
  static const _bg     = Color(0xFF060B14);
  static const _card   = Color(0xFF0D1520);
  static const _border = Color(0xFF1C2A3A);

  void _copy(BuildContext context, String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$label disalin!', style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.bold, decoration: TextDecoration.none)),
      backgroundColor: _green,
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 1),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20),
      child: DefaultTextStyle(
        style: const TextStyle(decoration: TextDecoration.none, decorationColor: Colors.transparent),
        child: Container(
          decoration: BoxDecoration(
            color: _bg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _green.withOpacity(0.2), width: 1),
            boxShadow: [
              BoxShadow(color: _green.withOpacity(0.08), blurRadius: 30),
              BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20),
            ],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [

            // ── Header hijau seperti struk ─────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_green.withOpacity(0.18), _green.withOpacity(0.06)],
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                ),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              ),
              child: Column(children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _card,
                    border: Border.all(color: _green.withOpacity(0.5), width: 1.5),
                    boxShadow: [BoxShadow(color: _green.withOpacity(0.25), blurRadius: 12, spreadRadius: 1)],
                  ),
                  child: const Icon(Icons.card_giftcard_rounded, color: _green, size: 26),
                ),
                const SizedBox(height: 10),
                const Text(
                  'AKUN FREE BERHASIL',
                  style: TextStyle(color: _green, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2, decoration: TextDecoration.none),
                ),
                const SizedBox(height: 2),
                Text(
                  'Tap baris untuk menyalin',
                  style: TextStyle(color: Colors.white.withOpacity(0.35), fontFamily: 'Rajdhani', fontSize: 11, decoration: TextDecoration.none),
                ),
              ]),
            ),

            // ── Garis putus-putus ──────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: LayoutBuilder(builder: (context, constraints) {
                const dashW = 6.0, gap = 4.0;
                final count = (constraints.maxWidth / (dashW + gap)).floor();
                return Row(children: List.generate(count, (_) => Container(
                  width: dashW, height: 1,
                  margin: const EdgeInsets.only(right: gap),
                  color: Colors.white12,
                )));
              }),
            ),

            // ── Kredensial ─────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                decoration: BoxDecoration(
                  color: _card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _border),
                ),
                child: Column(children: [
                  _credRow(context, Icons.person_rounded, 'Username', username, copyable: true),
                  Container(height: 1, color: _border),
                  _credRow(context, Icons.lock_rounded, 'Password', password, copyable: true),
                  Container(height: 1, color: _border),
                  _credRow(context, Icons.verified_rounded, 'Role', 'Free'),
                  Container(height: 1, color: _border),
                  _credRow(context, Icons.all_inclusive_rounded, 'Expired', 'Permanent'),
                ]),
              ),
            ),

            const SizedBox(height: 12),

            // ── Warning ────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1200),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFD97706).withOpacity(0.4)),
                ),
                child: const Row(children: [
                  Icon(Icons.photo_camera_rounded, color: Color(0xFFD97706), size: 15),
                  SizedBox(width: 10),
                  Expanded(child: Text(
                    'Screenshot sekarang! Password tidak bisa dilihat lagi.',
                    style: TextStyle(color: Color(0xFFD97706), fontFamily: 'Rajdhani', fontSize: 11, fontWeight: FontWeight.w700, decoration: TextDecoration.none),
                  )),
                ]),
              ),
            ),

            const SizedBox(height: 14),

            // ── Button ─────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF22C55E), Color(0xFF16A34A)]),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [BoxShadow(color: _green.withOpacity(0.35), blurRadius: 14, offset: const Offset(0, 5))],
                  ),
                  child: const Text(
                    'MENGERTI',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 2, decoration: TextDecoration.none),
                  ),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _credRow(BuildContext context, IconData icon, String label, String value, {bool copyable = false}) {
    return GestureDetector(
      onTap: copyable ? () => _copy(context, value, label) : null,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
        child: Row(children: [
          Icon(icon, color: copyable ? _green : Colors.white24, size: 15),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'Rajdhani', fontSize: 13, decoration: TextDecoration.none))),
          Text(value, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 13, decoration: TextDecoration.none)),
          if (copyable) ...[
            const SizedBox(width: 8),
            Icon(Icons.copy_rounded, color: _green.withOpacity(0.5), size: 13),
          ],
        ]),
      ),
    );
  }
}
