package com.nullx.shadow;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
